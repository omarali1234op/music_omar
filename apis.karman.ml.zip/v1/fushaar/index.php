<?php
header('Content-Type: application/json');
$botss = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET["token"]."/getme"),1);
$id = $botss["result"]["id"];
mkdir("token/$id");
if($_GET["token"] and $botss["ok"] == true){
file_put_contents("token/$id/token.txt", $_GET["token"]);
$name = $_GET["search"];
$Movie = "https://www.fushaar.com/movie/".$name."";
$ch = curl_init();
$headers = array(
'referer: https://www.fushaar.com/',
'user-agent: Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.99 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_URL, $Movie );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt($ch, CURLOPT_HTTPHEADER, $header );
$result = curl_exec( $ch );
curl_close($ch);
$title = '/<meta property="og:title" content="(.*?)" \/>/';
preg_match_all($title,$result,$title);
$description = '/<meta property="og:description" content="(.*?)" \/>/';
preg_match_all($description,$result,$description);
$photo = '/<meta property="og:image" content="(.*?)" \/>/';
preg_match_all($photo,$result,$photo);
$links = '/<a class="watch-hd" href="(.*?)" target="_blank"/';
preg_match_all($links,$result,$links);
$array['title'] = $title[1];
$array['des'] = $description[1];
$array['photo'] = $photo[1];
$array['q240'] = $links[1][2];
$array['q480'] = $links[1][3];
$array['q1080'] = $links[1][4];
$array['Dev'] = "VIRUS : @VR_LA";
echo json_encode($array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}