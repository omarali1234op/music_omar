<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["search"]){
$url = file_get_contents("https://www.fushaar.info/?s=".$_GET["search"]);
$count = explode('<article class="poster">',$url);
for($i=1;$i<count($count)-1;$i++){
preg_match_all('#<a title=”(.*?)” href="(.*?)">#',$url,$move);
preg_match_all('#<div class="card_content" style="background: url(.*?) no-repeat left bottom;">#',$url,$img);
preg_match_all('#<li class="year">(.*?)</li>#',$url,$year);
$imag = str_replace("(","",$img[1][$i]);
$image = str_replace(")","",$imag);
$info[] = [
"title"=>$move[1][$i],
"url"=>$move[2][$i],
"image"=>$image,
"year"=>$year[1][$i],
];
}
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET["url"]){
$url = file_get_contents($_GET["url"]);
preg_match_all('#<meta property="og:title" content="(.*?)"#',$url,$title);
preg_match_all('#<meta property="og:description" content="(.*?)"#',$url,$description);
preg_match_all('#<meta property="og:image" content="(.*?)"#',$url,$img);
preg_match_all('#<a class="watch-hd" href="(.*?)" target="_blank"#',$url,$watch);
$info = [
"title"=>$title[1][0],
"description"=>$description[1][0],
"image"=>$img[1][0],
"watch"=>$watch[1][3],
];
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}