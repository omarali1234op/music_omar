<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["search"]){
$url = file_get_contents("https://akwam.to/search?q=".$_GET["search"]);
$count = explode('<i class="icon-play"></i>',$url);
for($i=1;$i<count($count)-1;$i++){
$url = file_get_contents("https://akwam.to/search?q=".$_GET["search"]);
preg_match_all('#<a href="(.*?)" class="text-white">(.*?)</a>#',$url,$move);
preg_match_all('#<img src="(.*?)" data-src="(.*?)" class="img-fluid w-100 lazy" alt="(.*?)" />#',$url,$img);
preg_match_all('#<span class="label quality">(.*?)</span>#',$url,$quality);
$json[] = [
'title'=>$move[2][$i],
'url'=>$move[1][$i],
'image'=>$img[2][$i],
'quality'=>$quality[1][$i],
];
}
echo json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET["url"]){
$url = file_get_contents($_GET["url"]);
preg_match_all('#<a href="(.*?)" class="link-btn link-download d-flex align-items-center px-3">#',$url,$m);
$idd = $m[1][2];
$ex = explode('/',$idd);
$id = $ex[4];
$uu = $_GET["url"];
$exx = explode('/',$uu);
$mid = $exx[4];
$mo = $exx[5];
preg_match_all('#<meta property="og:image" content="(.*?)" />#',$url,$img);
preg_match_all('#<meta property="og:description" content="(.*?)" />#',$url,$description);
preg_match_all('#<span class="label quality">(.*?)</span>#',$url,$quality);
$down = "https://two.akwam.cc/watch/$id/$mid/$mo";
$array['title'] = $mo;
$array['des'] = $description[1][0];
$array['photo'] = $img[1][0];
$array['quality'] = $quality[1][0];
$array['watch'] = $down;
$array['Dev'] = "VIRUS : @VR_LA";
echo json_encode($array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}