<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["CarLetter"] and $_GET["CarNumber"] and $_GET["CarType"] and $_GET["CarReg"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://itp.gov.iq/carSearch.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority' => 'itp.gov.iq',
    'accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language' => 'ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6',
    'cache-control' => 'max-age=0',
    'content-type' => 'application/x-www-form-urlencoded',
    'origin' => 'https://itp.gov.iq',
    'referer' => 'https://itp.gov.iq/carSearch.php',
    'sec-ch-ua' => '"Chromium";v="105", "Not)A;Brand";v="8"',
    'sec-ch-ua-mobile' => '?1',
    'sec-ch-ua-platform' => '"Android"',
    'sec-fetch-dest' => 'document',
    'sec-fetch-mode' => 'navigate',
    'sec-fetch-site' => 'same-origin',
    'sec-fetch-user' => '?1',
    'upgrade-insecure-requests' => '1',
    'user-agent' => 'Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36',
    'Accept-Encoding' => 'gzip',
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, "CarLetter=".$_GET["CarLetter"]."&CarNumber=".$_GET["CarNumber"]."&CarType=".$_GET["CarType"]."&CarReg=".$_GET["CarReg"]."&submit=بحث");
$response = curl_exec($ch);
curl_close($ch);
$resulst = '#</table><br>(.*?)<br>#';
preg_match_all($resulst,$response,$resulst);
$result = $resulst[1];
$info = [
'Car'=>$result,
'by'=>"VIRUS - @VR_LA",
];
echo json_encode($info,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

}