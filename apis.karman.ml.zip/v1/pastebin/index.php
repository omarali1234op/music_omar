<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["text"]){
$key = "pzRb3hVAu3Bmjm8ng3iuIpboHvciZSva";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://pastebin.com/api/api_post.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "api_dev_key=".$key."&api_paste_code=".$_GET["text"]."&api_option=paste");
$headers = array();
$headers[] = "Content-Type: application/x-www-form-urlencoded";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
echo $response;
}