<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["id"]){
$curl = curl_init();
$key = "u1882931-3b6bf6896d89038ca4ef9511";
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.uptimerobot.com/v2/deleteMonitor",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "api_key=".$key."&format=json&id=".$_GET["id"],
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded"
  ),
));
$response = curl_exec($curl);
curl_close($curl);
$json = json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}