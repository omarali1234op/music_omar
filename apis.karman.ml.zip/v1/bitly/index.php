<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["url"]){
$short = file_get_contents("http://tinyurl.com/api-create.php?url=".$_GET["url"]);
$ex = explode('/',$short);
$id = $ex[3];
$info = [
"id"=>$id,
];
echo json_encode($info,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}