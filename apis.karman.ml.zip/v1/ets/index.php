<?php
header("Content-Type: application/json; charset=UTF-8");
error_reporting(0);
if($_GET["number"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.etisalat.eg/adl/games/sendActivationCode');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"dial":"'.$_GET["number"].'","channelId":"22","lang":"EN"}');
$headers = array();
$headers[] = 'Host: www.etisalat.eg';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Content-Length: 51';
$headers[] = 'Accept: application/json, text/plain, */*';
$headers[] = 'X-Ts-Ajax-Request: true';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
$headers[] = 'Content-Type: application/json';
$headers[] = 'Sec-Gpc: 1';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.5';
$headers[] = 'Origin: https://www.etisalat.eg';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Referer: https://www.etisalat.eg/etisalatgames/';
$headers[] = 'Accept-Encoding: gzip, deflate, br';
$headers[] = 'Cookie: DYN_USER_ID=741995029; DYN_USER_CONFIRM=2f2fd28971e221d675d8ae92a65607b9; userPrefLanguage=en_US; TS017ffcb1_28=01d8d7aa2ba466e42bc587731937bdf1640605383169292eb91f96e40b5695de685cce0e3d703728b7a59d1de5c7d63738e3db3e7a; JSESSIONID=RAqzT3QlM6wRo69QplHO4fjO2K1MHAJXmuNIT1lG1quL-bXNoyLb!-371507538; TS017ffcb1=010cd381e8e73b3761816614121b0a796f860525e90790d59daed4556781edf79e66560eb7dc8b2a00c5b0efe01b30923c6f891f4a';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json =  json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}