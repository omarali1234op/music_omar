<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["site"]){
$site = file_get_contents("".$_GET["site"]."");
echo $site;
}