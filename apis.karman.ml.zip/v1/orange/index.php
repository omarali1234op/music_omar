<?php
header("Content-Type: application/json; charset=UTF-8");
$ch = curl_init();
$user_agent = $_SERVER["HTTP_USER_AGENT"];
if($_GET["number"]){
$url = file_get_contents("http://oleorange.com/login");
preg_match_all('#<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="(.*?)" />#',$url,$VIEWSTATE);
preg_match_all('#<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.*?)" />#',$url,$VIEWSTATEGENERATOR);
preg_match_all('#<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="(.*?)" />#',$url,$EVENTVALIDATION);
curl_setopt($ch, CURLOPT_URL, 'http://oleorange.com/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "__LASTFOCUS=&__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=".$VIEWSTATE."&__VIEWSTATEGENERATOR=".$VIEWSTATEGENERATOR."&__EVENTVALIDATION=".$EVENTVALIDATION."&txtPhone=".$_GET["number"]."&btnLogin=%D8%A7%D9%84%D8%AF%D8%AE%D9%88%D9%84");
$mm = curl_init('http://oleorange.com/login');
curl_setopt($mm, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($mm, CURLOPT_HEADER, 1);
$response = curl_exec($mm);
preg_match_all('/^Set-Cookie:\s*([^;]*)/mi',$response,$cookies);
$headers = array();
$headers[] = 'Host: oleorange.com';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Content-Length: 457';
$headers[] = 'Cache-Control: max-age=0';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Origin: http://oleorange.com';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
$headers[] = 'Referer: http://oleorange.com/login';
$headers[] = 'Accept-Encoding: gzip, deflate';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Cookie: '.$cookies[1][0];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
curl_close($ch);
echo $result;
}