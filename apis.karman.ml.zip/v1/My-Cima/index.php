<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["search"]){
$url = file_get_contents("https://mycima.fun/search/".$_GET["search"]."/");
$count = explode('<div class="Social--Info--GridItem">',$url);
for($i=1;$i<count($count)-1;$i++){
preg_match_all('#https://mycimaa.tube/watch/(.*?)/#',$url,$link);
preg_match_all('#<a href="(.*?)" title="(.*?)">#',$url,$title); /*[2][$i]*/
preg_match_all('#data-lazy-style="--image:url(.*?);"#',$url,$img);
$imag = str_replace("(","",$img[1][$i]);
$image = str_replace(")","",$imag);
$info[] = [
"title"=>$title[2][$i],
"url"=>$link[0][$i],
"image"=>$image,
];
}
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET["url"]){
$url = file_get_contents($_GET["url"]);
preg_match_all('#<span itemprop="name">(.*?)</span>#',$url,$title);
preg_match_all('#<div class="StoryMovieContent">(.*?)</div>#',$url,$description);
preg_match_all('#<meta itemprop="thumbnailUrl" content="(.*?)" />#',$url,$img);
preg_match_all('#<meta itemprop="embedURL" content="(.*?)" />#',$url,$watch);
$info[] = [
"title"=>$title[1][3],
"Description"=>$description[1][0],
"image"=>$img[1][0],
"watch"=>$watch[1][0],
];
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET["series"]){
$url = file_get_contents("https://mycima.fun/series/".$_GET["series"]);
$count = explode('<i class="fa fa-play">',$url);
for($i=1;$i<count($count)-1;$i++){
preg_match_all('#<episodeTitle>(.*?)</episodeTitle>#',$url,$title);
preg_match_all('#style="--img:url(.*?);"#',$url,$img);
preg_match_all('#https://mycimaa.tube/watch/(.*?)/#',$url,$series);
$imag = str_replace("(","",$img[1][0]);
$image = str_replace(")","",$imag);
$info[] = [
"title"=>$title[1][$i],
"image"=>$image,
"url"=>$series[0][$i],
];
}
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}