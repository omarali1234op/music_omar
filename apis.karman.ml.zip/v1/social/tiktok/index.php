<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["url"]){
$ch = curl_init();
$token = file_get_contents("https://ssstik.io/en");
preg_match_all('#"tt:(.*?)"#',$token,$t);
$tt = str_replace("'","",$t[1][0]);
$url = curl_init('https://ssstik.io/en');
curl_setopt($url, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($url, CURLOPT_HEADER, 1);
$result = curl_exec($url);
preg_match_all('/^Set-Cookie:\s*([^;]*)/mi',$result,$cookie);
$ssstik = $cookie[1][0];
$__cflb = $cookie[1][1];
curl_setopt($ch, CURLOPT_URL, 'https://ssstik.io/abc?url=dl');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "id=".$_GET["url"]."&locale=ar&tt=".$tt);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: ssstik.io';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = "Cookie: ad_client=".$ssstik."; ".$__cflb;
$headers[] = 'Hx-Current-Url: https://ssstik.io/en';
$headers[] = 'Hx-Request: true';
$headers[] = 'Hx-Target: target';
$headers[] = 'Hx-Trigger: _gcaptcha_pt';
$headers[] = 'Origin: https://ssstik.io';
$headers[] = 'Referer: https://ssstik.io/en';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
preg_match_all('#src="(.*?)"#',$response,$PicAccount);
preg_match_all('#alt="(.*?)"#',$response,$Account);
preg_match_all('#href="(.*?)"#',$response,$links);
preg_match_all('#<p class="maintext">(.*?)</p>#',$response,$description);
preg_match_all('#<div>\n(.*?)</div>#',$response,$about);
$info[] = [
"PicAccount"=>$PicAccount[1][0],
"Account"=>$Account[1][0],
"WithoutWaterMark"=>$links[1][1],
"Music"=>$links[1][3],
"Description"=>$description[1][0],
"Love"=>$about[1][0],
"Comments"=>$about[1][1],
"Explore"=>$about[1][2],
"By"=>"VIRUS - @VR_LA",
];
echo json_encode($info,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}