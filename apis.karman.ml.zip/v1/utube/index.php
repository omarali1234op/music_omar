<?php
header('Content-Type: application/json');
if($_GET["url"]){
$link = $_GET["url"];
$api = json_decode(file_get_contents('https://api.snappea.com/v1/video/details?url='.$link),true);
$ti = $api['videoInfo']['title'];
$ViewsCount = $api['videoInfo']['viewCount'];
$thumbnail = $api['videoInfo']['thumbnail'];
$mp3 = $api['videoInfo']['downloadInfoList'][0]['partList'][0]['urlList'][0];
$mp4 = $api['videoInfo']['downloadInfoList'][4]['partList'][0]['urlList'][0];
$By = "virus - @VR_LA";
$info[] = [
'title'=>$ti,
'views'=>$ViewsCount,
'thumbnail'=>$thumbnail,
'mp3'=>$mp3,
'mp4'=>$mp4,
'Dev'=>$By,
];
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET["search"]){

$search = isset($_GET['search']) ? $_GET['search'] : NULL;

function thousandsCurrencyFormat($num)
{

    if ($num > 1000) {

        $x = round($num);
        $x_number_format = number_format($x);
        $x_array = explode(',', $x_number_format);
        $x_parts = array('k', 'm', 'b', 't');
        $x_count_parts = count($x_array) - 1;
        $x_display = $x;
        $x_display = $x_array[0] . ((int) $x_array[1][0] !== 0 ? '.' . $x_array[1][0] : '');
        $x_display .= $x_parts[$x_count_parts - 1];

        return $x_display;
    }

    return $num;
}


if (isset($search)) {
    $get = file_get_contents("https://www.youtube.com/results?search_query=" . urlencode($search));

    $pattrn = '/\\,{"videoRenderer":{"videoId":"(.*?)","thumbnail":{"thumbnails":\[{"url":"(.*?)"\\b(.*?)\\"title":{"runs":\[{"text":"(.*?)\"\\b(.*?)\\,"simpleText":"(.*?)"},"viewCountText":{"simpleText":"(.*?)"}/';
    preg_match_all($pattrn, $get, $json);

    function unescapeUTF8EscapeSeq($str)
    {
        return preg_replace_callback(
            "/\\\u([0-9a-f]{4})/i",
            function ($matches) {
                return html_entity_decode('&#x' . $matches[1] . ';', ENT_QUOTES, 'UTF-8');
            },
            $str
        );
    }

    $array['ok'] = true;
    for ($i = 0; $i <= count($json[1]) - 1; $i++) {
        $title = str_replace('",', null, preg_replace('#[0-9@=|()!-/"\}]]#', null, unescapeUTF8EscapeSeq($json[4][$i])));
        $url   = $json[1][$i];
        $image = str_replace('",', null, $json[2][$i]);
        $time  = $json[6][$i];
        $view  = str_replace("weergaven", null, $json[7][$i]);
        $array['results'][] = [
            'title' => $title,
            'url'   => $url,
            'time'  => $time,
            'view'  => thousandsCurrencyFormat(preg_replace('#[^0-9]#', null, $view)),
            'image' => $image,
        ];
    }
    echo json_encode($array, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}}