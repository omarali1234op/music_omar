<?php
header("Content-Type: application/json; charset=UTF-8");
$ch = curl_init();
if($_GET["number"]){
curl_setopt($ch, CURLOPT_URL, "https://asia-south1-truecaller-web.cloudfunctions.net/api/noneu/search/v1?q=".$_GET["number"]."&countryCode=eg");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: asia-south1-truecaller-web.cloudfunctions.net';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2Njk4MzkwODk3ODQsInRva2VuIjoiYTF3MDctLWJWZHowdmtOLVVnTUkxTTQwWnhRQ3RrekJYQ2lsNlQwSFdhcHBxRXZIZjhhbkRiWVFNNlpCOU5vdyIsImVuaGFuY2VkU2VhcmNoIjp0cnVlLCJjb3VudHJ5Q29kZSI6ImVnIiwibmFtZSI6Itin2YTYq9in2YbZiNmK2Kkg2KfZhNi52YrZhdmHIFBFR1kyIiwiZW1haWwiOiJhN21vczY0QGdtYWlsLmNvbSIsImltYWdlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUxtNXd1Mks5cml6Yy1kVURGb0dLczB1X19Db3p0NmdXamtZLVhObHFMVWE9czk2LWMiLCJpYXQiOjE2NjcxNjA2ODl9.EJeM2eamy968tx9bD_Qs86Rgs_GQRWOgaSG6pahO4Xc';
$headers[] = 'Origin: https://www.truecaller.com';
$headers[] = 'Referer: https://www.truecaller.com/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: cross-site';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
curl_close($ch);
$json =  json_decode($result);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}