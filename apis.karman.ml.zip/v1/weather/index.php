<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["country"]){
$api = json_decode(file_get_contents("http://api.weatherapi.com/v1/current.json?key=cdbefb35b63d4bd7b40204848222610&q=".$_GET["country"]."&aqi=no"),1);
echo json_encode($api,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}