<?php
error_reporting(0);
header("Content-Type: application/json; charset=UTF-8");
if($_GET['q']){
$response = file_get_contents('https://lake.egybest.life/autoComplete.php?q='.urlencode($_GET['q']));
$result = json_decode($response, 1);
$arr = array();
$url = file_get_contents("https://move.egybest.golf/explore/?q=".urlencode($_GET['q']));
$_ex = explode('<i class="i-fav rating">',$url);
for ($i=1; $i < count($_ex)-1; $i++) {
preg_match('#<a href="(.*?)" class="movie">#',$_ex[$i],$href);
preg_match('#<i>(.*?)</i>#',$_ex[$i],$rating);
preg_match('#<img src="(.*?)" alt="(.*?)">#',$_ex[$i],$img);
preg_match('#<span class="title">(.*?)</span>#',$_ex[$i],$title);
preg_match('#<span>(.*?)</span>#',$_ex[$i],$type);
$json[] = [
'title'=>$title[1],
'url'=>$href[1],
'image'=>$img[1],
'rating'=>$rating[1],
'type'=>$type[1]
];
}
$arr["all_results"] = $json;
if(!$json) $arr["all_results"] = null;
$arr["prominent_results"] = $result;
if(!$result[urlencode($_GET['q'])]) $arr["prominent_results"] = null;
echo json_encode($arr,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET['url']){
$url = file_get_contents($_GET['url'].'#download');
$_ex = explode('nop btn g dl _open_window',$url);
for ($i=1; $i < count($_ex)-1; $i++) {
preg_match('#<td>(.*?)</td> <td>(.*?)<i#',$_ex[$i],$href);
preg_match('#<img src="(.*?)" alt="(.*?)">#',$url,$img);
preg_match('#data-url="(.*?)">#',$_ex[$i],$dl);
preg_match('#<a class="nop btn b dl _open_window" data-url="(.*?)"><i class="i-playc"></i> مشاهدة</a>#',$_ex[$i],$playc);
$json[] = [
'title'=>$img[2],
'type'=>$href[1],
'size'=>$href[2],
'dl'=>"https://move.egybest.golf".$dl[1],
'playc'=>"https://move.egybest.golf/watch/?v=".$playc[1]
];
}
$arr["all_results"] = $json;
if(!$json) $arr["all_results"] = null;
echo json_encode($arr,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}