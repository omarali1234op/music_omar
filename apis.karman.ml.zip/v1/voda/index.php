<?php
header("Content-Type: application/json; charset=UTF-8");
error_reporting(0);
if($_GET["number"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://telcos.osn.com/eg/vodafone/assets/php/getTicketId.php?lp=ar&lpLang=ar');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "subscription-type-id=65130002&MSISDN-input=".$_GET["number"]."&MSISDN=".$_GET["number"]."");
$headers = array();
$headers[] = 'Host: telcos.osn.com';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Content-Length: 73';
$headers[] = 'Cache-Control: max-age=0';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Origin: https://telcos.osn.com';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8';
$headers[] = 'Sec-Gpc: 1';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.8';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: navigate';
$headers[] = 'Sec-Fetch-User: ?1';
$headers[] = 'Sec-Fetch-Dest: document';
$headers[] = 'Referer: https://telcos.osn.com/eg/vodafone/ar/';
$headers[] = 'Accept-Encoding: gzip, deflate, br';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json =  json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}