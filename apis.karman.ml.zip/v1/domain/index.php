<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["domain"]){
$lista = $_GET['domain'];
$ex = explode('.',$lista);
$domain = $ex[0];
$tld = $ex[1];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://my.freenom.com/includes/domains/fn-available.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "domain=".$domain."&tld=".$tld);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: my.freenom.com';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Cookie: mydottk_languagenr=12; dottyLn=ar; wwwLn=ar; WHMCSZH5eHTGhfvzP=973q2j271mn5meqb5ikbeh8qd0; _ga=GA1.2.1704992932.1665610822; _gid=GA1.2.119028522.1665610822; _gat=1';
$headers[] = 'Origin: https://www.freenom.com';
$headers[] = 'Referer: https://www.freenom.com/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-site';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json =  json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}