<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["url"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.deepai.org/api/colorizer');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "image=".$_GET["url"]);

$headers = array();
$headers[] = 'Api-Key: 6ad07515-ccf3-48e7-a4c6-eafaa2aa04b6';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
curl_close($ch);

echo $result;
}