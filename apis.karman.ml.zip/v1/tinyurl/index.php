<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["url"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://tinyurl.com/app/api/create');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"url":"'.$_GET["url"].'","domain":"tinyurl.com","alias":"","tags":[],"errors":{"errors":{}},"busy":true,"successful":false}');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: tinyurl.com';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Content-Type: application/json';
$headers[] = 'Cookie: tinyUUID=eyJpdiI6Iit5ZjlvTWNuQXhSMkxuRVRDOW9RWEE9PSIsInZhbHVlIjoiVldlZ0VYMzFwZEgzMUJIVjVkcFhsczBRQTRrNmxqblhXV0gzd2d5RWNMazBneE8ybndFQzhvNDd4cEpxWGl1THJGMXN4OEQzWEEzb3FBSm56amFzYVNxVUpHbkdnUGxVbTBaN0huRDRJWmM9IiwibWFjIjoiZmE3YjdlZTg1ZjdiMmFlNDAzNmQxNzJmZDE3N2M3NmM4NjVkZmE3NDg1NmMzNGFjODgwYTI0NmNiMjdkMmZkYyIsInRhZyI6IiJ9; early-access=eyJpdiI6ImpoREtxRyswNXdqRmtwVHhuOVc5eWc9PSIsInZhbHVlIjoiZTFoWlNaQ2UwbG1NZG4rclFlVmprdmVFcms1aDJCSGprSElrSzNuOW5HOVJKUEtqYlErVGFWNW1BRlRmcEt0VTRGdFd5TzhNYndVbTlzdmpvWmk1djgyZld3MmtZQ01MY01iTXY4bVBjckE9IiwibWFjIjoiZGFmMmVkMGQ2ZGMzYjI0YmMwYjhhNDYzNjZlMzZhZDFiYmExMDMxMWY2MzliMGE3MTYyZmMyYjVhYmI3MzU4YSIsInRhZyI6IiJ9; __stripe_mid=75db7ff1-6dac-4014-8695-57b662927020649851; XSRF-TOKEN=eyJpdiI6InNtbkVHbWNISmZwMk1pdUsxOUdDcVE9PSIsInZhbHVlIjoiTEk1WHFqNUlid0R3cmRIMDZWNWlieWRONTZVSUtIV1AxdFdMbjdvRVhndmZ4cWZPNHJJcHAwYlNHQS9EMURpMlN3bXNKUDJOWUVVOFR0d1dxK08wYzFYRzdVTU1xQjFrTHJQa3p5VStoSXMzT2xYTGlnYmNISkpzM3prQXdyTGwiLCJtYWMiOiIyYjQ0YWRiNWM2NmZmYTJhNzVjYWE3MGU4M2ZhYmEzZTI0NWMyNGQyOWQwZTc3MTNmY2FmYmFiOTdlZGEzNjU2IiwidGFnIjoiIn0%3D; tinyurl_session=eyJpdiI6InJ6R1Y5T2JPZEYwWEVaNE41S2RtVGc9PSIsInZhbHVlIjoib2dKRFIvMi9PL3lmVzVqbVczTGpOUkV5NWx1YlNPdlhRT3E5VzBxVzU5eEUyYklZVWNIYjB0cW5BQ1h5R21YQVNvcU9HOUZKWkk5SStRWklXeDdmb2ViUXJvNS93eHJTM0hUR0xNeUcwcmVuNmh4TXp0bDJPb0xIajZub3JqZE0iLCJtYWMiOiJjYmY4MWVkZTU3YTBjZDhhYjk0MmM1MjQyZTQyYTAxZTBkNGM1ZWYyY2I5NGE0MDAxMGQ1ZTRlM2I1ZjNiZDhmIiwidGFnIjoiIn0%3D; __stripe_sid=9fc897b1-3c48-4bbf-a709-40b783d7ff454c9597';
$headers[] = 'Origin: https://tinyurl.com';
$headers[] = 'Referer: https://tinyurl.com/app';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'X-Xsrf-Token: eyJpdiI6InNtbkVHbWNISmZwMk1pdUsxOUdDcVE9PSIsInZhbHVlIjoiTEk1WHFqNUlid0R3cmRIMDZWNWlieWRONTZVSUtIV1AxdFdMbjdvRVhndmZ4cWZPNHJJcHAwYlNHQS9EMURpMlN3bXNKUDJOWUVVOFR0d1dxK08wYzFYRzdVTU1xQjFrTHJQa3p5VStoSXMzT2xYTGlnYmNISkpzM3prQXdyTGwiLCJtYWMiOiIyYjQ0YWRiNWM2NmZmYTJhNzVjYWE3MGU4M2ZhYmEzZTI0NWMyNGQyOWQwZTc3MTNmY2FmYmFiOTdlZGEzNjU2IiwidGFnIjoiIn0=';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json =  json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}