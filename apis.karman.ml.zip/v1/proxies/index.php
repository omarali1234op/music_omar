<?php
header('Content-Type: application/json');
if($_GET["type"]){
$type = $_GET["type"];
$virus1 = file_get_contents("https://api.proxyscrape.com/v2/?request=getproxies&protocol=$type&timeout=10000&country=all&ssl=all&anonymity=all");
$virus2 = file_get_contents("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/$type.txt");
$virus3 = file_get_contents("https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/$type.txt");
$virus4 = file_get_contents("https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/proxy.txt");
$virus5 = file_get_contents("https://www.proxy-list.download/api/v1/get?type=$type");
echo "$virus1";
echo "$virus2";
echo "$virus3";
echo "$virus4";
echo "$virus5";
}