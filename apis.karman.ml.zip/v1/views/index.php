<?php
header("Content-Type: application/json; charset=UTF-8");
$to = file_get_contents("https://telegram.software/");
preg_match_all('#<input type="hidden" name="_token" value="(.*?)">#',$to,$token);
$ch = curl_init();
$channel =$_GET["user"];
$get_token = $token[1][0];
curl_setopt($ch, CURLOPT_URL, 'https://telegram.software/make_views_order');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "_token=".$get_token."&test_mode=on&number-days=1&slct-day=-&slct-moth=-&slct-year=-&link-channel=@".$channel."&speed-hour=1800&views=10000");
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: telegram.software';
$headers[] = 'Pragma: no-cache';
$headers[] = 'Cache-Control: no-cache';
$headers[] = 'Sec-Ch-Ua: \" Not A;Brand\";v=\"99\", \"Chromium\";v=\"98\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Origin: https://telegram.software';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 10; ART-L29) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.128 Mobile Safari/537.36';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: navigate';
$headers[] = 'Sec-Fetch-User: ?1';
$headers[] = 'Sec-Fetch-Dest: document';
$headers[] = 'Referer: https://telegram.software/';
$headers[] = 'Accept-Language: ar-IQ,ar;q=0.9,en-IQ;q=0.8,en;q=0.7,es-IQ;q=0.6,es;q=0.5,en-US;q=0.4';
$headers[] = 'Cookie: _ym_uid=1662893453779649076; _ym_d=1662893453; _gid=GA1.2.1746122763.1665317761; _ym_isad=2; _ym_visorc=w; _ga=GA1.2.1782802451.1662893452; XSRF-TOKEN=eyJpdiI6IkFIeHFWY1RFWCsxa1B5S01QTEI4Smc9PSIsInZhbHVlIjoiN0d1NE9rbnp6WnBTQjlyd0puaDNQME1LSzQ0QUlJU2k0MXNoL3hDRUsycWU3SVU3eWZDOFVXV3piVHBjTXRyNjl6N01yZGlPajJSR2U1b0Y4UUZ4ckk1QVZ5bWVzeVE0b3BmMzVVSStzVzdwT3V5c0J4MnhvcmdPUllKQ1QvWTEiLCJtYWMiOiJhZGY3NDk2MmExZGRhNTUxZjQ2MTQ1M2Y1Mjc4ZWJmZjU0NGY2ZTI0NGU3YzUyOWJmMzFiZWVlMDYxNGFiNjk1In0%3D; telegramsoftware_session=eyJpdiI6IlMvMkRLQzJSRS9EYzRRSDJGaGdBWkE9PSIsInZhbHVlIjoid21KdFlkdWY2dmtGWDNkc3RYcWQydnQ2OVladDlDUFFuMkp6Sldsd2NseEJSYXRBVHJDMmozN1c4UjAzNWc1NHd5QjREYkN3VzVjZnMybHpucTR3OEJZSGhFejFjWjJWTmxvL2RBa1dVQzVhOEVqVW9Jd0V3TDhmYTh5VkhreWoiLCJtYWMiOiIzOWE3NzcxZWExNDdlN2I4YTQyZjA2MDU1MzA4ZDVhMjEzNzFmNDExMDJjNDk4NWI2YzJjM2UxMTA3NmE0YzVlIn0%3D; _ga_LDCYE0PVMB=GS1.1.1665317757.2.1.1665317809.8.0.0';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
preg_match_all('#<title>(.*?)</title>#',$result,$erro);
preg_match_all('#<title>(.*?)</title>#',$result,$nit);
preg_match_all('#<a href="https://telegram.software/views" class="w-full p-3 flex justify-center text-center items-center text-white rounded-lg" style="background: #27a6dd">(.*?)</a>#',$result,$succes);
$success = $succes[1][0];
$error = $erro[1][0];
$not = $nit[1][0];
if($result == "You already used demo" or $error == "Page Expired" or $not == "Just a moment..."){
echo "Error";
if($success == "New order"){
echo "Done";
}
}