<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["search"]){
$url = file_get_contents("https://shahed4u.rodeo/?s=".$_GET["search"]);
$_ex = explode('<div class="hvr">',$url);
for ($i=1; $i < count($_ex)-1; $i++){
$url = file_get_contents("https://shahed4u.rodeo/?s=".$_GET["search"]);
preg_match_all('#<a href="(.*?)" title="(.*?)"#',$url,$title);
preg_match_all('#<a href="(.*?)" class="image">#',$url,$link);
preg_match_all('#<img class="imgInit" data-image="(.*?)"#',$url,$img);
preg_match_all('#<span class="rate ti-star">(.*?)</span>#',$url,$rate);
$ww = $link[1][$i];
$json[] = [
'title'=>$title[2][$i],
'url'=>"$ww/watch/",
'image'=>$img[1][$i],
'rating'=>$rate[1][$i],
];
}
echo json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
if($_GET["url"]){
$url = file_get_contents($_GET["url"]);
preg_match_all('#<meta itemprop="name" content="(.*?)">#',$url,$title);
preg_match_all('#<link itemprop="thumbnailUrl" href="(.*?)">#',$url,$img);
preg_match_all('#<meta property="og:description" content="(.*?)" />#',$url,$description);
preg_match_all('#<input type="hidden" name="fserver" value="(.*?)">#',$url,$watch);
$array['title'] = $title[1][0];
$array['des'] = $description[1][0];
$array['photo'] = $img[1][0];
$array['watch'] = $watch[1][0];
$array['Dev'] = "VIRUS : @VR_LA";
echo json_encode($array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}