<?php
header("Content-Type: application/json");
if($_GET["name"]){
$url = file_get_contents("https://www.brandcrowd.com/maker/logos?text=".$_GET["name"]."&isFromRootPage=true#show-onboarding-modal");
$count = explode('</picture>',$url);
for($i=1;$i<count($count)-1;$i++){
preg_match_all('#srcset="(.*?),#',$url,$logo);
$logos = str_replace("amp;","",$logo[1][$i]);
$info[] = [
"logo"=>$logos,
];
}
echo json_encode($info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}