<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["username"]){
$user_agent = $_SERVER["HTTP_USER_AGENT"];
$api = file_get_contents("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=100&country=all");
$proxylist = explode("\n",$api);
$proxy = $proxylist[array_rand($proxylist)];
$ip = explode(":",$proxy)[0];
$port = explode(":",$proxy)[1];
$rand = substr(str_shuffle('AaBbCcDdEeFfGgHhIiGgKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789'),1,4);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://core.poprey.com/api/create_test_order_v2.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
'Host'=>'core.poprey.com',
'content-length'=>'100',
'Connection'=>'keep-alive',
'accept'=>'application/json, text/plain, */*',
'x-auth-token'=>'null',
'x-target-lang'=>'en',
'user-agent'=>$user_agent,
'x-identity-site'=>'poprey.com',
#'x-identity-token'=>'LO6RhMUnyVdYqYQ7Y3JyYMIvJ6YiW0Yz',
'content-type'=>'application/x-www-form-urlencoded',
'sec-gpc'=>'1',
'accept-language'=>'ar-AE,ar;q=0.8',
'origin'=>'https://poprey.com',
'sec-fetch-site'=>'same-site',
'sec-fetch-mode'=>'cors',
'sec-fetch-dest'=>'empty',
'referer'=>'https://poprey.com/instagram_followers',
'accept-encoding'=>'gzip, deflate, br',
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, "service=Followers&email=".$rand."@gmail.com&username=".$_GET["username"]."&system=Instagram&count=10&type=t1&csrf=");
if($proxylist != null){
curl_setopt($ch, CURLOPT_PROXY, "http://$ip"); 
curl_setopt($ch, CURLOPT_PROXYPORT, $port); 
}
$response = curl_exec($ch);
curl_close($ch);
$json = json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}