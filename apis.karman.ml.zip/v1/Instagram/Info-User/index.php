<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["username"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://storiesig.info/api/ig/profile/'.$_GET["username"]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: storiesig.info';
$headers[] = 'Accept: application/json, text/plain, */*';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Cookie: XSRF-TOKEN=eyJpdiI6IllDSzN2aEJPWGlmbkdBVjVucmt0Ymc9PSIsInZhbHVlIjoiZEU2cGY4TDQ4NnBscWdHTDFPXC9IWUNcL3pRU0RLaWJMelpncDNIMlwvUlp5TXRLWUhac0NVMmwzdkdvdk1LNURmMkNoeE1Qd2hmakVVZGtQcVo5Q20zVjVLc09BdDdYbXZtZHdCZDQ2QVRhXC9mZ05zRUNiXC81dzRjNzRzd0lrbm9uVCIsIm1hYyI6IjkwNmZkM2Q4MzE2ZjU2Y2ZlZWE2ZDA1NDQwZWFmMjliZTRhOWEwMWRkYWNhZjRmYzY2MmViNDUyOTEyNjg0ODMifQ%3D%3D; aig_session=eyJpdiI6InlKTXhPcDdxWkY5aXkwMWV6Y0xvUmc9PSIsInZhbHVlIjoiVTdyWWhZd0docG5Tb1lkWTBFYk5nOWwzaWMrcUJPemN0bGxGOE91dGp2K0FHaXR3N3RcL0pXT1FWT2g2Y3VHMWk0RGpUYjg4em4zcVJYYmdhVzhvMG1TbjJSMVZZeEZRQnVJV1ZlZXJKREZsQnI5T204dzFuV2NtWWVaOTRjTU84IiwibWFjIjoiMmYzZmM0YWZlNWYwNmVjNzAyZDNkYWM2NDk3M2Y4ZWMzOTg3ODE3NWIxZjU2M2VlODgwM2YzY2VjZDM2OGI5NSJ9; _ga=GA1.2.1451710083.1666436666; _gid=GA1.2.1478620221.1666436666; uid=fd9745b3c17856f8; clickAds=38';
$headers[] = 'Referer: https://storiesig.info/en/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
$headers[] = 'X-Token: null';
$headers[] = 'X-Xsrf-Token: eyJpdiI6IllDSzN2aEJPWGlmbkdBVjVucmt0Ymc9PSIsInZhbHVlIjoiZEU2cGY4TDQ4NnBscWdHTDFPXC9IWUNcL3pRU0RLaWJMelpncDNIMlwvUlp5TXRLWUhac0NVMmwzdkdvdk1LNURmMkNoeE1Qd2hmakVVZGtQcVo5Q20zVjVLc09BdDdYbXZtZHdCZDQ2QVRhXC9mZ05zRUNiXC81dzRjNzRzd0lrbm9uVCIsIm1hYyI6IjkwNmZkM2Q4MzE2ZjU2Y2ZlZWE2ZDA1NDQwZWFmMjliZTRhOWEwMWRkYWNhZjRmYzY2MmViNDUyOTEyNjg0ODMifQ==';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json = json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}else{
echo "enter user plz";
}