<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["url"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://offeo.com/download/wp-json/aio-dl/video-data/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "url=".$_GET["url"]."&token=7dde524e4316058fee7a03de459f9f036d18371968199974935d071b1afa1940");
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: offeo.com';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Cookie: pll_language=en; _ga=GA1.2.946339081.1665695801; _gid=GA1.2.1947930112.1665695801; _gat=1; XSRF-TOKEN=eyJpdiI6IklrY1hLMnNRR29VSnRkaFFpWTk1VHc9PSIsInZhbHVlIjoiT2h4UzZRTDVSWU9zN3Zwb2pcL1dOVlU5eks4RUc3cFd6RSsrMFNZV1ZsN0RGMVJCeG9la3JuNlZqUDVVU0IzVmxUOVE4dHY2Zk1ybmd6RHA3OUJ5VnIwTGp3T2NqNVVUbzQ3dXpJRkRrZGZpWnc0VlAyeVMwMWR1XC95V1dvSGp0NSIsIm1hYyI6ImI0MDI2YmI5ZTA5NjBhNjYxZWQ4YWU1ODQzMTQ5NTVkNTI5OGQ2YzFjNWYzYjgxMjRhOWNjYjFiZDI2YjBhN2UifQ%3D%3D; offeo_api_session=eyJpdiI6IkkwdEEwbGVXNnBiK3h4emJRUzNtK0E9PSIsInZhbHVlIjoiY0dhR2Rhb2FrV2ZmRHluQmtTcUtsRURXbjUyRk5ZSjNFTUFTS1g0UGNKWG1sWnpRbWRGZEU4b2JNcHduSGk3eGkwY01cL2N4RFFSbXE1a1VVeHhsU1FiKzExbWNqcFlMZ1R0QWg0MzZaeDliXC9TbmtaUVdYQkQwZEdPN0FLdlVqNyIsIm1hYyI6ImQ2NTM4ZDZmOGVhMjNhM2QwY2FkZTEyMzg5YjI0Y2Q0NDhhNzhmNzdkMzBjODE3ZDZhNWNhYzdhY2I2ZGYyYjEifQ%3D%3D; PHPSESSID=oqp1e5k70vs48jjeqkb25sjbvt';
$headers[] = 'Origin: https://offeo.com';
$headers[] = 'Referer: https://offeo.com/download/pinterest-video-downloader/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json =  json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}