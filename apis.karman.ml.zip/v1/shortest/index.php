<?php
header("Content-Type: application/json; charset=UTF-8");
if($_GET["url"]){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://shorte.st/shortener/shorten');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "url=".$_GET["url"]);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Authority: shorte.st';
$headers[] = 'Accept: application/json, text/javascript';
$headers[] = 'Accept-Language: ar-AE,ar;q=0.9,en-GB;q=0.8,en;q=0.7,en-US;q=0.6';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Cookie: PHPSESSID=9u4gpm5f253tp37psmtih94dp4; shst-visited=1; hl=en; cookies-enable=1; __atuvc=1%7C41; __atuvs=6348109acadd15a6000; _ga=GA1.2.764306409.1665667227; _gid=GA1.2.857367662.1665667227; _gat=1';
$headers[] = 'Origin: https://shorte.st';
$headers[] = 'Referer: https://shorte.st/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"105\", \"Not)A;Brand\";v=\"8\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 12; SM-A225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36';
$headers[] = 'X-Requested-With: XMLHttpRequest';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);
curl_close($ch);
$json =  json_decode($response);
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}