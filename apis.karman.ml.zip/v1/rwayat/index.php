<?php
if($_GET["name"]){
$name = $_GET["name"];
$Rwayat = "https://www.kotobati.com/رواية-$name-pdf";
$ch = curl_init();
$header = array(
'referer: https://www.kotobati.com/',
'user-agent: Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.99 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_URL, $Rwayat );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt($ch, CURLOPT_HTTPHEADER, $header );
$result = curl_exec( $ch );
curl_close($ch);
/* =========== */
#echo $result;
$title = '#<h2 class="img-title ">(.*?)</h2>#';
preg_match_all($title,$result,$title);
/* =========== */
$description = '#<strong>(.*?)</strong>#';
preg_match_all($description,$result,$description);
/* =========== */
$photo = '#data-src="(.*?)"#';
preg_match_all($photo,$result,$photo);
/* =========== */
$linkk = '#<a target="_blank" href="(.*?)" class="btn btn-icon btn-1 download">تحميل الكتاب</a>#';
preg_match_all($linkk,$result,$linkk);
/* =========== */
$link = $linkk[1][0];
$img = $photo[1][0];
/* =========== */
$array["title"] = $title[1][0];
$array["description"] = $description[1][0];
$array["photo"] = "https://www.kotobati.com$img";
$array["Download"] = "https://www.kotobati.com$link";
$array["Dev"] = "VIRUS : @VR_LA";
echo json_encode($array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}