<?php
header("Content-Type: application/json; charset=UTF-8");
$url = file_get_contents("https://www.fakexy.com/");
preg_match_all('#<td>(.*?)</td>#',$url,$information);
$info[] = [
"Full Name"=>$information[1][17],
"Gender"=>$information[1][19],
"Birthday"=>$information[1][21],
"Social Security Number"=>$information[1][23],
"Country"=>$information[1][11],
"Street"=>$information[1][1],
"City/Town"=>$information[1][3],
"State/Province/Region"=>$information[1][5],
"Zip/Postal Code"=>$information[1][7],
"Phone Number"=>$information[1][9],
];
$json["result"] = $info;
echo json_encode($json,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
