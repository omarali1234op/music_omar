<?php
header('Content-Type: application/json');
$botss = json_decode(file_get_contents("https://api.telegram.org/bot".$_GET["token"]."/getme"),1);
$id = $botss["result"]["id"];
mkdir("token/$id");
if($_GET["token"] and $botss["ok"] == true){
file_put_contents("token/$id/token.txt", $_GET["token"]);
$name = $_GET['search'];
$imdb = file_get_contents("http://www.omdbapi.com/?t=".urlencode($name)."&apikey=9b24e033");
echo $imdb;
}