<!DOCTYPE html>
<html lang="en">
<head>
<title>️️️️️️️️𝙑 𝙄 𝙍 𝙐 𝙎</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/open-iconic-bootstrap.min.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/animate.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/owl.carousel.min.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/magnific-popup.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/aos.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/ionicons.min.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/flaticon.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/icomoon.css">
<link rel="stylesheet" href="https://dev-api-botat.pantheonsite.io/fun/css/style.css">
</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light site-navbar-target" id="ftco-navbar">
<div class="container">
<a class="nav-link" style="color: white;" href="index.php">Mohamed</a>
<button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
<span class="oi oi-menu"></span> Menu
</button>
<div class="collapse navbar-collapse" id="ftco-nav">
<ul class="navbar-nav nav ml-auto">
<li class="nav-item"><a href="#home-section" class="nav-link" style="color: white"><span>Home</span></a></li>
<li class="nav-item"><a href="#about-section" class="nav-link" style="color: white"><span>About</span></a></li>
<li class="nav-item"><a href="#skills-section" class="nav-link" style="color: white"><span>Skills</span></a></li>
<li class="nav-item"><a href="#contact-section" class="nav-link" style="color: white"><span>Contact</span></a></li>
</ul>
</div>
</div>
</nav>
<section id="home-section" style="background-color: #000000;">
<div class="home-slider  owl-carousel">
<div class="slider-item ">
<div class="overlay"></div>
<div class="container">
<div class="row d-md-flex no-gutters slider-text align-items-end justify-content-end" data-scrollax-parent="true">
<div class="one-third order-md-last">
<div class="overlay"></div>
</div>
<div class="one-forth d-flex  align-items-center ftco-animate" data-scrollax=" properties: { translateY: '60%' }">
<div class="text">
<h1 style="color: white;">Hello, I'm Mohamed</h1>
<h3 style="color: white;">A am from Egypt  and I am 17 years old</h3>
<br>

</ul>
</div>
</div>
</div>
</div>
<div class="carousel-caption d-none d-md-block">
<a class="btn btn-link btn-circle" style="color: white" role="button" href="#about-section"><i class="icon-long-arrow-down animated"></i></a>
</div>
</div>
<div class="slider-item">
<div class="overlay"></div>
<div class="container">
<div class="row d-flex no-gutters slider-text align-items-end justify-content-end" data-scrollax-parent="true">
<div class="one-third order-md-last img">
<div class="overlay"></div>
</div>
<div class="one-forth d-flex align-items-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
<div class="text">
<h1 class="mb-2 mt-2" style="color: white;">What am I ?</h1>
<h2 style="color: white;">I am a person who loves programming a lot and I hope to become a developer in the future ❤️
</h2>
<br><br>

</ul>
</div>
</div>
</div>
</div>
<div class="carousel-caption d-none d-md-block">
<a class="btn btn-link btn-circle" style="color: white" role="button" href="#about-section"><i class="icon-long-arrow-down animated"></i></a>
</div>
</div>
</div>
</section>
<section class="ftco-about ftco-counter img ftco-section" id="about-section">
<div class="container">
<div class="row d-flex">
<div class="col-md-6 col-lg-7 pl-lg-5 py-5">
<div class="row justify-content-start pb-3">
<div class="col-md-12 heading-section ftco-animate">
<span class="subheading">Welcome</span>
<h2 class="mb-4" style="font-size: 34px; text-transform: capitalize;">About Me</h2>
<p>My name is Mohamed, am from Egypt and I am 17 years old, I am a person who loves programming a lot and I hope to become a developer in the future ❤️<br></p>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="ftco-section bg-light" id="skills-section">
<div class="container">
<div class="row justify-content-center pb-5">
<div class="col-md-12 heading-section text-center ftco-animate">
<span class="subheading">Skills</span>
<h2 class="mb-4">My Skills</h2>
</div>
</div>
<div class="row">
<div class="col-md-6 animate-box">
<div class="progress-wrap ftco-animate">
<h3>LUA5</h3>
<div class="progress">
<div class="progress-bar color-1" role="progressbar" aria-valuenow="87" aria-valuemin="0" aria-valuemax="100" style="width:44%">
<span>19%</span>
</div>
</div>
</div>
</div>
<div class="col-md-6 animate-box">
<div class="progress-wrap ftco-animate">
<h3>java</h3>
<div class="progress">
<div class="progress-bar color-1" role="progressbar" aria-valuenow="87" aria-valuemin="0" aria-valuemax="100" style="width:20%">
<span>5%</span>
</div>
</div>
</div>
</div>
<div class="col-md-6 animate-box">
<div class="progress-wrap ftco-animate">
<h3>PHP7</h3>
<div class="progress">
<div class="progress-bar color-1" role="progressbar" aria-valuenow="87" aria-valuemin="0" aria-valuemax="100" style="width:48%">
<span>23%</span>
</div>
</div>
</div>
</div>
<div class="col-md-6 animate-box">
<div class="progress-wrap ftco-animate">
<h3>PYTHON3</h3>
<div class="progress">
<div class="progress-bar color-2" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:36%">
<span>11%</span>
</div>
</div>
</div>
</div>
<div class="col-md-6 animate-box">
<div class="progress-wrap ftco-animate">
<h3>HTML5</h3>
<div class="progress">
<div class="progress-bar color-3" role="progressbar" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100" style="width:35%">
<span>10%</span>
</div>
</div>
</div>
</div>
</section>
<footer class="ftco-footer ftco-section" id="contact-section">
<div class="container">
<div class="row mb-5">
<div class="col-md">
<div class="ftco-footer-widget mb-4">
<h2 class="ftco-heading-2">Follow me </h2>

</ul>
</div>
</div>
<div class="col-md">
<div class="ftco-footer-widget mb-4">
<h2 class="ftco-heading-2">Contact Me</h2>
<div class="block-23 mb-3">
<ul>
<li><span class="icon icon-map-marker"></span>
<span class="text">Egypt Cairo</span></li>
<li><a href="https://t.me/VR_LA"><span class="icon icon-telegram"></span>
<span class="text">@VR_LA</span></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</footer>

<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" /></svg></div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery-migrate-3.0.1.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/popper.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/bootstrap.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery.easing.1.3.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery.waypoints.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery.stellar.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/owl.carousel.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery.magnific-popup.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/aos.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/jquery.animateNumber.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/scrollax.min.js"></script>
<script src="https://dev-api-botat.pantheonsite.io/fun/js/main.js"></script>
</body>
</html>
