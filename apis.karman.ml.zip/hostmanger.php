<?php
ob_start();
$info = file_get_contents('infomanger.php');
$getinfomanger = explode("\n",$info);
$token = $getinfomanger[1];
$API_url = 'https://api.telegram.org/bot'.$token;
define('API_KEY',$API_url);
echo file_get_contents(API_KEY."/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$url = API_KEY."/".$method;
$ch = curl_init();
 curl_setopt($ch,CURLOPT_URL,$url);
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
 curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
if(curl_error($ch)){
 var_dump(curl_error($ch));
}else{
 return json_decode($res);
}
}
$update = json_decode(file_get_contents('php://input'));
$filesjson = json_decode(file_get_contents('fileshost.json'),1);
$filename = str_replace('/','',$_SERVER['SCRIPT_NAME']);
$adminsfile1 = file_get_contents("admins1.txt");
$adminsfile2 = file_get_contents("admins2.txt");
$message = $update->message;
$name = $message->from->first_name;
$id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$autoadmin = $getinfomanger[2];
$admins1 = explode("\n",$adminsfile1);
$admins2 = explode("\n",$adminsfile2);
$adminsnem1 = count($admins1)-1;
$adminsnem2 = count($admins2)-1;
if(isset($update->callback_query)){ 
$id = $update->callback_query->message->from->id; 
$chat_id = $update->callback_query->message->chat->id; 
$message_id = $update->callback_query->message->message_id; 
$data= $update->callback_query->data; 
}
function save($array){
 file_put_contents('fileshost.json', json_encode($array));
}
function clear($array){
foreach($array as $key => $val){
$array[$key] = null;
}
return $array;
}

function Zip($BackupZip1, $BackupZip2){
$BackupZip4 = realpath($BackupZip1);
$BackupZip = new ZipArchive();
$BackupZip->open($BackupZip2, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$BackupZip3 = new RecursiveIteratorIterator(
new RecursiveDirectoryIterator($BackupZip4),
RecursiveIteratorIterator::LEAVES_ONLY);
foreach($BackupZip3 as $BackupZip5 => $BackupZip6){
if(!$BackupZip6->isDir()){
$BackupZip7 = $BackupZip6->getRealPath();
$BackupZip8 = substr($BackupZip7, strlen($BackupZip4) + 1);
$BackupZip->addFile($BackupZip7, $BackupZip8);
}}
$BackupZip->close();
}

function Size($BackupZip9, $BackupZip10 = 2){
$BackupZip11=array(' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
$BackupZip12=floor((strlen($BackupZip9) - 1) / 3);
return sprintf("%.{$BackupZip10}f", $BackupZip9 / pow(1024, $BackupZip12)) . @$BackupZip11[$BackupZip12];
}

// عرض الملفات
$dnam = 1;
$fnam = 1;
$dirs = "- المجلدات 📂؛\n";
$all = count(scandir(__DIR__) ) - 2;
$files = "- الملفات 📃'\n";
foreach(scandir(__DIR__) as $file){
if($file == '.' || $file == '..'){ continue;}
if(is_dir($file)){
$dirs .= "*$dnam-*`$file`\n";
$dnam+=1;
}
if(is_file($file)){
$files .= "*$fnam-*`$file`\n";
$fnam+=1;
}
}


if($message and !in_array($chat_id,$admins2) and !in_array($chat_id,$admins1) and $chat_id != $autoadmin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
عذرا $name
انت لست ادمن في البوت
لايمكنك التحكم به
",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الــمــطــور','url'=>'t.me/VR_LA']],
]])
]);
}

if(in_array($chat_id,$admins2) || in_array($chat_id,$admins1) || $chat_id == $autoadmin){

// بدء ادمن اساسي
if($text == "/start" and $chat_id == $autoadmin){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
حسنا عزيزي $name
بوت تحكم الاستضافه مطور الملف @VR_LA
موقعك ادمن الاساسي
اليك كيبورد الاوامر انلاين في الاسفل
",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$msgid,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"مـوقـعـك"],['text'=>"قـائـمـه الاوامـر"]],
[['text'=>"الـغـاء الامـر"]],
]])
]);
}

// بدء ادمن 1
if($text == "/start" and in_array($chat_id,$admins1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
حسنا عزيزي $name
بوت تحكم الاستضافه مطور الملف @VR_LA
موقعك ادمن 1
اليك كيبورد الاوامر انلاين في الاسفل
",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$msgid,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"مـوقـعـك"],['text'=>"قـائـمـه الاوامـر"]],
[['text'=>"الـغـاء الامـر"]],
]])
]);
}

// بدء ادمن 2
if($text == "/start" and in_array($chat_id,$admins2)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
حسنا عزيزي $name
بوت تحكم الاستضافه مطور الملف @VR_LA
موقعك ادمن 2
اليك كيبورد الاوامر انلاين في الاسفل
",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$msgid,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"مـوقـعـك"],['text'=>"قـائـمـه الاوامـر"]],
[['text'=>"الـغـاء الامـر"]],
]])
]);
}

// موقع ادمن اساسي
if($text == "مـوقـعـك" and $chat_id == $autoadmin){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
حسنا $name
موقعك الان ادمن اساسي
",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$msgid,
]);
}

// موقع ادمن 1
if($text == "مـوقـعـك" and in_array($chat_id,$admins1)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
حسنا $name
موقعك الان ادمن 1
",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$msgid,
]);
}

// موقع ادمن 2
if($text == "مـوقـعـك" and in_array($chat_id,$admins2)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
حسنا $name
موقعك الان ادمن 2
",
'parse_mode'=>'markdown',
'reply_to_message_id'=>$msgid,
]);
}

// الغاء
if($text == 'الغاء' or $text == 'الـغـاء الامـر'){
bot("sendmessage",[
"chat_id"=>$chat_id,
"text"=>"تم الغاء الامر",
'parse_mode'=>"markdown",
'reply_to_message_id'=>$message->message_id,
]);
save(clear($filesjson));
return false;
}

/* بدء الاوامر */

#الادمنيه 1#

// اضف ادمن 1
if($data == "addadmin1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
ارسل ايدي الشخص لرفعه ادمن 1 في البوت
",
'parse_mode'=>"markdown",
]);
$filesjson[$chat_id.';'.'admin1'] = 'add';
save($filesjson);
exit;
}

// حفظ ايدي الادمن 1//
if($filesjson[$chat_id.';'.'admin1'] == 'add'){ 
$url = json_decode(file_get_contents($API_url.'/getchat?chat_id='.$text));
$ok = $url->ok;
$addid = $url->result->id;
$addname = $url->result->first_name;
$markaddname = "[$addname](tg://user?id=$addid)";
if($text == $autoadmin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
هذا [الادمن الاساسي](tg://user?id=$text) لا يمكنك رفعه ادمن 1
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
return false;
}
if($addid != $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
لم يقم العضو بعمل /start في البوت
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
return false;
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم رفع $markaddname ادمن 1 في البوت
",
'parse_mode'=>'markdown',
]);
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"
قام [$name](tg://user?id=$id) برفعك ادمن 1 في البوت
/start
",
'parse_mode'=>"markdown",
]);
$deladmin2 = str_replace($text."\n",'',$adminsfile2);
file_put_contents("admins2.txt",$deladmin2);
$deladmin1 = str_replace($text."\n",'',$adminsfile1);
file_put_contents("admins1.txt",$deladmin1);
file_put_contents("admins1.txt","$text\n",FILE_APPEND);
save(clear($filesjson));
}


// حذف ادمن 1
if($data == "deladmin1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
ارسل ايدي الشخص لي تنزيله من الادمن
",
'parse_mode'=>"markdown",
]);
$filesjson[$chat_id.';'.'admin1'] = 'del';
save($filesjson);
exit;
}

// حذف ايدي الادمن 1//
if($filesjson[$chat_id.';'.'admin1'] == 'del'){
$url = json_decode(file_get_contents($API_url.'/getchat?chat_id='.$text));
$ok = $url->ok;
$addid = $url->result->id;
$addname = $url->result->first_name;
$markaddname = "[$addname](tg://user?id=$addid)";
if($text == $autoadmin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
هذا [الادمن الاساسي](tg://user?id=$text) لا يمكنك تنزيله ادمن 1
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
return false;
}
if($text == $id){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
لايمكنك تنزيل نفسك من الادمن
",
'parse_mode'=>'markdown'
]);
save(clear($filesjson));
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم تنزيل $markaddname ادمن من البوت
",
'parse_mode'=>'markdown'
]);
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"
قام [$name](tg://user?id=$id) بتنزيلك ادمن 1 من البوت
",
'parse_mode' =>"markdown",
]);
$deladmin1 = str_replace($text."\n",'',$adminsfile1);
file_put_contents("admins1.txt",$deladmin1);
save(clear($filesjson));
}
}

// عرض الادمنيه
if($data == "admins1"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
عدد الادمنيه $adminsnem1
$adminsfile1
",
'parse_mode'=>"markdown",
]);
}

// حذف الادمنيه
if($data == "deladmins1"){
unlink('admins1.txt');
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
تم حذف قائمه الادمن في البوت
",
'parse_mode'=>"markdown",
]);
}


#الادمنيه 2#

// اضف ادمن 2
if($data == "addadmin2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
ارسل ايدي الشخص لرفعه ادمن في البوت
",
'parse_mode'=>"markdown",
]);
$filesjson[$chat_id.';'.'admin2'] = 'add';
save($filesjson);
exit;
}

// حفظ ايدي الادمن 2//
if($filesjson[$chat_id.';'.'admin2'] == 'add'){
$url = json_decode(file_get_contents($API_url.'/getchat?chat_id='.$text));
$ok = $url->ok;
$addid = $url->result->id;
$addname = $url->result->first_name;
$markaddname = "[$addname](tg://user?id=$addid)";
if($text == $autoadmin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
هذا [الادمن الاساسي](tg://user?id=$text) لا يمكنك رفعه ادمن 2
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
return false;
}
if($addid != $text){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
لم يقم العضو بعمل /start في البوت
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
return false;
}
if(in_array($text,$admins1)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
$markaddname بالفعل ادمن 1
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم رفع $markaddname ادمن 2 في البوت
",
'parse_mode'=>'markdown',
]);
bot('sendMessage',[
'chat_id'=>$addid,
'text'=>"
قام [$name](tg://user?id=$id) برفعك ادمن في البوت
/start
",
'parse_mode'=>"markdown",
]);
$deladmin2 = str_replace($text."\n",'',$adminsfile2);
file_put_contents("admins2.txt",$deladmin2);
file_put_contents("admins2.txt","$text\n",FILE_APPEND);
save(clear($filesjson));
}
}


// حذف ادمن 2
if($data == "deladmin2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
ارسل ايدي الشخص لي تنزيله من الادمن
",
'parse_mode'=>"markdown",
]);
$filesjson[$chat_id.';'.'admin2'] = 'del';
save($filesjson);
exit;
}

// حذف ايدي الادمن 2//
if($filesjson[$chat_id.';'.'admin2'] == 'del'){
$url = json_decode(file_get_contents($API_url.'/getchat?chat_id='.$text));
$ok = $url->ok;
$addid = $url->result->id;
$addname = $url->result->first_name;
$markaddname = "[$addname](tg://user?id=$addid)";
if($text == $autoadmin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
هذا [الادمن الاساسي](tg://user?id=$text) لا يمكنك تنزيله ادمن 2
",
'parse_mode'=>'markdown',
]);
save(clear($filesjson));
return false;
}
if($text == $id){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
لايمكنك تنزيل نفسك من الادمن
",
'parse_mode'=>'markdown'
]);
save(clear($filesjson));
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم تنزيل $markaddname ادمن من البوت
",
'parse_mode'=>'markdown'
]);
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"
قام [$name](tg://user?id=$id) بتنزيلك ادمن من البوت
",
'parse_mode' =>"markdown",
]);
$deladmin2 = str_replace($text."\n",'',$adminsfile2);
file_put_contents("admins2.txt",$deladmin2);
save(clear($filesjson));
}
}

// عرض الادمنيه 2
if($data == "admins2"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
عدد الادمنيه $adminsnem2
$adminsfile2
",
'parse_mode'=>"markdown",
]);
}

// حذف الادمنيه 2
if($data == "deladmins2"){
unlink('admins2.txt');
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
تم حذف قائمه الادمن في البوت
",
'parse_mode'=>"markdown",
]);
}

#الويب هوك#

// عمل ويب هوك
if($data == 'webhookon'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'
قم بي ارسال رابط الملف الان
'.$dirs.'
----------
'.$files,
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'webhook'] = 'on';
save($filesjson);
exit;
}

// حفظ الرابط //
if($filesjson[$chat_id.';'.'webhook'] == 'on'){ 
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم حفظ الرابط ارسل توكن البوت الان
",
'parse_mode'=>'markdown',
]);
file_put_contents('files2.json', $text);
$filesjson[$chat_id.';'.'webhook'] = 'on2';
save($filesjson);
exit;
}

// حفظ التوكن + عمل الويب هوك //
if($filesjson[$chat_id.';'.'webhook'] == 'on2'){
$webhookurl = "https://api.telegram.org/bot".$text."/setwebhook?url=".file_get_contents('files2.json');
$infos = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$usernamebot = $infos->result->username;
$namebot = $infos->result->first_name;
if($usernamebot){
bot('sendMessage',[
'reply_to_message_id'=>$message->message_id,
'chat_id'=>$chat_id,
'text'=>"
تم عمل ويب هوك الرابط 👇
$webhookurl
",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>$namebot,'url'=>'t.me/'.$usernamebot.'?start']],
]])
]);
file_get_contents($webhookurl);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"• التوكن غير صحيح 📛"
]);
}
save(clear($filesjson));
}

// حذف ويب هوك
if($data == 'webhookdel'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'
ارسل توكن البوت
'
]);
$filesjson[$chat_id.';'.'webhook'] = 'del';
save($filesjson);
exit;
}

// تم حذف الويب هوك //
if($filesjson[$chat_id.';'.'webhook'] == 'del'){
$infos = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$usernamebot = $infos->result->username;
$namebot = $infos->result->first_name;
if($usernamebot){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم حذف الويب هوك
",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>$namebot,'url'=>'t.me/'.$usernamebot.'?start']],
]])
]);
file_get_contents("https://api.telegram.org/bot".$text."/deletewebhook");
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"• التوكن غير صحيح 📛"
]);
}
save(clear($filesjson));
}
// جلب معلومات التوكن
if($data == 'webhookinfo'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'
ارسل توكن البوت
'
]);
$filesjson[$chat_id.';'.'webhook'] = 'info';
save($filesjson);
exit;
}

// معلومات التوكن
if($filesjson[$chat_id.';'.'webhook'] == 'info'){
$info1 = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$info2 = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getwebhookinfo"));
$namebot = $info1->result->first_name;
$usernamebot = $info1->result->username;
$idbot = $info1->result->id;
$webhookbot = $info2->result->url;
$updatebot = $info2->result->pending_update_count;
if($usernamebot){
bot('sendMessage',[
'reply_to_message_id'=>$message->message_id,
'chat_id'=>$chat_id,
'text'=>"
اسم البوت
- $namebot
معرف البوت
- @$usernamebot
ايدي البوت
- $idbot
رابط الويب هوك
- $webhookbot
عدد الابديت
- $updatebot
",
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>$namebot,'url'=>'t.me/'.$usernamebot.'?start']],
]])
]);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"• التوكن غير صحيح 📛"
]);
}
save(clear($filesjson));
}

// معلومات الاستضافه
if($data == 'infoftp'){
$info = json_decode(file_get_contents('https://apis.clouduz.ru/ipinfo.php'));
$ip = $info->ip; // الايبي
$country_emoji = $info->country_emoji; // الهوست
$city_name = $info->city_name; // المدينه
$region_name = $info->region_name; // المحافظه
$country_name = $info->country_name; // الدوله
$calling_code = $info->calling_code; // المنطقه الزمنيه
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
الايبي
$ip
علم الدوله
$country_emoji
المدينه
$city_name
المحافظه
$region_name
الدوله
$country_name
كود الدوله
$calling_code
",
'parse_mode'=>"markdown",
]); 
}

// اصدار الاستضافه
if($data == 'Version'){
$ver = phpversion();  
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
اصدار الاستضافه
<code>$ver</code>
",
'parse_mode'=>"HTML",
]); 
}

// جلب دومين الاستضافه
if($data == 'sendhost'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
الدومين
`".$_SERVER['SERVER_NAME']."`
https://".$_SERVER['SERVER_NAME']."
",
'parse_mode'=>'markdown'
]);
}
if($data == 'upload'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'- قم بأرسال الملف الان'
]);
$filesjson[$chat_id.';'.'mode'] = 'upload';
save($filesjson);
exit;
}


if($data == 'downloadfile'){ 
bot('editMessageText',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message_id, 
'text'=>'- قم بأرسال اسم الملف ليتم تحميله،
'.$dirs.'
----------
'.$files,
'parse_mode'=>'markdown',
]); 
$filesjson[$chat_id.';'.'mode'] = 'downloadfile'; 
save($filesjson); 
exit; 
 }
 
 if($filesjson[$chat_id.';'.'mode'] == 'downloadfile'){
if(is_file($text)){ 
 bot('senddocument',[
 'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
 'document'=>new CURLFile("$text"),
 ]);save(clear($filesjson));
} else { 
bot('sendMessage',[ 
 'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id, 
 'text'=>"- لا يوجد ملف بهذا الاسم ، حدث خطأ 🚫؛ *$text*", 
 'parse_mode'=>'MarkDown', 
]); 
save(clear($filesjson));
} 
 } 

if($data == 'backup'){ 
bot('editMessageText',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message_id, 
'text'=>'- جاري ارسال نسخه من الاستضافه ،',
'parse_mode'=>'markdown',
]); 
Zip("",$_SERVER['SERVER_NAME'].".zip");
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'caption'=>"حجم الملف ".Size(filesize($_SERVER['SERVER_NAME'].".zip")),
'reply_to_message_id'=>$message->message_id,
 'document'=>new CURLFile($_SERVER['SERVER_NAME'].".zip"),
 ]);
 unlink($_SERVER['SERVER_NAME'].".zip");
}


if($data == 'downloadfolders'){ 
bot('editMessageText',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message_id, 
'text'=>'- قم بأرسال اسم المجلد ليتم تحميله،
'.$dirs.'
----------
'.$files,
'parse_mode'=>'markdown',
]); 
$filesjson[$chat_id.';'.'mode'] = 'downloadfolders'; 
save($filesjson); 
exit; 
 }
 
 if($filesjson[$chat_id.';'.'mode'] == 'downloadfolders'){
if(is_dir($text)){ 
Zip("$text","$text.zip");
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'caption'=>"حجم الملف ".Size(filesize("$text.zip")),
'reply_to_message_id'=>$message->message_id,
 'document'=>new CURLFile("$text.zip"),
 ]);
 unlink("$text.zip");
 save(clear($filesjson));
} else { 
bot('sendMessage',[ 
 'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id, 
 'text'=>"- لا يوجد مجلد بهذا الاسم ، حدث خطأ 🚫؛ *$text*", 
 'parse_mode'=>'MarkDown', 
]); 
save(clear($filesjson));
} 
 } 

if($data == 'show'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"• العدد الكلي ، $all\n\n$dirs\n----------\n$files",
'parse_mode'=>'markdown'
]);
}

if($data == 'webhookfileup'){ 
bot('editMessageText',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message_id, 
'text'=>'- قم بأرسال توكن البوت،'
]); 
$filesjson[$chat_id.';'.'mode'] = 'webhookfileup'; 
save($filesjson); 
exit; 
 }
 
if($filesjson[$chat_id.';'.'mode'] == 'webhookfileup'){
$webhookurl = "https://api.telegram.org/bot".$text."/setwebhook?url=".file_get_contents('files2.json');
$infos = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getme"));
$usernamebot = $infos->result->username;
$namebot = $infos->result->first_name;
if($usernamebot){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
تم عمل ويب هوك الرابط 👇
$webhookurl
",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>$namebot,'url'=>'t.me/'.$usernamebot]],
]])
]);
file_get_contents($webhookurl);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"• التوكن غير صحيح 📛"
]);
}
}


if($data == 'showurl'){ 
bot('editMessageText',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message_id, 
'text'=>'- قم بأرسال اسم الملف،
'.$dirs.'
----------
'.$files,
'parse_mode'=>'MarkDown',
]); 
$filesjson[$chat_id.';'.'mode'] = 'showurl'; 
save($filesjson); 
exit; 
 }

if($filesjson[$chat_id.';'.'mode'] == 'showurl'){
if(is_file($text)){
$urlfile = "https://".$_SERVER['SERVER_NAME']."/$text";
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"
رابط *$text*
$urlfile
",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>'اضغط لي عمل ويب هوك','callback_data'=>'webhookfileup']],
]])
]);
}else{
bot('sendMessage',[ 
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id, 
'text'=>"- لا يوجد ملف بهذا الاسم ، حدث خطأ 🚫؛ *$text*", 
'parse_mode'=>'MarkDown', 
]); 
}
save(clear($filesjson));
file_put_contents($urlfile);
file_put_contents('files2.json', $urlfile);
}


if($data == 'showDir'){
bot('editMessageText',[ 
'chat_id'=>$chat_id, 
'message_id'=>$message_id, 
'text'=>'- قم بأرسال اسم المجلد،
'.$dirs,
'parse_mode'=>'MarkDown',
]); 
$filesjson[$chat_id.';'.'mode'] = 'showDir'; 
save($filesjson); 
exit; 
 }

if($data == 'delete'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'- قم بأرسال اسم الملف ،
'.$dirs.'
----------
'.$files,
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'mode'] = 'delete';
save($filesjson);
exit;
}
if($data == 'eDir' or $data == 'eFile'){
if($data == 'eDir'){
$d = 'المجلد';
} else {
$d = 'الملف';
}
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"- قم بأرسال اسم $d القديم
".$dirs."
----------
".$files,
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'mode'] = 'old';
save($filesjson);
exit;
}
if($filesjson[$chat_id.';'.'mode'] == 'old'){
if(is_file($text) or is_dir($text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>'✅┇ تم الحفظ الان ارسل الاسم الجديد ',
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'mode'] = 'rename';
$filesjson[$chat_id.';'.'old'] = $text;
save($filesjson);
exit;
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- لا يوجد ملف او مجلد بهذا الاسم ، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
}
if($filesjson[$chat_id.';'.'mode'] == 'rename'){
if(rename($filesjson[$chat_id.';'.'old'], $text)){
$urlfile = "https://".$_SERVER['SERVER_NAME']."/$text";
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- تم التغيير بنجاح بنجاح ✅؛ من *".$filesjson[$chat_id.';'.'old']."* الى *$text*
الرابط الجديد : $urlfile",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>'اضغط لي عمل ويب هوك','callback_data'=>'webhookfileup']],
]])
]);
file_put_contents($urlfile);
file_put_contents('files2.json', $urlfile);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- لم يتم تغيير الاسم، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
save(clear($filesjson));
}
if($data == 'uploadD'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'- قم بأرسال اسم المجلد ، '
]);
$filesjson[$chat_id.';'.'mode'] = 'uploadD';
save($filesjson);
exit;
}
if($data == 'deleteD'){
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>'- قم بأرسال اسم المجلد ، 
'.$dirs,
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'mode'] = 'deleteD';
save($filesjson);
exit;
}
if($filesjson[$chat_id.';'.'mode'] == 'deleteD'){
if(is_dir($text)){
$sc = scandir($text);
foreach($sc as $file){
if($file == '.' or $file == '..'){continue;}
if(is_file($text.'/'.$file)){
unlink($text.'/'.$file);
} elseif(is_dir($text.'/'.$file)){
foreach(scandir($text.'/'.$file) as $f1){
if($f1 == '.' or $f1 == '..'){continue;}
if(is_file($text.'/'.$file.'/'.$f1)){
unlink($text.'/'.$file.'/'.$f1);
} elseif(is_dir($text.'/'.$file.'/'.$f1)){
foreach(scandir($text.'/'.$file.'/'.$f1) as $f2){
if($f2 == '.' or $f2 == '..'){continue;}
if(is_file($text.'/'.$file.'/'.$f1.'/'.$f2)){
unlink($text.'/'.$file.'/'.$f1.'/'.$f2);
}
}
}
}
}
}
unlink($text);
rmdir($text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- تم الحذف بنجاح ✅؛ *$text* ",
'parse_mode'=>'MarkDown',
]);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"-المجلد غير موجود ، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
save(clear($filesjson));
}
if($filesjson[$chat_id.';'.'mode'] == 'uploadD'){
if(mkdir($text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- تم الانشاء بنجاح ✅؛ *$text* ",
'parse_mode'=>'MarkDown',
]);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- لم يتم انشاء المجلد ، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
save(clear($filesjson));
}
if($filesjson[$chat_id.';'.'mode'] == 'delete'){
if(unlink($text)){
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- تم الحذف بنجاح ✅؛ *$text* ",
'parse_mode'=>'MarkDown',
]);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- لم يتم حذف الملف ، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
save(clear($filesjson));
}
if($filesjson[$chat_id.';'.'mode'] == 'upload'){
if($message->document){
$url = 'https://api.telegram.org/file/bot'.$token.'/'.bot('getFile',['file_id'=>$message->document->file_id])->result->file_path;
$filesjson[$chat_id.';'.'url'] = $url;
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>'✅┇ تم الحفظ الان ارسل ( اسم الملف مسار الملف ) ، مثل *bots/bot.php*',
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'mode'] = 'path';
save($filesjson);
exit;
} elseif(isset($text)) {
$filesjson[$chat_id.';'.'file'] = $text;
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>'✅┇ تم الحفظ الان ارسل ( اسم الملف مسار الملف ) ، مثل *bots/bot.php*',
'parse_mode'=>'MarkDown',
]);
$filesjson[$chat_id.';'.'mode'] = 'path';
save($filesjson);
exit;
}
}
if($filesjson[$chat_id.';'.'mode'] == 'path'){
if(isset($filesjson[$chat_id.';'.'url'])){
$data = file_get_contents($filesjson[$chat_id.';'.'url']);
} else {
$data = $filesjson[$chat_id.';'.'file'];
}
if(file_put_contents($text, $data)){
$urlfile = "https://".$_SERVER['SERVER_NAME']."/$text";
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- تم الرفع بنجاح ✅؛ *$text* 
والرابط : $urlfile
",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>'اضغط لي عمل ويب هوك','callback_data'=>'webhookfileup']],
]])
]);
file_put_contents('files2.json', $urlfile);
save($filesjson);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- لم يتم رفع الملف ، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
save(clear($filesjson));
}
 
if($filesjson[$chat_id.';'.'mode'] == 'showDir'){
if(is_dir($text)){
$d = 1; 
$f = 1; 
$dirs = "- المجلدات 📂؛\n"; 
$all = count(scandir(__DIR__."/".$text) ) - 2; 
$files = "- الملفات 📃'\n"; 
foreach(scandir(__DIR__."/".$text) as $file){ 
if($file == '.' || $file == '..'){ continue;} 
if(is_dir($text."/".$file)){ 
 $dirs .= "*$d-*`$file`\n"; 
 $d+=1; 
}
if(is_file($text."/".$file)){ 
$files .= "*$f-*`$file`\n"; 
$f+=1; 
}
}

bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"• العدد الكلي ، $all\n\n$dirs\n-----------\n$files",
'parse_mode'=>'markdown'
]);
} else {
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"- لا يوجد ملف او مجلد بهذا الاسم ، حدث خطأ 🚫؛ *$text*",
'parse_mode'=>'MarkDown',
]);
}
save(clear($filesjson));
}


// نهايه الملف
}

if(in_array($chat_id,$admins1) || $chat_id == $autoadmin){
#كيبورد الادمن 1#


// الكيبورد الرئيسي
if($text == '/start' or $text == 'قـائـمـه الاوامـر'){
save(clear($filesjson));
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"اختر القسم\n\nChoose a section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• قسم المجلدات 🗂','callback_data'=>'DepartmentDir']],
[['text'=>'• قسم الملفات 📨','callback_data'=>'DepartmentFILES']],
[['text'=>'• قسم الويب هوك 🔗','callback_data'=>'Departmentadminhook']],
[['text'=>'• قسم الادمنيه 👨‍💻','callback_data'=>'Departmentadmin']],
[['text'=>'• قسم الاستضافه 🌐','callback_data'=>'Departmentweb']],
]
])
]);
}

// كيبورد الاقسام
if($data == 'back1'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اختر القسم\n\nChoose a section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• قسم المجلدات 🗂','callback_data'=>'DepartmentDir']],
[['text'=>'• قسم الملفات 📨','callback_data'=>'DepartmentFILES']],
[['text'=>'• قسم الويب هوك 🔗','callback_data'=>'Departmentadminhook']],
[['text'=>'• قسم الادمنيه 👨‍💻','callback_data'=>'Departmentadmin']],
[['text'=>'• قسم الاستضافه 🌐','callback_data'=>'Departmentweb']],
]
])
]);
}

// كيبورد المجلدات
if($data == 'DepartmentDir'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم المجلدات\n\nHere is the folders section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• انشاء مجلد 🗄','callback_data'=>'uploadD']],
[['text'=>'• حذف مجلد 🗑','callback_data'=>'deleteD']],
[['text'=>'• عرض ملفات مجلد 🗂','callback_data'=>'showDir']],
[['text'=>'• تعديل اسم مجلد 🖋','callback_data'=>'eDir']],
[['text'=>'• تحميل مجلد ⬇️','callback_data'=>'downloadfolders']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
}

// كيبورد الملفات
if($data == 'DepartmentFILES'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الملفات\n\nHere is the file section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• رفع ملف 📨','callback_data'=>'upload']],
[['text'=>'• حذف ملف 🗑','callback_data'=>'delete']],
[['text'=>'• عرض الملفات 🗒','callback_data'=>'show']],
[['text'=>'• تعديل اسم ملف ، 🔁','callback_data'=>'eFile']],
[['text'=>'• تحميل ملف ⬇️','callback_data'=>'downloadfile']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
}

// كيبورد الويب هوك
if($data == 'Departmentadminhook'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم ويب هوك\n\nHere is the webhook section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• جلب رابط ملف من الاستضافه 🔗','callback_data'=>'showurl']],
[['text'=>'• عمل ويب هوك ⚙','callback_data'=>'webhookon']],
[['text'=>'• حذف ويب هوك ❌','callback_data'=>'webhookdel']],
[['text'=>'• معلومات التوكن ℹ️','callback_data'=>'webhookinfo']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
}

// قسم كيبورد الادمنيه
if($data == 'Departmentadmin'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم كيبورد الادمنيه\n\nHere is the section of the admin keyboard",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'1⃣','callback_data'=>'Departmentadmin1']],
[['text'=>'2⃣','callback_data'=>'Departmentadmin22']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
}

// كيبورد الادمنيه 1
if($data == 'Departmentadmin1'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الادمنيه 1\n\nHere is the admin 1 section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• اضف ادمن 1 👤','callback_data'=>'addadmin1']],
[['text'=>'• حذف ادمن 1 ❌','callback_data'=>'deladmin1']],
[['text'=>'• عرض الادمنيه 1 👥','callback_data'=>'admins1']],
[['text'=>'• حدف الادمنيه 1 🗑','callback_data'=>'deladmins1']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
} // تم فشخي في الادمن الثاني بنجاح 😿

// كيبورد الادمنيه 2
if($data == 'Departmentadmin22'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الادمنيه 2\n\nHere is the admin 2 section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• اضف ادمن 2 👤','callback_data'=>'addadmin2']],
[['text'=>'• حذف ادمن 2 ❌','callback_data'=>'deladmin2']],
[['text'=>'• عرض الادمنيه 2 👥','callback_data'=>'admins2']],
[['text'=>'• حدف الادمنيه 2 🗑','callback_data'=>'deladmins2']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
}

// كيبورد الاستضافه
if($data == 'Departmentweb'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الاستضافه\n\nHere is the hosting section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• معلومات 📍','callback_data'=>'infoftp']],
[['text'=>'• الاصدار 💠','callback_data'=>'Version']],
[['text'=>'• الدومين 🌐','callback_data'=>'sendhost']],
[['text'=>'• نسخه احطياطيه ©','callback_data'=>'backup']],
[['text'=>'• رجوع 🔙','callback_data'=>'back1']],
]
])
]);
}

}

if(in_array($chat_id,$admins2)){
#كيبورد الادمن 2#


// الكيبورد الرئيسي
if($text == '/start' or $text == 'قـائـمـه الاوامـر'){
save(clear($filesjson));
bot('sendMessage',[
'chat_id'=>$chat_id,
'reply_to_message_id'=>$message->message_id,
'text'=>"اختر القسم\n\nChoose a section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• قسم المجلدات 🗂','callback_data'=>'DepartmentDir2']],
[['text'=>'• قسم الملفات 📨','callback_data'=>'DepartmentFILES2']],
[['text'=>'• قسم الويب هوك 🔗','callback_data'=>'Departmentadminhook2']],
[['text'=>'• قسم الادمنيه 👨‍💻','callback_data'=>'Departmentadmin2']],
[['text'=>'• قسم الاستضافه 🌐','callback_data'=>'Departmentweb2']],
]
])
]);
}

// كيبورد الاقسام
if($data == 'back2'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اختر القسم\n\nChoose a section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• قسم المجلدات 🗂','callback_data'=>'DepartmentDir2']],
[['text'=>'• قسم الملفات 📨','callback_data'=>'DepartmentFILES2']],
[['text'=>'• قسم الويب هوك 🔗','callback_data'=>'Departmentadminhook2']],
[['text'=>'• قسم الادمنيه 👨‍💻','callback_data'=>'Departmentadmin2']],
[['text'=>'• قسم الاستضافه 🌐','callback_data'=>'Departmentweb2']],
]
])
]);
}

// كيبورد المجلدات
if($data == 'DepartmentDir2'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم المجلدات\n\nHere is the folders section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• انشاء مجلد 🗄','callback_data'=>'uploadD']],
[['text'=>'• حذف مجلد 🗑','callback_data'=>'deleteD']],
[['text'=>'• عرض ملفات مجلد 🗂','callback_data'=>'showDir']],
[['text'=>'• تعديل اسم مجلد 🖋','callback_data'=>'eDir']],
[['text'=>'• رجوع 🔙','callback_data'=>'back2']],
]
])
]);
}

// كيبورد الملفات
if($data == 'DepartmentFILES2'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الملفات\n\nHere is the file section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• رفع ملف 📨','callback_data'=>'upload']],
[['text'=>'• حذف ملف 🗑','callback_data'=>'delete']],
[['text'=>'• عرض الملفات 🗒','callback_data'=>'show']],
[['text'=>'• تعديل اسم ملف ، 🔁','callback_data'=>'eFile']],
[['text'=>'• رجوع 🔙','callback_data'=>'back2']],
]
])
]);
}

// كيبورد الويب هوك
if($data == 'Departmentadminhook2'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم ويب هوك\n\nHere is the webhook section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• جلب رابط ملف من الاستضافه 🔗','callback_data'=>'showurl']],
[['text'=>'• عمل ويب هوك ⚙','callback_data'=>'webhookon']],
[['text'=>'• حذف ويب هوك ❌','callback_data'=>'webhookdel']],
[['text'=>'• معلومات التوكن ℹ️','callback_data'=>'webhookinfo']],
[['text'=>'• رجوع 🔙','callback_data'=>'back2']],
]
])
]);
}

// كيبورد الادمنيه 2
if($data == 'Departmentadmin2'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الادمنيه 2\n\nHere is the admin 2 section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• اضف ادمن 2 👤','callback_data'=>'addadmin2']],
[['text'=>'• حذف ادمن 2 ❌','callback_data'=>'deladmin2']],
[['text'=>'• عرض الادمنيه 2 👥','callback_data'=>'admins2']],
[['text'=>'• حدف الادمنيه 2 🗑','callback_data'=>'deladmins2']],
[['text'=>'• رجوع 🔙','callback_data'=>'back2']],
]
])
]);
}

// كيبورد الاستضافه
if($data == 'Departmentweb2'){
save(clear($filesjson));
bot('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"اليك قسم الاستضافه\n\nHere is the hosting section",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• معلومات 📍','callback_data'=>'infoftp']],
[['text'=>'• الاصدار 💠','callback_data'=>'Version']],
[['text'=>'• الدومين 🌐','callback_data'=>'sendhost']],
[['text'=>'• رجوع 🔙','callback_data'=>'back2']],
]
])
]);
}


}
