<?php




//////////////(hmo)/////////#
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$message = $update->message;
$admin = 916165019; // ايديك
$username = $message->from->username;
$message_id2 = $update->callback_query->message->message_id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$Name = $update->callback_query->from->first_name;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$fn = $message->from->first_name;
$user_id = $message->from->id;
$userbot = "thkker_bot"; //يوز البوت دون @
$ch = "ddeneat"; //معرف قناتك دون @
#---------@ABoTaiM--------#

#صل على رسول الله
$type                  = $message->chat->type;
$itprivate             = $type == "private";
  
  $itsupergroup          = $type == "supergroup";
  $itgroup               = $type == "group";


$chat = explode("\n",file_get_contents("chat.txt"));
if($itgroup or $itsupergroup){
if(!in_array($chat_id,$chat)){
file_put_contents("chat.txt",$chat_id . "\n", FILE_APEND);
}}

if($_GET['zker'] == true){
$chat = explode("\n",file_get_contents("chat.txt"));
$zker = file_get_contents("https://hmsbots.aba.vg/apieati/ApiAthkar.php");
for($i=0;$i<=count($chat);$i++){
bot('sendmessage',[
'chat_id'=>$chat[$i],
'text'=>$zker
]);
}
}

if($text ==  '/start'){
bot( sendMessage ,[
chat_id =>$chat_id,
text => "أهلاً بك في بوت القران الكريم ..

أسأل الله تعال أن يكتب الأجر لي ولك ❤️

اليك الاقسام التاليه اختر منها مايناسبك 🤍
",
reply_markup =>json_encode([
inline_keyboard =>[
[[ 'text' => 'القرآن الكريم.',callback_data => 'سور' ]],
[[ 'text' => 'للاستماع للقرآن او القرائة','callback_data' => "show2"],['text'=>" تلاوات الاطفال ",'callback_data'=>'الاطفال']],
[['text' => 'قسم علوم القران',callback_data => 'olomq' ]],
[[ 'text' => 'الرقيه الشرعيه',callback_data => 'roqua' ],['text'=>'قسم الخطب','callback_data'=> '7ho6bh']],
[[ 'text' => 'المصحف كامل pdf',callback_data => 'moss7fpdf' ]],
[[ 'text' => 'الأذكار والأدعية .',callback_data => 'starta' ],['text'=>" NEW الادعية ",'callback_data'=>'الادعية']],
[[ 'text' => 'الكتب الاسلاميه .',callback_data => 'kottobeslameah' ]],
[['text'=> 'قصص من القران .' ,callback_data => 'Qasass'],[ 'text' => 'عن الوالدين',callback_data => 'Omewaabe' ]],
[[ 'text' => 'قسم الفيديو .',callback_data => 'videneat' ]],
[['text'=>"تطبيق مسلم برو",'callback_data'=>'tatbek'],[ 'text' => 'قسم البحث .',callback_data => 'bhtgggg' ]],
[[ 'text' => 'المصادرو الحقوق .',callback_data => 'mssader' ],[ 'text' => 'نبذه .',callback_data => 'nobtha' ]],
]])]);}




if($data == "rj03"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id2,
 'text'=>"أهلاً بك في بوت القران الكريم ..

أسأل الله تعال أن يكتب الأجر لي ولك ❤️

اليك الاقسام التاليه اختر منها مايناسبك 🤍
",
reply_markup =>json_encode([
inline_keyboard =>[
[[ 'text' => 'القرآن الكريم.',callback_data => 'سور' ]],
[[ 'text' => 'للاستماع للقرآن او القرائة','callback_data' => "show2"],['text'=>" تلاوات الاطفال ",'callback_data'=>'الاطفال']],
[['text' => 'قسم علوم القران',callback_data => 'olomq' ]],
[[ 'text' => 'الرقيه الشرعيه',callback_data => 'roqua' ],['text'=>'قسم الخطب','callback_data'=> '7ho6bh']],
[[ 'text' => 'المصحف كامل pdf',callback_data => 'moss7fpdf' ]],
[[ 'text' => 'الأذكار والأدعية .',callback_data => 'starta' ],['text'=>" NEW الادعية ",'callback_data'=>'الادعية']],
[[ 'text' => 'الكتب الاسلاميه .',callback_data => 'kottobeslameah' ]],
[['text'=> 'قصص من القران .' ,callback_data => 'Qasass'],[ 'text' => 'عن الوالدين',callback_data => 'Omewaabe' ]],
[[ 'text' => 'قسم الفيديو .',callback_data => 'videneat' ]],
[['text'=>"تطبيق مسلم برو",'callback_data'=>'tatbek'],[ 'text' => 'قسم البحث .',callback_data => 'bhtgggg' ]],
[[ 'text' => 'المصادرو الحقوق .',callback_data => 'mssader' ],[ 'text' => 'نبذه .',callback_data => 'nobtha' ]],
]])]);}


file_get_contents("https://api.telegram.org/bot".API_KEY."/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
$houda = json_decode(file_get_contents("houda.json"),true);
$update = json_decode(file_get_contents('php://input'));
if(isset($update->message)){
$message = $update->message;
$message_id = $update->message->message_id;
$chat_id = $message->chat->id;
$text = $message->text;
$user = $message->from->username;
$name0 = $message->from->first_name;
$name1 = $message->from->last_name;
$from_id = $message->from->id;
$tc = $message->chat->type;
}
if(isset($update->callback_query)){
$data = $update->callback_query->data;
$chat_id = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$name = $update->callback_query->message->chat->first_name;
$user = $update->callback_query->message->chat->username;
$from_id = $chat_id;
$tc = $update->callback_query->message->chat->type;
}

if($data == "exit"){
bot('editMessageReplyMarkup',[
'chat_id'=>$chat_id,
'message_id' =>$message_id,
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"العودةللقائمه الرئسيه 🔙",'callback_data'=>"rj03"]],
[['text'=>'نـسالـكم الدعـاء لنا 🤲','url'=>"https://t.me/hms_01"]],
]
])
]);
}
if($data == "7ho6bh"){
bot('sendphoto',[
'chat_id'=>$chat_id,
"photo"=>"https://j.top4top.io/p_2567il8xs1.jpg",
'parse_mode'=>"MarkDown",
'caption'=>"
*اهلا بك $name في بوت الخطب والمحاضرات *
* - نقدم لكم اروع الخطب لاكثر من شيخ *

للرجوع للقائمه الرئيسيه اضغط ♡ /start

• ┉ • ┉ • ┉ • ┉ • ┉ •
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'قسم الاستماع','callback_data'=> 'sora']],
]
])
]);
}
if($data == "exit1"){
bot('editMessageCaption',[
'chat_id'=>$chat_id,
'message_id' =>$message_id,
'caption'=>"
*اهلا بك $name في بوت الخطب والمحاضرات *
* - نقدم لكم اروع الخطب لاكثر من شيخ *

للرجوع للقائمه الرئيسيه اضغط ♡ /start

• ┉ • ┉ • ┉ • ┉ • ┉ •
",'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'قسم الاستماع','callback_data'=> 'sora']],
]
])
]);
}
$info =json_decode(file_get_contents('http://hmsbots.aba.vg/apieati/khutb.php'),ture);
if($data =="sora"){
for($key=2;$key <=20; $key++){
$name =$info[$key]["name"];
$url =$info[$key]["url"];
$reply_markup['inline_keyboard'][] = [['text'=>"".$name,'callback_data'=>"search#$url#$key"]];
}
$reply_markup['inline_keyboard'][] =[['text'=>'ᴇxɪᴛ ❎ ','callback_data'=>"exit1"]];
$reply_markup = json_encode($reply_markup);
bot('editMessageCaption',[
'chat_id'=>$chat_id,
'message_id' =>$message_id,
'caption'=>"
*حسنا عزيزي قم بإختيار من الاسفل *👋
",'parse_mode'=>"Markdown",
'reply_markup'=>$reply_markup
]);
}
$ex = explode("#",$data);
$search =json_decode(file_get_contents('http://hmsbots.aba.vg/apieati/khutb.php?info='.$ex[1]),ture);
if($ex[0]=="search"){
for($key=0;$key <=40; $key++){
$name =$search[$key]["name"];
$reply_markup['inline_keyboard'][] = [['text'=>"".$name,'callback_data'=>"down#$key#$ex[1]"]];
}
$reply_markup['inline_keyboard'][] =[['text'=>'ᴇxɪᴛ ❎ ','callback_data'=>"exit1"]];
$reply_markup = json_encode($reply_markup);
$photo =$info[$ex[2]]["photo"];
$n =$info[$ex[2]]["name"];
bot('editMessageMedia',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'media'=>json_encode([
'type'=>'photo',
'media'=>$photo,
'caption'=>"
الشيخ : $n 
"
]),
'parse_mode'=>"Markdown",
'reply_markup'=>$reply_markup
]);
}
if($ex[0]=="down"){
$search =json_decode(file_get_contents('http://hmsbots.aba.vg/apieati/khutb.php?info='.$ex[2]),ture);
$name =$search[$ex[1]]["name"];
$n =$search["n"];
$url =$search[$ex[1]]["url"];
bot('deletemessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id
    ]);
$xx = bot('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>$url,
'caption'=>"
   * الشيخ  : $n *
   * الخطبة  : $name *",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>'نـسالـكم الدعـاء لنا 🤲','url'=>"https://t.me/hms_01"]],
[['text'=>'اغلاق ❎','callback_data'=>"exit"]],
]
])
])->ok;
return false;
bot('sendaudio',[
'chat_id'=>-1001535817602,
'audio'=>$url,
'caption'=>"
   * الشيخ  : $n *
   * الخطبة : $name *
   *المستخدم : $name0 $name1*
   *معرفــة :@$user *
   ",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>'نـسالـكم الدعـاء لنا والدعم 🤲','url'=>"https://t.me/ddeneat"]],
]
])
]);
 if(!$xx){
$xxx = bot('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>curl_file_create($url,"audio.mp3","$name"),
'caption'=>"
  * الشيخ  : $n *
   * الخطبة : $name *",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>'نـسالـكم الدعـاء لنا 🤲','url'=>"https://t.me/hms_01"]],
[['text'=>'اغلاق ❎','callback_data'=>"exit"]],
]
])
])->ok;
}if(!$xxx && !$xx) {
bot("sendmessage",[
"chat_id"=>$chat_id,
"text"=>"❌┇حدث *خطأ* الحجم اكبر من 50 ميجابايت

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
• ┉ • ┉ • ┉ • ┉ • ┉ •
.","parse_mode"=>"markdown",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>'تحميل من رابط خارجي','url'=>"".$url]],
[['text'=>'رجوع ','callback_data'=>"exit"]],
]
])
]);
}
}

 if($data == "show2"){
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendphoto',[
'chat_id'=>$chat_id2,
'photo'=>"http://www.daily-quran.com/static/quran.jpg",
'caption'=>"*
- بسم الله الرحمن الرحيم 

- اهلا بك في قسم القرآن الكريم
- يقوم البوت بجلب صفحات القرآن صفحة صفحة
- كل ما عليك هوه ارسال رقم الصفحة لاقوم بجلبه بشكل صورة لك .،
- ارسل الارقام باللغة الانكليزية (1.2..4..الخ)
------‐------------------------
- نسألكم الدعاء ❤

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
-------------------------------*
",'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• تصفح القرآن",'callback_data'=>"1@1"]],
]])]);}
 if($data == "b1a2k"){
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendphoto',[
'chat_id'=>$chat_id2,
'photo'=>"http://www.daily-quran.com/static/quran.jpg",
'caption'=>"*
- بسم الله الرحمن الرحيم 

- اهلا بك في قسم القرآن الكريم
- يقوم البوت بجلب صفحات القرآن صفحة صفحة
- كل ما عليك هوه ارسال رقم الصفحة لاقوم بجلبه بشكل صورة لك .،
- ارسل الارقام باللغة الانكليزية (1.2..4..الخ)
• يمكنك الاستماع الى السور ايضا
------‐------------------------
- نسألكم الدعاء 

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
-------------------------------*
",'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• تصفح القرآن",'callback_data'=>"1@1"]],
]])]);}
 if($data == "show"){
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendphoto',[
'chat_id'=>$chat_id2,
'photo'=>"http://www.daily-quran.com/static/quran.jpg",
'caption'=>"*
- بسم الله الرحمن الرحيم 

- اهلا بك في قسم القرآن الكريم
- يقوم البوت بجلب صفحات القرآن صفحة صفحة
- كل ما عليك هوه ارسال رقم الصفحة لاقوم بجلبه بشكل صورة لك .،
- ارسل الارقام باللغة الانكليزية (1.2..4..الخ)
------‐------------------------
- نسألكم الدعاء ❤

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
-------------------------------*
",'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"الانتقال الى الموقع",'url'=>"https://www.daily-quran.com/quran/page/1.jpg"]],
[["text"=>"سورة الفاتحة","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/001.mp3"],["text"=>"سورة البقرة","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/002.mp3"]],
[["text"=>"  سورة آل عمران","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/003.mp3"],["text"=>"سورة النساء","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/004.mp3"]],
[["text"=>"سورة المائدة","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/005.mp3"],["text"=>"سورة الأنعام","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/006.mp3"]],
[["text"=>"سورة الأعراف","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/007.mp3"],["text"=>"سورة الأنفال","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/008.mp3"]],
[["text"=>" سورة التوبة","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/009.mp3"],["text"=>"سورة يونس","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/010.mp3"]],
[["text"=>"  سورة هود","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/011.mp3"],["text"=>"سورة يوسف","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/012.mp3"]],
[["text"=>"سورة الرعد","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/013.mp3"],["text"=>"سورة إبراهيم","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/014.mp3"]],
[["text"=>"سورة النحل","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/016.mp3"],["text"=>"سورة الإسراء","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/017.mp3"]],
[["text"=>"سورة الكهف","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/018.mp3"],["text"=>"  سورة مريم","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/019.mp3"]],
[["text"=>"سورة طه","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/020.mp3"],["text"=>"سورة الأنبياء","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/021.mp3"]],
[["text"=>"سورة الحج","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/022.mp3"],["text"=>"سورة المؤمنون","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/023.mp3"]],
[["text"=>"سورة النّور","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/024.mp3"],["text"=>"سورة الفرقان","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/025.mp3"]],
[["text"=>"سورة الشعراء","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/026.mp3"],["text"=>"سورة النّمل","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/027.mp3"]],
[["text"=>"سورة القصص","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/028.mp3"],["text"=>"سورة العنكبوت","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/029.mp3"]],
[["text"=>"سورة الرّوم","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/030.mp3"],["text"=>"سورة لقمان","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/031.mp3"]],
[["text"=>"سورة السجدة","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/032.mp3"],["text"=>"سورة الأحزاب","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/033.mp3"]],
[["text"=>" سورة سبأ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/034.mp3"],["text"=>"سورة فاطر","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/035.mp3"]],
[["text"=>"سورة يس","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/036.mp3"],["text"=>"سورة الصافات","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/037.mp3"]],
[["text"=>"سورة ص","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/038.mp3"],["text"=>"سورة الزمر","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/039.mp3"]],
[["text"=>"سورة غافر","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/040.mp3"],["text"=>"سورة فصّلت","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/041.mp3"]],
[["text"=>"سورة الشورى","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/042.mp3"],["text"=>"سورة الزخرف","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/043.mp3"]],
[["text"=>"سورة الدّخان","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/044.mp3"],["text"=>"سورة الجاثية","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/045.mp3"]],
[["text"=>"سورة الأحقاف","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/046.mp3"],["text"=>"سورة محمد","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/047.mp3"]],
[["text"=>"سورة الفتح","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/048.mp3"],["text"=>"سورة الحجرات","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/049.mp3"]],
[["text"=>"سورة ق","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/050.mp3"],["text"=>"سورة الذاريات","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/051.mp3"],["text"=>"سورة الطور","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/052.mp3"]],[["text"=>"سورة الحجر","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/015.mp3"]],
[["text"=>"باقي السور","callback_data"=>"next"]],
[['text'=>"• تصفح القرآن",'callback_data'=>"1@1"]],
[["text"=>"• رجوع ","callback_data"=>"b1a2k"]],
]])]);}
if($data == "next"){
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
'text'=>"• تم استعراض جميع الايات المتبقية 
~ اضغط للاستمتاع 💡

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
• ┉ • ┉ • ┉ • ┉ • ┉ •",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[["text"=>"سورة النجم ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/053.mp3"],["text"=>"سورة القمر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/054.mp3"]],
[["text"=>"سورة الرحمن ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/055.mp3"],["text"=>"سورة الواقعة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/056.mp3"]],
[["text"=>"سورة الحديد ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/057.mp3"],["text"=>"سورة المجادلة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/058.mp3"]],
[["text"=>"سورة الحشر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/059.mp3"],["text"=>"سورة الممتحنة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/060.mp3"]],
[["text"=>"سورة الصف ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/061.mp3"],["text"=>"سورة الجمعة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/062.mp3"]],
[["text"=>"سورة المنافقون ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/063.mp3"],["text"=>"سورة التغابن ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/064.mp3"]],
[["text"=>"سورة الطلاق ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/065.mp3"],["text"=>"سورة التحريم ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/066.mp3"]],
[["text"=>"سورة الملك ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/067.mp3"],["text"=>"سورة القلم ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/068.mp3"]],
[["text"=>"سورة الحاقة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/069.mp3"],["text"=>"سورة المعارج ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/070.mp3"]],
[["text"=>"سورة نوح ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/071.mp3"],["text"=>"سورة الجن ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/072.mp3"]],
[["text"=>"سورة المزّمّل ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/073.mp3"],["text"=>"سورة المدّثر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/074.mp3"]],
[["text"=>"سورة القيامة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/075.mp3"],["text"=>"سورة الإنسان ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/076.mp3"]],
[["text"=>"سورة المرسلات ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/077.mp3"],["text"=>"سورة النبأ ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/078.mp3"]],
[["text"=>"سورة النازعات ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/079.mp3"],["text"=>"سورة عبس ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/080.mp3"]],
[["text"=>"سورة التكوير ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/081.mp3"],["text"=>"سورة الإنفطار ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/082.mp3"]],
[["text"=>"سورة المطفّفين ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/083.mp3"],["text"=>"سورة الإنشقاق ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/084.mp3"]],
[["text"=>"سورة البروج ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/085.mp3"],["text"=>"سورة الطارق ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/086.mp3"]],
[["text"=>"سورة الأعلى ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/087.mp3"],["text"=>"سورة الغاشية ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/088.mp3"],["text"=>"سورة الفجر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/089.mp3"]],
[["text"=>"سورة البلد ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/090.mp3"],["text"=>"سورة الشمس ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/091.mp3"]],
[["text"=>"سورة الليل ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/092.mp3"],["text"=>"سورة الضحى ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/093.mp3"]],
[["text"=>"سورة الشرح ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/094.mp3"],["text"=>"سورة التين ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/095.mp3"]],
[["text"=>"سورة العلق ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/096.mp3"],["text"=>"سورة القدر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/097.mp3"]],
[["text"=>"سورة البينة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/098.mp3"],["text"=>"سورة الزلزلة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/099.mp3"]],
[["text"=>"سورة العاديات ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/100.mp3"],["text"=>"سورة القارعة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/101.mp3"]],
[["text"=>"سورة التكاثر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/102.mp3"],["text"=>"سورة العصر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/103.mp3"]],
[["text"=>"سورة الهمزة ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/104.mp3"],["text"=>"سورة الفيل ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/105.mp3"]],
[["text"=>"سورة قريش ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/106.mp3"],["text"=>"سورة الماعون ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/107.mp3"]],
[["text"=>"سورة الكوثر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/108.mp3"],["text"=>"سورة الكافرون ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/109.mp3"]],
[["text"=>"سورة النصر ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/110.mp3"],["text"=>"سورة المسد ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/111.mp3"]],
[["text"=>"سورة الإخلاص ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/112.mp3"],["text"=>"سورة الفلق ","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/113.mp3"]],
[["text"=>"سورة النّاس","url"=>"https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/114.mp3"]],
[['text'=>"• تصفح القرآن",'callback_data'=>"1@1"]],
[["text"=>"• رجوع ","callback_data"=>"b1a2k"]],
]])]);}

if($text < 10){
$num = $text+1;
$null = $text-1;
bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>"https://www.daily-quran.com/static/pages/page-00$text.jpg",
'caption'=>"*- تم العرض  للعرض من داخل الموقع،
- اضغط على الزر من الاسفل  نسألكم الدعاء .

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
------------*",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- الانتقال الى الموقع - ❤",'url'=>"https://www.daily-quran.com/quran/page/$text.jpg"]],
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• التالي",'callback_data'=>"1@$num"],['text'=>"• السابق",'callback_data'=>"1@$null"]],
[['text'=>"• رجوع",'callback_data'=>"b1a2k"]],
]])]);}
if($text >= 10 and $text <100){
$num = $text+1;
$null = $text-1;
bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>"https://www.daily-quran.com/static/pages/page-0$text.jpg",
'caption'=>"*- تم العرض  للعرض من داخل الموقع،
- اضغط على الزر من الاسفل  نسألكم الدعاء .

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
------------*",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- الانتقال الى الموقع -❤",'url'=>"https://www.daily-quran.com/quran/page/0$text.jpg"]],
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• التالي",'callback_data'=>"1@$num"],['text'=>"• السابق",'callback_data'=>"1@$null"]],
[['text'=>"• رجوع",'callback_data'=>"b1a2k"]],
]])]);}
if($text >= 100){
bot('sendphoto',[
'chat_id'=>$chat_id,
'photo'=>"https://www.daily-quran.com/static/pages/page-$text.jpg",
'caption'=>"*- تم العرض  للعرض من داخل الموقع،
- اضغط على الزر من الاسفل  نسألكم الدعاء .

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
------------*",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[[['text'=>"- الانتقال الى الموقع -❤",'url'=>"https://www.daily-quran.com/quran/page/$text.jpg"]],
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• التالي",'callback_data'=>"1@$num"],['text'=>"• السابق",'callback_data'=>"1@$null"]],
[['text'=>"• رجوع",'callback_data'=>"b1a2k"]],
]])]);}
$ex = explode("@",$data);
if($ex[1] < 10 ){
$num = $ex[1]+1;
$null = $ex[1]-1;
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendphoto',[
'chat_id'=>$chat_id2,
'photo'=>"https://www.daily-quran.com/static/pages/page-00$ex[1].jpg",
'caption'=>"*- تم العرض  للعرض من داخل الموقع،
- اضغط على الزر من الاسفل  نسألكم الدعاء .

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
------------*",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- الانتقال الى الموقع -❤",'url'=>"https://www.daily-quran.com/quran/page/0$ex[1].jpg"]],
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• التالي",'callback_data'=>"1@$num"],['text'=>"• السابق",'callback_data'=>"1@$null"]],
[['text'=>"• رجوع",'callback_data'=>"b1a2k"]],
]])]);}
if($ex[1] >= 10 and $ex[1] <100){
$num = $ex[1]+1;
$null = $ex[1]-1;
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendphoto',[
'chat_id'=>$chat_id2,
'photo'=>"https://www.daily-quran.com/static/pages/page-0$ex[1].jpg",
'caption'=>"*- تم العرض  للعرض من داخل الموقع،
- اضغط على الزر من الاسفل  نسألكم الدعاء .

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
------------*",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- الانتقال الى الموقع -❤",'url'=>"https://www.daily-quran.com/quran/page/0$ex[1].jpg"]],
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• التالي",'callback_data'=>"1@$num"],['text'=>"• السابق",'callback_data'=>"1@$null"]],
[['text'=>"• رجوع",'callback_data'=>"b1a2k"]],
]])]);}
if($ex[1] >= 100){
$num = $ex[1]+1;
$null = $ex[1]-1;
bot('sendMessage',[
'chat_id'=>$chat_id2,'message_id'=>$message_id2,
]);
bot('sendphoto',[
'chat_id'=>$chat_id2,
'photo'=>"https://www.daily-quran.com/static/pages/page-0$ex[1].jpg",
'caption'=>"*- تم العرض  للعرض من داخل الموقع،
- اضغط على الزر من الاسفل  نسألكم الدعاء .

 للرجوع للقائمه الرئيسيه اضغط ♡ /start
------------*",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- الانتقال الى الموقع -❤",'url'=>"https://www.daily-quran.com/quran/page/0$ex[1].jpg"]],
[['text'=>"• استمع الى القرآن",'callback_data'=>"show"]],
[['text'=>"• التالي",'callback_data'=>"1@$num"],['text'=>"• السابق",'callback_data'=>"1@$null"]],
[['text'=>"• رجوع",'callback_data'=>"b1a2k"]],
]])]);}

if($data=="nobtha"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
بسم الله والصلاة والسلام على رسول الله ❤
هذا البوت صدقة جاريه لجميع امواتنا واموات المسلمين اسأل الله ان يغفر لهم ويرحمهم ويجعل قبورهم روضه من رياض الجنه ويجعلهم من اهلها اللهم امين ..💙
 الدال على الخير كفاعلة ❀
اصدار البوت : 5.0
تم تحديث البوت في تاريخ  : الأثنين/مايو /2022/05/30م
ـ06:16:35
",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]])]);}
if($data=="mssader"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
قناة الفتاوى للشيخ عثمان الخميس

https://youtube.com/channel/UCoRDayQCpJLRf-yk4nheo5g

قصص الانبياء نواف السالم 

https://youtube.com/playlist?list=PLG9IF6afbWoc9v6dweh8XG4XnRSe457_-

وقفات تربويه للشيخ سعد العتيق

https://youtube.com/playlist?list=PLVV65uldXO2tCJL_jt1HILWvmFWrHXjme

طارق السويدان السيرة النبويه


https://youtube.com/playlist?list=PLXtSlqC4MDLwX_6mx_tVyy01MYYofSe8w
",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]])]);}
if($data == "tatbek"){
   bot('senddocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/YOUSFKH/1939",
'caption'=>"@$userbot",
]);
bot('sendmessage',[
     'chat_id'=>$chat_id2,
   'text'=>"
يعتبره أكثر من 70 مليون مسلم في أنحاء العالم الإسلامي التطبيق الأكثر دقة لمواعيد الصلاة والأذان. كما يحتوي Muslim Pro أيضًا على القرآن بالكامل بالنصوص العربية والعلامات الصوتية والترجمات والتلاوات المسموعة إلى جانب محدد موقع القبلة وتقويم هجري إسلامي وخريطة لمطاعم الأكل الحلال والمساجد وما إلى ذلك.
",
]);}


$Voice = rand(36, 55);
if($data == "telawa"){
bot('sendvoice',[
 'chat_id'=>$chat_id2,
 'voice'=>"https://t.me/sand_199/$Voice",
 'caption'=>"@$userbot", 
]);}

#صل على رسول الله
if($data){
$thekr = file_get_contents("https://sand65.ml/api/azkar.php");
bot('answerCallbackQuery',[ 
'callback_query_id'=>$update->callback_query->id, 
'text'=>"$thekr", 
'show_alert'=>true 
]);} 
//صل على رسول الله
$a = array("الفاتحة","البقرة","ال عمران","النساء","المائدة","الانعام","الاعراف","الانفال","التوبة","يونس","هود","يوسف","الرعد","ابراهيم","الحجر","النحل","الاسراء","الكهف","مريم","طه","الانبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الاحزاب","سبا","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدّخان","الجاثية","الاحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الانسان","المرسلات","النبا","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الاعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الاخلاص","الفلق","الناس");
if(in_array($text,$a)){
$x = array_search($text,$a);
if($x < 10){
$f = $x+1;
$g = "https://server8.mp3quran.net/afs/00$f.mp3";
}
if($x >= 10 and $x <100){
$f = $x+1;
$g = "https://server8.mp3quran.net/afs/0$f.mp3";
}
if($x >= 100){
$f = $x+1;
$g = "https://server8.mp3quran.net/afs/$f.mp3";
}
bot('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>$g,
'caption'=>"[$text $f](https://server8.mp3quran.net/afs/$f.mp3)
@$userbot",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>'markdown','disable_web_page_preview'=>true
]);
}

if($data=="bhtgggg"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"

* هذه قائمة اوامر البحث ✅*

*
🤍 ¦ سورة اسم السورة ~ لارسال السورة على شكل ملف mp3

🤍 ¦ اية: ما تذكره من اية ~ للبحث عن آية

🤍 ¦ صفحة رقم الصفحة ~ لإرسال صورة الصفحة في القرآن الكريم

🤍 ¦ حديث: ما تذكره من الحديث ~ للبحث عن الحديث

🤍 ¦ وللبحث عن حديث برقم الحديث في الكتب التالية 
🤍 ¦ صحيح البخاري
🤍 ¦ صحيح مسلم
🤍 ¦ مسند أحمد
🤍 ¦ موطأ مالك
🤍 ¦ سنن الترمذي
🤍 ¦ سنن أبو داود
🤍 ¦ سنن الدارمي
🤍 ¦ سنن ابن ماجه
🤍 ¦ سنن النسائي
🤍 ¦الطريقة ك التالي 
🤍 ¦اسم الكتاب + الرقم
🤍 ¦مثال : 
🤍 ¦ صحيح البخاري 100
🤍 ¦ مسند أحمد 100
🤍 ¦ موطأ مالك 100
🤍 ¦ سنن الدارمي 100
🤍 ¦ استوري ديني ~ لإرسال مقطع ديني قصير*",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]])]);}

if($data=="videneat"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الفيديوهات الدينيه

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للفيديوهات المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"ستوريات دينيه",'callback_data'=>'ddenevid'],['text'=>"عجائب خلق الله",'callback_data'=>'3jgaebrbe']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($text == "دينيات"){
$rand_id = rand(2,105);
$video = "https://t.me/Telawat_Qurani/".$rand_id;
bot('sendvideo',[
'chat_id'=>$chat_id,
'video'=>$video,
'caption'=>"💚🌸@ddeneat", 
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"♡ آج‌ــ‌๋ـر ♡ ♻",'url'=>"https://t.me/ddeneat"]],
],
]),
]);
}
if($data == "video#$from_id"){
$rand_id = rand(2,100);
$video = "https://t.me/Telawat_Qurani/".$rand_id;
bot('editMessageMedia',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'media'=>json_encode([
'type'=>'video',
'media'=>$video,
'caption'=>"🌸💚@ddeneat", 
]),
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"♡ آج‌ــ‌๋ـر ♡ ♻",'url'=>"https://t.me/ddeneat"]],
],
]),
]);
}
function cap($url){
preg_match_all('#content=(.*)#',file_get_contents($url),$match);
return str_replace(['"','<','>'],null,$match[1][4]);
}
if($text == "عجائب" || $text == "خلق الله"){
$video = rand(2,43);
$video1 = "https://t.me/agaebrby/$video";
bot('sendvideo',[
'chat_id'=>$chat_id,
'video'=>$video1,
'caption'=>cap($video1), 
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'♡ آج‌ــ‌๋ـر ♡ ♻','url'=>"https://t.me/ddeneat"]],
],
]),
]);
}
if($data == "video#$from_id"){
$video = rand(2,43);
$video1 = "https://t.me/agaebrby/$video";
bot('editMessageMedia',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'media'=>json_encode([
'type'=>'video',
'media'=>$video1,
'caption'=>cap($video1), 
]),
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'♡ آج‌ــ‌๋ـر ♡ ♻','url'=>"https://t.me/ddeneat"]],
],
]),
]);
}

###البحث###



if(preg_match('/^سورة (.*)$/',$text,$match)){
$words  = array("الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","ابراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبإ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الانسان","المرسلات","النبإ","النازعات","عبس","التكوير","الإنفطار","المطففين","الإنشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس");
$input = $match[1];
$shortest = -1;
foreach ($words as $word) {
    $lev = levenshtein($input, $word);
    if ($lev == 0) {
        $closest = $word;
        $shortest = 0;
        break;
    }
    if ($lev < $shortest || $shortest < 0) {
        $closest  = $word;
        $shortest = $lev;
    }
}
if(!in_array($input,$words)){
if ($shortest == 0) {
$s = "";
$txt = "حدث خطأ!! 
حاول إرسال الكلمة من دون أخطاء املائية ..";
} else {
$s = $closest;
$main = "ok";
}
}else{
$s = $input;
}
$e=array_search($s,$words)+2;
$link = "https://t.me/mshriiafs/".$e;
$tt = isset($s) ? "سورة $s" : $txt;
bot('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>$link,
'caption'=>$tt,
'reply_to_message_id'=>$message_id,
]);
}


$g = str_replace('حديث: ','',$text);
if($text == "حديث: $g"){
$a = file_put_contents("$from_id.txt",Strip_tags(file_get_contents("https://musliem-bot.ml/حديث/Index.php?k=".$g)));
$get = file_get_contents("$from_id.txt");
$ex = explode("--",$get);
for($i=0;$i<count($ex);$i++){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$ex[$i]
]);
}
if($i <= count($ex)){
bot('senddocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("$from_id.txt"),
'caption'=>"النتائج بالكامل داخل الملف",
]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
تم البحث واظهار النتائج بنجاح ✅
للبحث مجددا ارسل حديث + نص الحديث



⚠ يرجى تجنب الأخطاء الإملائية للحصول على نتائج دقيقة 👌🇸🇦
—————
",
]);
unlink("$from_id.txt");
}}
function page_quran($count){
 if(10 > $count){
$a = "http://www.aliman-group.com/quran/big_gif/00$count.gif";
}elseif(10 <= $count && 100 > $count){
$a = "http://www.aliman-group.com/quran/big_gif/0$count.gif";
}elseif(100 <= $count){
$a = "http://www.aliman-group.com/quran/big_gif/$count.gif";
}
if($count > 604){
return false;}
return $a;
}
function pagee($count){
 if(10 > $count){
$a = "00$count";
}elseif(10 <= $count && 100 > $count){
$a = "0$count";
}elseif(100 <= $count){
$a = "$count";
}
if($count > 604){
return false;}
return $a;
}
if(preg_match("/صفحة ([\d]*)/",$text,$count)){
bot('SendPhoto',[
'chat_id'=>$chat_id,
'photo'=>page_quran($count[1]),
'parse_mode'=>"MarkDown",
'caption'=>"صفحة رقم *$count[1]* من القرآن الكريم 🌿",
'reply_to_message_id'=>$message_id,
]);
$pagee = pagee($count[1]);
file_put_contents('../mediaa/'.$pagee.".mp3",file_get_contents("https://ia802309.us.archive.org/32/items/mshary-al3afasy-by-qasr-almonfasel-604-page-quran-mp3-128kb_21/".$pagee.".mp3"));
bot('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>new CURLFILE ('../mediaa/'.$pagee.".mp3"),
'performer'=>"القارئ مشاري عفاسي",
'title'=>"الصفحة : ".$pagee,
'parse_mode'=>"MarkDown",
'caption'=>"صفحة رقم *$count[1]* من القرآن الكريم 🌿",
'reply_to_message_id'=>$message_id,
]);
}
if($text == "استوري ديني"){
$rand_id = rand(2,100);
$video = "https://t.me/Telawat_Qurani/".$rand_id;
bot('sendvideo',[
'chat_id'=>$chat_id,
'video'=>$video, 
'reply_to_message_id'=>$message->message_id,
]);
} 
if(preg_match('/^اية: (.*)/',$text,$match)){
$get = json_decode(file_get_contents('https://api-quran.cf/quransql/index.php?text='.$match[1]), true);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>$get['result'][0]."
لاتنساني من دعائك",
'reply_to_message_id'=>$message_id,
]);
}
/*
if(preg_match('/صحيح (.*) \| حديث: (.*)/',$text,$j)){
$ke = str_replace(["مسلم","البخاري","احمد","مالك","الترمذي"],["muslim","bukhari","ahmed","malik","trmzi"],$j[1]);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>json_decode(file_get_contents("https://raw.githubusercontent.com/Mohamed-Nagdy/Quran-App-Data/main/Hadith%20Books%20Json/$ke.json"),1)[$j[2]-1][hadith],
'reply_to_message_id'=>$message_id,
]);
}
*/
if(preg_match('/صحيح (.*) (.*)/',$text,$j)){
  $ke = str_replace(["مسلم","البخاري","أحمد","مالك","الترمذي","الدارمي"],["muslim","bukhari","ahmed","malik","trmizi","darimi"],$j[1]);
  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>json_decode(file_get_contents("https://raw.githubusercontent.com/Mohamed-Nagdy/Quran-App-Data/main/Hadith%20Books%20Json/$ke.json"),1)[$j[2]-1][hadith],
  'reply_to_message_id'=>$message_id,
]);
}
  
  if(preg_match('/سنن (.*) (.*)/',$text,$j)){
  $ke = str_replace(["أبو داود","الترمذي","الدارمي","النسائي","ابن ماجه"],["abi_daud","trmizi","darimi","nasai","ibn_maja"],$j[1]);
  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>json_decode(file_get_contents("https://raw.githubusercontent.com/Mohamed-Nagdy/Quran-App-Data/main/Hadith%20Books%20Json/$ke.json"),1)[$j[2]-1][hadith],
  'reply_to_message_id'=>$message_id,
  ]);
}
  
  if(preg_match('/مسند (.*) (.*)/',$text,$j)){
  $ke = str_replace(["أحمد"],["ahmed"],$j[1]);
  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>json_decode(file_get_contents("https://raw.githubusercontent.com/Mohamed-Nagdy/Quran-App-Data/main/Hadith%20Books%20Json/$ke.json"),1)[$j[2]-1][hadith],
  'reply_to_message_id'=>$message_id,
]);
}
  
  if(preg_match('/موطأ (.*) (.*)/',$text,$j)){
  $ke = str_replace(["مالك"],["malik"],$j[1]);
  bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>json_decode(file_get_contents("https://raw.githubusercontent.com/Mohamed-Nagdy/Quran-App-Data/main/Hadith%20Books%20Json/$ke.json"),1)[$j[2]-1][hadith],
  'reply_to_message_id'=>$message_id,
]);
}


if($data=="ddenevid"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"*
 🌸 ¦ اكتب دينيات او استوري ديني ~ لإرسال مقطع ديني قصير*
",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]])]);}

if($data=="3jgaebrbe"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"*
 🌸 ¦ اكتب خلق الله او عجائب ~ لإرسال مقطع ديني قصير*
",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]])]);}




if($data ==  'starta' ){
bot( editMessageText ,[
chat_id =>$chat_id2,
'message_id'=>$message_id,
'text' => 'أهلاً بك في قسم لأذكار ..
      القسم مطور بطريقة مميزة ليسهل عليك قراءة الأذكار 
/start',
reply_markup =>json_encode([
inline_keyboard =>[
[['text'=>" الاذكار اليومية ",'callback_data'=>'الاذكار']],
[[ 'text' => 'أذكار الصباح .',callback_data => 'c' ],['text'=> 'أذكار المساء .' ,callback_data => 'e']] ,
[['text'=> 'أوقات الصلاة .' ,callback_data => 'a'],['text'=> 'أركان الإسلام .' ,callback_data => 't']] ,
[['text'=> 'آذكار ما قبل النوم .' ,callback_data => 'adnom'],['text'=> 'اذكار الاستيقاظ من النوم .' ,callback_data => 'sbhdkr']] ,
[[ 'text' => 'اذكار بعد الصلاه .',callback_data => 'dkrb3dslah' ]],
[['text'=> 'أجمل دعاء إلى الله .' ,callback_data => 'y'],['text'=> 'دعاء يقال في قيام الليل .' ,callback_data => 'r']] ,
[['text'=> 'الدعاء عند دخول الخلاء و عند الخروج منه .' ,callback_data => 'z']] ,
[['text'=> 'أوقات يُستحب فيها الدعاء وتُستجاب الدعوات .' ,callback_data => 'u']] ,
[['text'=> 'كلمتان خفيفتان على اللسان، ثقيلتان في الميزان .' ,callback_data => 'w']] ,
[[ 'text' => 'الدعاء للميت .',callback_data => 'd32meet']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]])]);}

if($data=="adnom"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم اذكار ماقبل النوم

 - اختر اسم القسم من الاسفل وساقوم بتحويلك الاذكار المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"الذكر 1",'callback_data'=>'nomsor1'],['text'=>"الذكر2",'callback_data'=>'nomsor2']],
[['text'=>"اذكار النوم صوت",'callback_data'=>'nomsot']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data=="sbhdkr"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم اذكار الاستيقاظ من النوم

 - اختر اسم القسم من الاسفل وساقوم بتحويلك الاذكار المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"صوت",'callback_data'=>'sbhsot'],['text'=>"صورة",'callback_data'=>'sbhsorah']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data=="d32meet"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الدعاء للميت

 - اختر اسم القسم من الاسفل وساقوم بتحويلك الاذكار المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"دعاء صوت1",'callback_data'=>'d3a3'],['text'=>"دعاء صوت2",'callback_data'=>'d3a32']],
[['text'=>"صورة",'callback_data'=>'metsor']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data == "nomsor1"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/39",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "nomsor2"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/40",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "nomsot"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/41",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sbhsot"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/42",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sbhsorah"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/43",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "dkrb3dslah"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/44",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "d3a3"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/49",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "d3a32"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/48",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "metsor"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/47",
reply_to_message_id =>$message->message_id, 
]);
}
if($data ==  'c' ){
bot( editMessageText ,[
chat_id =>$chat_id2,
'message_id'=>$message_id,
'text' => '▪️أَعُوذُ بِاللهِ مِنْ الشَّيْطَانِ الرَّجِيمِ
     
     ⏺اللّهُ لاَ إِلَـهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّومُ لاَ تَأْخُذُهُ سِنَةٌ وَلاَ نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلاَّ بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلاَ يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلاَّ بِمَا شَاء وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالأَرْضَ وَلاَ يَؤُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ.[آية الكرسى - البقرة 255]. 
     🔹مرة واحدة',
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '➖بِسْمِ اللهِ الرَّحْمنِ الرَّحِيم
     
     ⏺قُلْ هُوَ ٱللَّهُ أَحَدٌ، ٱللَّهُ ٱلصَّمَدُ، لَمْ يَلِدْ وَلَمْ يُولَدْ، وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ.
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '➖بِسْمِ اللهِ الرَّحْمنِ الرَّحِيم
     
     ⏺قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ، مِن شَرِّ مَا خَلَقَ، وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ، وَمِن شَرِّ ٱلنَّفَّٰثَٰتِ فِى ٱلْعُقَدِ، وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ. 
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '➖بِسْمِ اللهِ الرَّحْمنِ الرَّحِيم
     
     ⏺قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ، مَلِكِ ٱلنَّاسِ، إِلَٰهِ ٱلنَّاسِ، مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ، ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ، مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ.
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c4' ]]
    ]
    ])
    ]);
    }
    
    if($data ==  'c4' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '
     🔸أَصْـبَحْنا وَأَصْـبَحَ المُـلْكُ لله وَالحَمدُ لله ، لا إلهَ إلاّ اللّهُ وَحدَهُ لا شَريكَ لهُ، لهُ المُـلكُ ولهُ الحَمْـد، وهُوَ على كلّ شَيءٍ قدير ، رَبِّ أسْـأَلُـكَ خَـيرَ ما في هـذا اليوم وَخَـيرَ ما بَعْـدَه ، وَأَعـوذُ بِكَ مِنْ شَـرِّ ما في هـذا اليوم وَشَرِّ ما بَعْـدَه، رَبِّ أَعـوذُبِكَ مِنَ الْكَسَـلِ وَسـوءِ الْكِـبَر ، رَبِّ أَعـوذُ بِكَ مِنْ عَـذابٍ في النّـارِ وَعَـذابٍ في القَـبْر. ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c5' ]]
    ]
    ])
    ]);
    }
    
    if($data ==  'c5' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '
     🔸اللّهـمَّ أَنْتَ رَبِّـي لا إلهَ إلاّ أَنْتَ ، خَلَقْتَنـي وَأَنا عَبْـدُك ، وَأَنا عَلـى عَهْـدِكَ وَوَعْـدِكَ ما اسْتَـطَعْـت ، أَعـوذُبِكَ مِنْ شَـرِّ ما صَنَـعْت ، أَبـوءُ لَـكَ بِنِعْـمَتِـكَ عَلَـيَّ وَأَبـوءُ بِذَنْـبي فَاغْفـِرْ لي فَإِنَّـهُ لا يَغْـفِرُ الذُّنـوبَ إِلاّ أَنْتَ . ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c6' ]]
    ]
    ])
    ]);
    }
    
    if($data ==  'c6' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔸رَضيـتُ بِاللهِ رَبَّـاً وَبِالإسْلامِ ديـناً وَبِمُحَـمَّدٍ صلى الله عليه وسلم نَبِيّـاً. 
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c7' ]]
    ]
    ])
    ]);
    }
    
    
    
    if($data ==  'c7' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '
     🔸حَسْبِـيَ اللّهُ لا إلهَ إلاّ هُوَ عَلَـيهِ تَوَكَّـلتُ وَهُوَ رَبُّ العَرْشِ العَظـيم. 
     🔹7 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c8' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c8' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘بِسـمِ اللهِ الذي لا يَضُـرُّ مَعَ اسمِـهِ شَيءٌ في الأرْضِ وَلا في السّمـاءِ وَهـوَ السّمـيعُ العَلـيم.    
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c9' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c9' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘اللّهُـمَّ بِكَ أَصْـبَحْنا وَبِكَ أَمْسَـينا ، وَبِكَ نَحْـيا وَبِكَ نَمُـوتُ وَإِلَـيْكَ النُّـشُور' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c10' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c10' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘أَصْبَـحْـنا عَلَى فِطْرَةِ الإسْلاَمِ، وَعَلَى كَلِمَةِ الإِخْلاَصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِينَا إبْرَاهِيمَ حَنِيفاً مُسْلِماً وَمَا كَانَ مِنَ المُشْرِكِينَ. ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الـتـالـي' , callback_data => 'c11' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c11' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '
     🔘سُبْحـانَ اللهِ وَبِحَمْـدِهِ عَدَدَ خَلْـقِه ، وَرِضـا نَفْسِـه ، وَزِنَـةَ عَـرْشِـه ، وَمِـدادَ كَلِمـاتِـه.
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c12' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c12' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘اللّهُـمَّ عافِـني في بَدَنـي ، اللّهُـمَّ عافِـني في سَمْـعي ، اللّهُـمَّ عافِـني في بَصَـري ، لا إلهَ إلاّ أَنْـتَ اللّهُـمَّ إِنّـي أَعـوذُ بِكَ مِنَ الْكُـفر ، وَالفَـقْر ، وَأَعـوذُ بِكَ مِنْ عَذابِ القَـبْر ، لا إلهَ إلاّ أَنْـتَ.
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c13' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c13' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '
     🔘اللّهُـمَّ إِنِّـي أسْـأَلُـكَ العَـفْوَ وَالعـافِـيةَ في الدُّنْـيا وَالآخِـرَة ، اللّهُـمَّ إِنِّـي أسْـأَلُـكَ العَـفْوَ وَالعـافِـيةَ في ديني وَدُنْـيايَ وَأهْـلي وَمالـي ، اللّهُـمَّ اسْتُـرْ عـوْراتي وَآمِـنْ رَوْعاتـي ، اللّهُـمَّ احْفَظْـني مِن بَـينِ يَدَيَّ وَمِن خَلْفـي وَعَن يَمـيني وَعَن شِمـالي ، وَمِن فَوْقـي ، وَأَعـوذُ بِعَظَمَـتِكَ أَن أُغْـتالَ مِن تَحْتـي. ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c14' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c14' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘يَا حَيُّ يَا قيُّومُ بِرَحْمَتِكَ أسْتَغِيثُ أصْلِحْ لِي شَأنِي كُلَّهُ وَلاَ تَكِلُنِي إلَى نَفْسِي طَـرْفَةَ عَيْنٍ.' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c15' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c15' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘اللّهُـمَّ عالِـمَ الغَـيْبِ وَالشّـهادَةِ فاطِـرَ السّماواتِ وَالأرْضِ رَبَّ كـلِّ شَـيءٍ وَمَليـكَه ، أَشْهَـدُ أَنْ لا إِلـهَ إِلاّ أَنْت ، أَعـوذُ بِكَ مِن شَـرِّ نَفْسـي وَمِن شَـرِّ الشَّيْـطانِ وَشِـرْكِه ، وَأَنْ أَقْتَـرِفَ عَلـى نَفْسـي سوءاً أَوْ أَجُـرَّهُ إِلـى مُسْـلِم. ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c17' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘أَعـوذُ بِكَلِمـاتِ اللّهِ التّـامّـاتِ مِنْ شَـرِّ ما خَلَـق.
     🔹3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c18' ]]
    ]
    ])
    ]);
    }
    
    
    if($data ==  'c18' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ على نَبِيِّنَا مُحمَّد.
     ✔️غير مقيد بعدد' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c19' ]]
    ]
    ])
    ]);
    }
    if($data ==  'c19' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '🔘اللَّهُمَّ إِنَّا نَعُوذُ بِكَ مِنْ أَنْ نُشْرِكَ بِكَ شَيْئًا نَعْلَمُهُ ، وَنَسْتَغْفِرُكَ لِمَا لَا نَعْلَمُهُ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'c20' ]]
    ]
    ])
    ]);
    }
    
    if($data ==  'c20' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
   "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    
    if($data ==  'a' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الفجْر٤:٣٨ ص' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الفْجر .' , callback_data => 'a1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'a1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الشروق٥:٥٩ ص' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الشروق .' , callback_data => 'a2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'a2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الظُّهْر١٢:٢٩ م' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الظُّهْر .' , callback_data => 'a3' ]]
    ]
    ])
    ]);
    }
    
    
    if($data ==  'a3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'العَصر٣:٥٠ م' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العَصر .' , callback_data => 'a4' ]]
    ]
    ])
    ]);
    }
    if($data ==  'a4' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'المَغرب٦:٥٨ م' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'المَغرب .' , callback_data => 'a5' ]]
    ]
    ])
    ]);
    }
    if($data ==  'a5' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'العِشاء٨:٢٨ م' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العِشاء .' , callback_data => 'a6' ]]
    ]
    ])
    ]);
    }
    if($data ==  'a6' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    
    if($data ==  'z' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'عند الدخول يقول : (بِسمِ الله ) اللّهُـمَّ إِنِّـي أَعـوذُ بِـكَ مِـنَ الخُـبثِ وَالخَبائِث. رواه البخاري ومسلم .
وإذا خرج قال: غُفـرانَك. أخرجه أصحاب السنن إلا النسائي' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'z1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'z1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    
    if($data ==  'r' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللهم أنت ربي لا إله إلا أنت عليك توكلت وأنت رب العرش العظيم ما شاء الله كان وما لم يشأ لم يكن لا حول ولا قوة إلا العظيم العلى العظيم أعلم أن الله على كل شيء قدير وأن الله قد أحاط بكل شيء علما اللهم إني أعوذ بك من شر نفسي ومن شر كل دابة أنت آخذ بناصيتها إن ربي على صراط مستقيم.' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'r1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'r1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    
    if($data ==  'w' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'عن أبي هريرة - رضي الله عنه - قال: قال رسول الله - صلى الله عليه وسلم -: ((كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن: ((سبحان الله وبحمده، سبحان الله العظيم))، متفق عليه.' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'w1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'w1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    if($data ==  'y' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دُعاء مصدر دَعا، وهو ما يُدْعَى به اللهَ من القول، وهو أيضًا رفع الكفّين بالابتهال والتضرّع إلى الله، وهو من العبادات التي يلجأ بها العبد إلى الله وحده دون غيره في أي وقت شاء، ولا ينحصر الدعاء في صيغة محدّدة، وقد قال تعالى في كتابه الكريم: " وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ" [١]، ولا يقتصر الدعاء على دعاء المرء لنفسه فقط، بل من الجميل قيام المرء بالدعاء لغيره بالخير، وفي هذا المقال حديثٌ عن الدعاء وعن أجمل دعاء إلى الله من الكتاب والسنّة .' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'y1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'y1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
   
    if($data ==  't' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الشهادتان (شهادة أن لا إله إلا الله، وشهادة ان محمداً رسول الله)' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الركن الاول .' , callback_data => 't1' ]]
    ]
    ])
    ]);
    }
    if($data ==  't1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'إقام الصلاة (وهي خمس صلوات في اليوم والليلة)' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الركن الثاني .' , callback_data => 't2' ]]
    ]
    ])
    ]);
    }
    if($data ==  't2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'إيتاء الزكاة' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الركن الثالث .' , callback_data => 't3' ]]
    ]
    ])
    ]);
    }
    
    
    if($data ==  't3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'صوم شهر رمضان' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الركن الرابع .' , callback_data => 't4' ]]
    ]
    ])
    ]);
    }
    if($data ==  't4' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'حج البيت (من استطاع إليه سبيلا، أي للقادرين)' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'الركن الخامس .' , callback_data => 't5' ]]
    ]
    ])
    ]);
    }
    if($data ==  't5' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     
    text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    
    if($data ==  'e' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'أَعُوذُ بِاللهِ مِنْ الشَّيْطَانِ الرَّجِيمِ
     اللّهُ لاَ إِلَـهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّومُ لاَ تَأْخُذُهُ سِنَةٌ وَلاَ نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلاَّ بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلاَ يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلاَّ بِمَا شَاء وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالأَرْضَ وَلاَ يَؤُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'e1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'بِسْمِ اللهِ الرَّحْمنِ الرَّحِيم
     قُلْ هُوَ ٱللَّهُ أَحَدٌ، ٱللَّهُ ٱلصَّمَدُ، لَمْ يَلِدْ وَلَمْ يُولَدْ، وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ 
     3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'بِسْمِ اللهِ الرَّحْمنِ الرَّحِيم
     قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ، مِن شَرِّ مَا خَلَقَ، وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ، وَمِن شَرِّ ٱلنَّفَّٰثَٰتِ فِى ٱلْعُقَدِ، وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ. 
     3 مرات'
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'بِسْمِ اللهِ الرَّحْمنِ الرَّحِيم
     قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ، مَلِكِ ٱلنَّاسِ، إِلَٰهِ ٱلنَّاسِ، مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ، ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ، مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ
     3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e4' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e4' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'أَمْسَيْـنا وَأَمْسـى المـلكُ لله وَالحَمدُ لله ، لا إلهَ إلاّ اللّهُ وَحدَهُ لا شَريكَ لهُ، لهُ المُـلكُ ولهُ الحَمْـد، وهُوَ على كلّ شَيءٍ قدير ، رَبِّ أسْـأَلُـكَ خَـيرَ ما في هـذهِ اللَّـيْلَةِ وَخَـيرَ ما بَعْـدَهـا ، وَأَعـوذُ بِكَ مِنْ شَـرِّ ما في هـذهِ اللَّـيْلةِ وَشَرِّ ما بَعْـدَهـا ، رَبِّ أَعـوذُبِكَ مِنَ الْكَسَـلِ وَسـوءِ الْكِـبَر ، رَبِّ أَعـوذُ بِكَ مِنْ عَـذابٍ في النّـارِ وَعَـذابٍ في القَـبْر. ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e5' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e5' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللّهـمَّ أَنْتَ رَبِّـي لا إلهَ إلاّ أَنْتَ ، خَلَقْتَنـي وَأَنا عَبْـدُك ، وَأَنا عَلـى عَهْـدِكَ وَوَعْـدِكَ ما اسْتَـطَعْـت ، أَعـوذُبِكَ مِنْ شَـرِّ ما صَنَـعْت ، أَبـوءُ لَـكَ بِنِعْـمَتِـكَ عَلَـيَّ وَأَبـوءُ بِذَنْـبي فَاغْفـِرْ لي فَإِنَّـهُ لا يَغْـفِرُ الذُّنـوبَ إِلاّ أَنْتَ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e6' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e6' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'رَضيـتُ بِاللهِ رَبَّـاً وَبِالإسْلامِ ديـناً وَبِمُحَـمَّدٍ صلى الله عليه وسلم نَبِيّـاً. 3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e7' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e7' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'حَسْبِـيَ اللّهُ لا إلهَ إلاّ هُوَ عَلَـيهِ تَوَكَّـلتُ وَهُوَ رَبُّ العَرْشِ العَظـيم.   7 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e8' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e8' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'بِسـمِ اللهِ الذي لا يَضُـرُّ مَعَ اسمِـهِ شَيءٌ في الأرْضِ وَلا في السّمـاءِ وَهـوَ السّمـيعُ العَلـيم. 3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e9' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e9' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللّهُـمَّ بِكَ أَمْسَـينا وَبِكَ أَصْـبَحْنا، وَبِكَ نَحْـيا وَبِكَ نَمُـوتُ وَإِلَـيْكَ الْمَصِيرُ.' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'e10' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e10' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'أَمْسَيْنَا عَلَى فِطْرَةِ الإسْلاَمِ، وَعَلَى كَلِمَةِ الإِخْلاَصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِينَا إبْرَاهِيمَ حَنِيفاً مُسْلِماً وَمَا كَانَ مِنَ المُشْرِكِينَ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e11' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e11' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللّهُـمَّ عافِـني في بَدَنـي ، اللّهُـمَّ عافِـني في سَمْـعي ، اللّهُـمَّ عافِـني في بَصَـري ، لا إلهَ إلاّ أَنْـتَ.  اللّهُـمَّ إِنّـي أَعـوذُ بِكَ مِنَ الْكُـفر ، وَالفَـقْر ، وَأَعـوذُ بِكَ مِنْ عَذابِ القَـبْر لا إلهَ إلاّ أَنْـتَ
     3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e12' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e12' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللّهُـمَّ إِنِّـي أسْـأَلُـكَ العَـفْوَ وَالعـافِـيةَ في الدُّنْـيا وَالآخِـرَة ، اللّهُـمَّ إِنِّـي أسْـأَلُـكَ العَـفْوَ وَالعـافِـيةَ في ديني وَدُنْـيايَ وَأهْـلي وَمالـي اللّهُـمَّ اسْتُـرْ عـوْراتي وَآمِـنْ رَوْعاتـي ، اللّهُـمَّ احْفَظْـني مِن بَـينِ يَدَيَّ وَمِن خَلْفـي وَعَن يَمـيني وَعَن شِمـالي ، وَمِن فَوْقـي وَأَعـوذُ بِعَظَمَـتِكَ أَن أُغْـتالَ مِن تَحْتـي. ' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e13' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e13' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'يَا حَيُّ يَا قيُّومُ بِرَحْمَتِكَ أسْتَغِيثُ أصْلِحْ لِي شَأنِي كُلَّهُ وَلاَ تَكِلُنِي إلَى نَفْسِي طَـرْفَةَ عَيْنٍ. 3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e14' ]]
    ]
    ])
    ]);
    }if($data ==  'e14' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللّهُـمَّ عالِـمَ الغَـيْبِ وَالشّـهادَةِ فاطِـرَ السّماواتِ وَالأرْضِ رَبَّ كـلِّ شَـيءٍ وَمَليـكَه ، أَشْهَـدُ أَنْ لا إِلـهَ إِلاّ أَنْت ، أَعـوذُ بِكَ مِن شَـرِّ نَفْسـي وَمِن شَـرِّ الشَّيْـطانِ وَشِـرْكِه ، وَأَنْ أَقْتَـرِفَ عَلـى نَفْسـي سوءاً أَوْ أَجُـرَّهُ إِلـى مُسْـلِم' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e15' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e15' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'أَعـوذُ بِكَلِمـاتِ اللّهِ التّـامّـاتِ مِنْ شَـرِّ ما خَلَـق
     3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e16' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e16' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ على نَبِيِّنَا مُحمَّد.
     غير مقيد بعدد' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e17' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'أسْتَغْفِرُ اللهَ َ الَّذِي لاَ إلَهَ إلاَّ هُوَ، الحَيُّ القَيُّومُ، وَأتُوبُ إلَيهِ. 3 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e19' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e19' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'لَا إلَه إلّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلُّ شَيْءِ قَدِيرِ. 10 مرات' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e20' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e20' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'سُبْحـانَ اللهِ وَبِحَمْـدِهِ.100 مرة' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'e21' ]]
    ]
    ])
    ]);
    }
    if($data ==  'e21' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
   [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    if($data ==  'u' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ليلة القدر' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
     [['text'=> 'دعاء ليلة القدر .' ,callback_data => 'uu']] ,
    [[ 'text' => 'التالي .' , callback_data => 'u1' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'جوف الليل الأخير' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ما بين الأذان والإقامة'
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'عند نزول الغيث' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
     [['text'=> 'دعاء نزول الغيث .' ,callback_data => 'uuu']] ,
    [[ 'text' => 'التالي . ' , callback_data => 'u4' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u4' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ساعة من يوم الجمعة 
( وأرجح الأقوال فيها أَنها آخر ساعة من ساعات العصر يوم الجمعة، وقد تكون ساعة الخطبة والصلاة )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
     [['text'=> 'دعاء يوم الجمعة .' ,callback_data => 'uuuu']] ,
    [[ 'text' => 'التالي . ' , callback_data => 'u5' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u5' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'عند شُرب ماء زمزم مع صدق النية' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u6' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u6' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'وقت السجود' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u7' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u7' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'عند الاستقياظ من النوم ليلاً' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u8' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u8' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'عند الدعاء بِـ: 
( لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u9' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u9' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المُسلم لأخيه المُسلم في ظهر الغيب' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي .' , callback_data => 'u10' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u10' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء يوم عرفة' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u11' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u11' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء في شهر رمضان' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
     [['text'=> 'أدعية مستحبة في شهر رمضان .' ,callback_data => 'uuuuu']] ,
    [[ 'text' => 'التالي . ' , callback_data => 'u12' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u12' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'في مجالس الذكر' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u13' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u13' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المسافر' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
     [['text'=> 'دعاء السفر .' ,callback_data => 'uuuuuu']] ,
    [[ 'text' => 'التالي . ' , callback_data => 'u14' ]]
    ]
    ])
    ]);
    }if($data ==  'u14' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المضطر' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u15' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u15' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء الولد البار بوالديه' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u16' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u16' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الدعاء بعد الوضوء' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'u17' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    if($data ==  'uu' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللهم اهدنا فيمن هديت، وعافنا فيمن عافيت، وتولنا فيمن توليت، وبارك لنا فيما أعطيت، وقنا برحمتك واصرف عنا شر ما قضيت، إنَّك تقضي ولا يُقضى عليك، إنّه لا يذِلُّ من واليت، ولا يعِزُّ من عاديت، تباركت ربنا وتعاليت، نستغفرك اللهم من جميع الذنوب والخطايا ونتوب إليك، ونؤمن بك ونتوكلُ عليك، اللهم أنتَ الغنيُّ ونحن الفقراء إليك، وأنتَ القويُّ ونحنُ الضعفاءُ اليك، اللَّهُمَّ إِنَّكَ عَفُوٌّ كَرِيمٌ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّا يا كريم' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uu1' ]]
    ]
    ])
    ]);
    }if($data ==  'uu1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'يا إله العالمين، يا مجيب دعوة المضطرين، يا من لا يزداد على السؤال إلا كرمًا وجودًا، وعلى كثرة الإلحاح إلا تفضلاً وإحساناً، نسألك مسألة المساكين، ونبتهل إليك يا ربنا ابتهال الخاضع المذنب الذليل، ندعوك دُعاء من خضعت لكَ رقبته وذلَّ لكَ جسمه ورغم لكَ أنفه وفاضت لك عيناه، يا من يجيب المضطر إذا دعاه، ويكشف السوء عمن ناداه اللهم هؤلاء عبادك، قد نصبوا وجوههم إليك، ورفعوا أكُفَّ الضراعة إليك، في هذه الليلة المباركة، اللهم فأعطهم سؤلهم، ولا تخيب رجاءنا ورجاءهم، ولا تردنا خائبين برحمتك يا أرحم الراحمين' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uu2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uu2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللهم إنَّا نسألك في هذا المقام المبارك، وفي هذه الليلة المباركة أن تكتبنا من عتقائك من النار، اللهم أعتق رقابَنا ورقابَ آبائنا وأمهاتنا وسائر قراباتنا من النار يا عزيز يا غفار' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uu3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uu3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللهم أنتَ أحقَّ من ذُكر، وأحقَّ من عبد، وأنصرُ من ابتغى، وأرأف من مَلك، وأجود من سُئل، و أوسعُ من أعطى، أنتَ الملك لا شريك لكَ، والفرد لا تهلك، كل شيء هالك إلا وجهكَ، لن تطاع ألا بأذنك، ولن تعصى إلا بعلمك، تُطاع فتشكر، وتُعصى فتغفر، أقرب شهيد، وأدنى حفيظ، أخذت بالنواصي، وكتبت الآثار، ونسخت الآجال، القلوب لك مفضية، والسرُّ عندك علانية، الحلال ما أحللت، والحرام ما حرمت، والدين ما شرعت والأمر ما قضيت، الخلق خلقكَ، والعبد عبدكَ، وأنتَ الله الرؤوف الرحيم أسألك بنور وجهك الذي أشرقت له السماوات والأرض، أن تقبلنا العشية بإحسانك وأن تُجيرنا من النار برحمتك' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العودة' , callback_data => 'u17' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }
    
    
    
    
    if($data ==  'uuu' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الدعاء عند اشتداد الريح:
 ( اللهم لقحًا لا عقيمًا )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuu1' ]]
    ]
    ])
    ]);
    }if($data ==  'uuu1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المطر كما ورد عن الرسول -عليه الصلاة والسلام : 
( عن عائشة -رضي الله عنها- أن رسول الله -صلى الله عليه وسلم- كان إذا رأى المطر قال: {صيبًا نافعًا}، ويقصد بهذا الدعاء أن يكون المطر نافعًا دافعًا للفساد والضرر' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuu2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuu2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المطر : 
(اللَّهم اسقِ بلدكَ وبهائمك، وانشُرْ رحمتك وأحيِ بلدك الميتَ اللهم اسقِنا غيثًا مغيثًا مَريئًا مُريعًا طَبَقًا واسِعًا عاجِلًا غيرَ آجلٍ نافعًا غيرَ ضار اللَّهم سُقْيا رَحمَةٍ ولا سُقْيا عذابٍ ولا هدم ولا غرَق ولا مَحْق اللَّهمَّ اسقنا الغيثَ وانصرنا على الأعداءِ)' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuu3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuu3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المطر :
(اللَّهم حوالينا ولا علينا اللهم على الآكام والظّراب وبطون الأودية ومنابت الشجر)' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العودة' , callback_data => 'u3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    if($data ==  'uuuu' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ما ورد في قوله تعالى في سورة الفرقان: 
*{رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا}*' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuu1' ]]
    ]
    ])
    ]);
    }if($data ==  'uuuu1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ماورد في قوله تعالى في سورة الشعراء:
 *{رَبِّ هَبْ لِي حُكْمًا وَأَلْحِقْنِي بِالصَّالِحِينَ* وَاجْعَلْ لِي لِسَانَ صِدْقٍ فِي الآخِرِينَ* وَاجْعَلْنِي مِن وَرَثَةِ جَنَّةِ النَّعِيمِ}*' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuu2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuu2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ما ورد في قوله تعالى في سورة الأحقاف:
 {*رَبِّ أَوْزِعْنِي أَنْ أَشْكُرَ نِعْمَتَكَ الَّتِي أَنْعَمْتَ عَلَيَّ وَعَلَى وَالِدَيَّ وَأَنْ أَعْمَلَ صَالِحًا تَرْضَاهُ وَأَصْلِحْ لِي فِي ذُرِّيَّتِي إِنِّي تُبْتُ إِلَيْكَ وَإِنِّي مِنَ الْمُسْلِمِينَ}*' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuu3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuu3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'ما ورد في قوله تعالى في سورة آل عمران:
 *{ربَّنَا اغْفِرْ لَنَا ذُنُوبَنَا وَإِسْرَافَنَا فِي أَمْرِنَا وَثَبِّتْ أَقْدَامَنَا وانصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ}*' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العودة' , callback_data => 'u4' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    if($data ==  'uuuuu' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ
' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuu1' ]]
    ]
    ])
    ]);
    }if($data ==  'uuuuu1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '*{رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا}*' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuu2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuuu2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => '{*رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِنْ ذُرِّيَّتِي رَبَّنَا وَتَقَبَّلْ دُعَاءِ * رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ}*' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuu3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuuu3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'اللّهمَّ إنّك عفوٌّ تحبُّ العفوَ فاعفُ عنّي' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العودة' , callback_data => 'u11' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }
    
    
    
    
    
    if($data ==  'uuuuuu' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'يقول المسلم إذا أراد الخروج من المنزل لسفرٍ أو لغيره ما ورد عن أنس بن مالك -رضي الله عنه- أن رسول الله -صلى الله عليه وسلم- قال:
( مَنْ قالَ - يعني إذا خرج من بيته - : باسْمِ اللَّهِ ، تَوَكَّلْتُ على اللَّهِ ، وَلاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ باللَّهِ . يُقالُ لَهُ : كُفِيتَ وَوُقِيتَ وَهُدِيتَ ، فَتَتَنَحَّى لَهُ الشَّيَاطِينُ ، فَيَقُولُ لَهُ شَيطَانٌ آخَرُ : كَيْفَ لَكَ بِرَجُلٍ قَدْ هُدِيَ وكُفِيَ وَوُقِيَ ) ؟
' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuuu1' ]]
    ]
    ])
    ]);
    }if($data ==  'uuuuuu1' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المسافر للمقيم: 
( أَسْتَوْدِعُكُمُ اللَّهَ الَّذِي لاَ تَضِيعُ وَدَائِعُهُ )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuuu2' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuuuu2' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المقيم للمسافر:
 ( أَسْتَوْدِعُ اللَّهَ دِينَكَ، وَأَمَانَتَكَ، وَخَوَاتِيمَ عَمَلِكَ"، ويقول أيضًا: "زَوَّدَكَ اللَّهُ التَّقْوَى، وَغَفَرَ ذَنْبَكَ، وَيَسَّرَ لَكَ الخَيْرَ حَيْثُ ما كُنْتَ )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuuu3' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuuuu3' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'الذِكر أثناء السفر:  
الإكثار من التكبير والتسبيح، قَالَ جَابِرٌ رضي الله عنه :
 ( كُنَّا إِذَا صَعَدْنَا كَبَّرْنَا، وَإِذَا نَزَلْنَا سَبَّحْنَا )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'التالي . ' , callback_data => 'uuuuuu4' ]]
    ]
    ])
    ]);
    }
    if($data ==  'uuuuuu4' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     'text' => 'دعاء المسافر إذا أسحر:
 ( سَمَّعَ سَامِعٌ بِحَمْدِ اللَّهِ، وَحُسْنِ بَلاَئِهِ عَلَيْنَا، رَبَّنَا صاحِبْنَا، وَأَفْضِلْ عَلَيْنَا، عَائِذاً بِاللَّهِ مِنَ النَّارِ". دعاء المسافر إذا نزل منزلًا: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ )' 
     ,
     
     reply_markup =>json_encode([
     inline_keyboard =>[
    [[ 'text' => 'العودة' , callback_data => 'u13' ]]
    ]
    ])
    ]);
    }
    if($data ==  'u17' ){
    bot( editMessageText ,[
     chat_id =>$chat_id2,
     'message_id'=>$message_id,
     
     text => 
     
     "- /start
     "
     
     ,
     reply_markup =>json_encode([
     inline_keyboard =>[
    [['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
    
    
    ]
    ])
    ]);
    }



if($data=="kottobeslameah"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الكتب  الاسلاميه 🎁🕋

 - اختر اسم القسم من الاسفل وساقوم بتحويلك الكتب المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"زاد المستقنع في شرح العبادات",'callback_data'=>'mktbttt'],['text'=>"كتب الشيخ الشعراوي",'callback_data'=>'kttbsh3rawe']],
[['text'=>"كتب الإمام ابن كثير",'callback_data'=>'bnktherkotob'],[ 'text' => 'كتب التفسير',callback_data => 'tf' ]],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data=="mktbttt"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الكتب الاسلاميه والدينيه ، 🗂'

- اختر اسم الكتاب من الاسفل وساقوم بارساله لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"فهرس شرح كتاب الصلاة",'callback_data'=>'ktaabslah'],['text'=>"الكتاب كامل زاد المستنقع",'callback_data'=>'zadelmstng3']],
[['text'=>"الزكاه",'callback_data'=>'zzkaht'],['text'=>"الصلاة",'callback_data'=>'sslatg']],
[['text'=>"الجهاد",'callback_data'=>'gjehadd']],
[['text'=>"الصيام",'callback_data'=>'somktab'],['text'=>"الجنائز",'callback_data'=>'gjnazatktab']],
[['text'=>"المناسك",'callback_data'=>'mnassek']],
[['text'=>"البيع",'callback_data'=>'zadbe3'],['text'=>"اصناف الربا",'callback_data'=>'zadbe32']],
[['text'=>"الطهاره",'callback_data'=>"tharhzad"]],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="kttbsh3rawe"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الكتب الاسلاميه والدينيه ، 🗂'

- اختر اسم الكتاب من الاسفل وساقوم بارساله لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"القضاء والقدر",'callback_data'=>'gthsh3rawe'],['text'=>"نهاية العالم",'callback_data'=>'endworsh3rawe']],
[['text'=>"قصص الانبياء للشعراوي",'callback_data'=>'shqssrawe'],['text'=>"قصص الانبياء 2",'callback_data'=>'shqssrawe2']],
[['text'=>"قصص الصحابه للشعراوي",'callback_data'=>'shqssrawe3']],
[['text'=>"أسماء الله الحسنى",'callback_data'=>'asmaallahsh'],['text'=>"الله والنفس البشريه",'callback_data'=>'allahwelbshr']],
[['text'=>"موسوعة فتاوي الشعراوي",'callback_data'=>'mososh3rawe']],
[['text'=>"فقه المرأة المسلمة",'callback_data'=>'fghmahsh3rawe'],['text'=>"االسحر والحسد",'callback_data'=>'s7rsh3rawe']],
[['text'=>"البعد الحجاجي للتأويل في الخطاب الديني",'callback_data'=>"7h6abah3rwe"]],
[['text'=>"منهج الشعراوي في الاستدلال بالأحاديث",'callback_data'=>"mnhgjsh3rawe"]],
[['text'=>"التوبه1",'callback_data'=>'ettobh1'],['text'=>"التوبه2",'callback_data'=>'etoobh2']],
[['text'=>"الإسراء والمعراج",'callback_data'=>'m3ragjsh3'],['text'=>"أنبياء الله",'callback_data'=>'anbeaash3rawe']],
[['text'=>"١٠٠ سؤال وجواب في الفقه الإسلامي",'callback_data'=>'wonsh3rae']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="bnktherkotob"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الكتب الاسلاميه والدينيه ، 🗂'

- اختر اسم الكتاب من الاسفل وساقوم بارساله لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"اختصار علوم الحديث",'callback_data'=>'bnkther3lmo'],['text'=>"الأحكام الكبرى لإبن كثير",'callback_data'=>'bnkthera7kam']],
[['text'=>"فضائل القرآن",'callback_data'=>'fdaelbnkthr'],['text'=>"قصص الأنبياء",'callback_data'=>'anbbnkther']],
[['text'=>"معجزات الرسول صلى الله عليه وسلم",'callback_data'=>'m3gjzbnkher']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data == "ktaabslah"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/57",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "zadelmstng3"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/58",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "zzkaht"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/59",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sslatg"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/60",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "gjehadd"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/61",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "somktab"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/62",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "gjnazatktab"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/63",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mnassek"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/64",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "zadbe3"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/65",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "zadbe32"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/66",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "tharhzad"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/67",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "gthsh3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/68",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "endworsh3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/69",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "shqssrawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/70",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "shqssrawe2"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/71",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "shqssrawe3"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/72",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "asmaallahsh"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/73",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "allahwelbshr"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/74",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mososh3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/75",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "fghmahsh3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/76",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "s7rsh3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/77",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "7h6abah3rwe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/78",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mnhgjsh3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/79",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ettobh1"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/80",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "etoobh2"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/81",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "m3ragjsh3"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/82",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "anbeaash3rawe"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/83",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "wonsh3rae"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/84",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "m3gjzbnkher"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/85",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "bnkther3lmo"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/86",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "bnkthera7kam"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/87",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "fdaelbnkthr"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/88",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "anbbnkther"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/89",
reply_to_message_id =>$message->message_id, 
]);
}




if($data=="olomq"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

- اختر احد الاقسام من الاسفل 

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[[ 'text' => 'قسم التفسير',callback_data => 'tf' ]],
[['text'=> 'مواقيت الصلاة.' ,callback_data => 'salwaty'],[ 'text' => 'صفحه من القران .',callback_data => 'safhaq' ]],
[['text'=> 'لعشاق الايباحيات' ,callback_data => 'sexy']],
[['text'=> 'اخطاء شائعه' ,callback_data => 'aktaa'],[ 'text' => 'نواقض الاسلام',callback_data => 'nwaketh' ]],
[[ 'text' => 'العوده',callback_data => 'rj03' ]],
]])]);}

##صل على رسول الله

if($data=="sexy"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
 إلى كل من يشاهد الأفلام الإباحية إنها نصيحة لله ::
لا أكثر ولا أقل 
1-هل تعلم أن ما تشاهده من صور عارية من الكبائر.
2-هل تعلم أن مشاهدة هذه المناظر تورث الذل والضعف .
3- هل تعلم أن مشاهدة هؤلاء الزناة تجعلك صغيرا في أعين الناس .
4-هل تعلم أن تلك المعصية تسقط العبد من عين الله.
5-هل أستقر في ذهنك صورة هؤلاء الزناة (هذا غضب من الله)
وكلنا يذكر قصة عابد بني إسرائيل الذي دعت عليه أمه أن يرى فقط (وجوه المومسات).
6-هل تعلم أن مشاهدة تلك المناظر يجعلك تخاف من أبسط الأمور .
7-هل تعلم انك لن تحصل علم إن كنت تشاهد هذا العري .
8-هل تعلم أنك ستحرم من عيش حياة زوجية هانئة مع زوجة تحبها وتحبك.
9-هل تعلم ان هذا الفعل الشنيع الذي تقوم به يجعل الصالحون يبغضونك؛ حتى وإن لم تقص لهم ما تفعل.
10-هل تعلم أنه واجب أن تنظر إلى هؤلاء الزناة ؛لكن عندما يرجمون حتى الموت.
11-هل تعلم أن كل ما شاهدته ستدفع ثمنه غاليا ؛ان لم تتوب إلى الله ؛وأن الله عزيز ذو أنتقام .
12-هل ترضى أن يأتي إليك خبر موت أحد تحبه؛ وأنت جالس على تلك المواقع .
13-هل تعلم أن من قبح هذه المعصية ؛من الممكن أن يخسف الله بك الأرض .
14-هل تعلم أنه من الممكن أن تموت على هذا الوضع (سوء خاتمة).
15-ربك حليم ؛يتركك؛لكن لا تفرح بهذا ؛فلا بد من دفع الثمن ؛ولو بعد حين إن لم تتوب.
16-هل تعلم أن من ترك شيئا لله ؛عوضه خيرا منه.
17-هل تعلم أن الله الغني الحميد يفرح بتوبة عبده.
18-هل تعلم أن الله سيغنيك من فضله إن أستعففت أخيرا ؛قارن نفسك بمن يجاهد في سبيل الله ؛وادرس جيدا سير الصحابة العظماء ؛وسير الصالحين ؛وأعلم أن هناك عبادا لله الآن يتقوه حق تقاته؛كل هذا وأنت تحارب رب العالمين 
بالمعاصي 
ولا تجعل (الشاشات) كمبيوتر؛ وتلفون ؛يكونوا سببا في خزي الدنيا ؛
وعذاب الآخرة.
إنك بعد نزول القبر تأكل عيناك ؛وتبقى هذه الصور الذي شاهدتها ؛وتكون حسرات عليك إن لم تتوقف ؛وتتوب إلى الله رب العالمين .
أنشره ليكون في ميزان حسناتك  
ليستفيد غيرك و تكسب الأجر
",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"العودة 🔙",'callback_data'=>"olomq"]],
]])]);}

if($data=="safhaq"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

- لجلب صفحة من القران فقط ارسل الامر .
- صفحة + رقمها مثال ~ صفحة 6 .
- سيقوم البوت باارسال الصفحه اليك .
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"olomq"]],
]])]);}


if($data=="aktaa"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

- انتبه اخي المسلم من هذه الاخطاء التي يقع بها الجميع 

1 - قول انشاء الله والجائز قول ان شاء الله 
2 - قول لاحول الله والجائز قول لا حول ولا قوة الا بالله
3 - قول اللهم صلي على محمد والجائز قول اللهم صلِّ على محمد 
4 - قول وحق الكعبه والجائز قول ورب الكعبه 
5 - قول ومحمد قسما والجائز قول ورب محمد 
6 - احذر الحلف بغير الله 

 قال صلى الله عليه وسلم 
*ان الشخص ليقول الكلمه يهوي بها في جهنم سبعين خريفا*
فاحذر اخي / اختي المسلم/ه

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"olomq"]],
]])]);}


if($data=="nwaketh"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

- اضغط على احد الازرار

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=> 'الناقض الاول' ,callback_data => 'nwaketh1'],[ 'text' => 'الناقض الثاني',callback_data => 'nwaketh2' ]],
 [['text'=> 'الناقض الثالث' ,callback_data => 'nwaketh3'],[ 'text' => 'الناقض الرابع',callback_data => 'nwaketh4' ]],
 [['text'=> 'الناقض الخامس' ,callback_data => 'nwaketh5'],[ 'text' => 'الناقض السادس',callback_data => 'nwaketh6' ]],
 [['text'=> 'الناقض السابع' ,callback_data => 'nwaketh7'],[ 'text' => 'الناقض الثامن',callback_data => 'nwaketh8' ]],
 [['text'=> 'الناقض التاسع' ,callback_data => 'nwaketh9'],[ 'text' => 'الناقض العاشر',callback_data => 'nwaketh10' ]],
 [['text'=>"العودة 🔙",'callback_data'=>"olomq"]],
]])]);}


if($data=="nwaketh1"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

🔰الناقض الاول

▫️النوع الاول:الـشِـرك الأكـبـر

الشرك الاكبر لا يغفره الله الا بالتوبة
وان لقي الله قبل التوبة فان جزائه جهنم خالدا مخلدا

وللشرك الاكبر انواع كثيرة, مدارها على اربعة انواع سنذكرها مفصلة مع الدليل على ان تكون المنشورات قصيرة ومفيدة.

1_شرك الدعوة:
دليله قوله تعالى: (فإذا ركبوا في الفلك دعوا الله مخلصين له الدين فلما نجاهم الى البر اذا هم يشركون)

2_شرك النية والارادة والقصد:
دليله قوله تعالى: (من كان يريد الحياة الدنيا وزينتها نوَّف اليهم اعمالهم فيها وهم فيها لا يُبخسون ● اولئك الذين ليس لهم في الاخرة الا النار وحبط ما صنعوا فيها وباطل ما كانوا يعملون )

⇐شرك النية شرك اكبر محمول على من كانت جميع اعماله مستقصدا بها غير وجه الله
اما من طرأ عليه الرياء فانه شرك اصغر.

3_شرك الطاعة :
دليله قوله تعالى: (اتَّخَذُوا أحبارَهُم ورُهبانَهُم أرْبابًا مِن دونِ اللهِ والمَسيحَ ابنَ مَريَمَ وما أُمِرُوا إلَّا لِيَعْبُدوا إلٰهًا واحِدًا لا إلٰه إلَّا هوَ سُبحَانَهُ عَمَّا يُشرِكُون)

قال شيخُ الإسلامِ ابنُ تيميةَ - رحمهُ الله - :

« وهؤلاءِ الَّذينَ اتَّخَذوا أحبارَهم ورُهبانَهم أربابًا، حيثُ أطاعوهم في تحليل ما حرَّم الله وتحريمِ ما أحلَّ الله، يكونون على وجهيْنِ :

• أحدُهما : أن يعلَموا أنَّهم بدَّلوا دينَ الله، فيتَّبِعوهم على التَّبديلِ، فيعتَقِدون تحليلَ ما حرَّم الله وتحريمَ ما أحلَّ الله، فهذا كُفــرٌ

• الثاني : أن يكونَ إيمانهم بتحريم الحرام وتحليل الحلال ثابتًا، لكنهم أطاعوهم في معصية الله، كما يفعل المسلمُ ما يفعلُه مِن المعاصي التي يعتقِدُ أنها معاصٍ؛ فهؤلاءِ لهم حُكمُ أمثالِهم مِن أهلِ الذنوبِ ».

[ مجموعُ الفتاوى || (٧٠/٧) ]

4_شرك المحبة :
دليله قوله تعالى: (ومن الناس من يتخذ من دون الله اندادا يحبونتم كحب الله)


فالمُشرِكُ تجِدُه يحبُّ الآلهة من الأصنام وغيرها كحُبِّ الله وأعظم من ذلك، تجدُه إذا انتُهِكَتْ يَغضَبُ لها أعظم مما يغضبُ لله، ويستبشر لها ما لا يستبشِرُ لله.

⇦ ومِنَ الشِّركِ الأكبَرِ أيضًا : الذبحُ لغيرِ الله، لأنَّ الذبحَ لله قُربةٌ له مِن أجَلِّ القرُبات؛ كما قال تعالى : ﴿فصَلِّ لربِّك وانحَر﴾

فمَن ذبحَ للأولياء أو للأصنام أو للجن فقد خرجَ عن الإسلام، ودخلَ في دائرة الكفر والضلال.

⇦ ومِن ذلك : النَّذْرُ لغيرِ الله : فهو شركٌ أكبر، لأنَّ النَّذرَ عبادة، كما قال تعالى : ﴿يُوفُونَ بالنَّذْرِ﴾

فمن نذَرَ لوليٍّ اللحوم وغيرها فقد خلعَ ربقة الإسلام من عنُقِه، فما يفعلُه عُبَّاد القبور من النذر لمن يعتقدون فيه ضرًا أو نفعًا شركٌ أكبر مُخرِجٌ من الإسلام.

⇦ ومن ذلك : الاستعاذة والاستغاثة : كلُّ ذلك صرفُه لغيرِ الله شِركٌ.

وهنا انتهينا من الشرك الاكبر
-----------------------------------
▫️النوع الثاني:الـشِـرك الاصغر

وصاحبه إن لقِيَ الله به، فهو تحت المشيئة على القولِ الصحيح إن شاء عفا عنه، وإن شاء عذَّبه، ولكنَّ مآلَه إلى الجنة؛ لأنَّ الشركَ الأصغر لا يخلد صاحبَه في النارِ، ولكنَّه مُعرَّضٌ للوعيد، فيجبُ الحذرُ منه.

• ومِن أنواعِ الشرك الأصغر: الحلفُ بغيرِ الله: إن لم يقصد تعظيمَ المَحلوفِ به؛ وإلا صارَ شِركًا أكبر.

وقد قال النبي ﷺ: « مَن حلف بغيرِ الله فقد كفرَ أو أشرك ».

• ومنه : يسيرُ الرِّياء والتَّصنُّع للخَلق :

وقد قال النبي ﷺ: « أخوف ما أخاف عليكم الشرك الأصغر، فسُئِلَ عنه؟ فقال: الرِّياء ».

فإذا كان الشركُ الأصغر مخوفًا على الصحابة الذين مع النبي ﷺ؛ فعلى غيرهم من باب أولى.

↫ والعمل لغير الله له حالات :

الحالة الأولى : أن يكون رياءً محضًا، فلا يريد صاحبه إلا الدنيا، أو مراآة المخلوقين؛ كالمنافقين الذين قال الله فيهم : ﴿ وإذا قاموا إلى الصلاةِ قاموا كُسالى يُراءونَ الناسَ ولا يَذكُرُونَ اللهَ إلا قليلًا ﴾
فهذا العمل حابط، يستحق صاحبه المقت من الله.

الحالة الثانية : أن يكون العمل لله، ويشاركه الرياء، فهذا له حالتان :

أ- إما أن يشاركه الرياء من أصله.
ب- وإما أن يطرأ عليه.

فأما الأول : فالعمل حابط لا يُقبَل، لقوله ﷺ: « قال الله تعالى: أنا أغنى الشركاء عن الشرك، من عمل عملًا أشرك معي فيه غيري؛ تركته وشركه »
.

وأما إن طرأ عليه الرياء، واسترسل معه : فبعض العلماء يبطله بالكلية، وبعض العلماء يقول : إن استرسل معه فله أجر إخلاصه وعليه وزر الرياء، وأما أن جاهده ودفعه فهذا له نصيب من قوله تعالى : ﴿ وأما من خاف مقامَ ربهِ ونهى النفسَ عنِ الهوى • فإنَّ الجنةَ هيَ المأوى ﴾.


[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh2"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰️شرح الناقض الثاني:
  
  قال الشيخ ابن عبدالوهاب رحمه الله :
  
  « مَن جعلَ بينَه وبين الله وسائِط؛ يدعُوهم ويسألُهم الشفاعة، ويتوكَّلُ عليهم؛ كفرَ إجماعًا ».
  
  أقولُ : إنَّ هذا الناقضَ من أكثر النواقض وقوعًا وأعظمِها خطرًا، لأنَّ كثيرًا ممن يتسمَّى باسم الإسلام جعلَ بينه وبين الرب وسائط يسألونهم جَلب المنافع ودَفعَ المَضار، وهؤلاء كفَّارٌ بإجماع المسلمين؛ لأنَّ الله ما أنزل الكتب وأرسل الرسل إلا ليعبدوه وحده لا شريك له، ولكن أبى ذلك عباد القبور..
  
  ← قال تعالى : ﴿ولا تَدْعُ مِن دونِ الله ما لا يَنفَعُك ولا يضُرُّك فإن فعلتَ فإنَّك إذًا مِنَ الظَّالِمين • وإن يَمْسَسْكَ اللهُ بِضُرٍ فلا كاشِفَ له إلَّا هو وإن يُرِدْكَ بخيرٍ فلا رادَّ لِفَضْلِه﴾
  
  ← وقال ﷺ : « احفظ الله يحفظك، احفظ الله تجِدْهُ تُجاهَك، وإذا سألْتَ فاسألِ الله، وإذا استعنتَ فاستعِنْ بالله ».
  
  والمُشرِكون في قديمِ الدَّهْرِ وحديثِه إنَّما وقعوا في الشركِ الأكبر لتعلُّقِهم بأذيالِ الشَّفاعةِ.

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh3"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح الناقض الثالث:
  
  شرح الشيخ سليمان العلوان
  
  قال رحمه الله :
  
  « مَن لم يُكَفِّر المُشركين أو شكَّ في كُفرهم أو صحَّح مذهبَهم ».
  
  لأنَّ الله ﷻ كفَّرهم في آياتٍ كثيرة من كتابِه، وأمرَ بعداوتِهم لافترائهم الكذب عليه، ولجعلهم شركاء مع الله، وقد افترض الله ﷻ على المسلمين مُعاداتهم وبُغضَهم.
  
  أمَّا مَن صحَّح مَذهبَهم، واستَحسَنَ ما هم عليه من الكفر والطغيان، فهذا كافرٌ بإجماع المُسلمين؛ لأنه لم يَعرف الإسلام على حقيقتِه، وهو : « الاستسلام لله بالتوحيد، والانقياد له بالطاعة، والبراءة من الشرك وأهله ».
  
  وقد قال ﷺ : « مَن قال لا إله إلا الله، كفر بما يُعبَد من دون الله، حرم ماله ودمه، وحسابه على الله ».
  
  وقال تعالى : ﴿فمَن يكفُر بالطَّاغوت ويؤمن بالله فقد استَمسَك بالعُروَةِ الوُثقى﴾
  
  قال الإمام محمد بن عبد الوهَّاب : « وصِفةُ الكفر بالطاغوت : أن تعتقد بُطلان عبادةِ غير الله، وتترُكَها، وتُبغِضَها، وتكفِّرَ أهلَها وتُعاديهم ».

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh4"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰 الناقض الرابع:
  
  شرح الشيخ سليمان العلوان
  
  « ومَن اعتقدَ أنَّ غير هديَ النبي ﷺ أكمل من هديه، أو أنَّ حكمَ غيره أحسن من حكمه؛ كالذي يُفضِّل حكمَ الطواغيت على حُكمِه ».
  
  #المسألة_الاولى:
  
  أمَّا المسألةُ الأولى، وهي : « مَن اعتقدَ أنَّ غير هديَ النبي ﷺ أكمل من هديه »، فهي مسألةٌ عظيمة خطيرة، تُردي بمعتقِدِها إلى الجحيم.
  
  وقد كان النبي ﷺ يقولُ : « أمَّا بعد؛ فإنَّ خيرَ الحديث كتاب الله، وخير الهدي هدي محمد ».
  
  ولا شك أنَّ هدي محمد ﷺ أكمل الهدي لأنه وحي يوحى إليه، كما قال الله ﷻ : ﴿إن هوَ إلَّا وَحيٌ يُوحَى﴾
  
  ← ولذلك أجمعَ العلماءُ على أنَّ السُّنة هي الأصلُ الثاني مِن أصول التشريعِ الإسلامي، وأنَّها مُستقِلَّة بتشريعِ الأحكام، وهي كالقرآن في التحليل والتحريم.
  
  #المسألة_الثانية:
  
  وأمَّا المسألةُ الثانية، وهي : « مَن اعتقدَ أنَّ حُكمَ غيره أحسنُ من حُكمِه، كالَّذي يُفَضِّل حُكمَ الطواغيت على حُكمِه »، فهذا كافرٌ بإجماعِ أهلِ العلم، لتَفضِيلهم أحكامَ أُناسٍ مثلِهم على حُكم رسولِ ربِّ العالمين، الَّذي بعثَه الله هُدًى للعالَمين.
  
  والحُكمُ بما أنزلَ الله واعتقادُ أنَّ حكم الرسول أحسن من حكم غيره، مِن مُقتضات شهادة أن لا إله إلا الله، لأنَّ الانقيادَ شرطٌ مِن شروطِ هذه الكلمة العظيمة.
  
  ويدخلُ فيما تقدَّم مِن الكفرِ والضَّلال قول مَن يقول: إنَّ إنفاذ حكمِ الله في رجمِ الزَّاني المُحصن وقطع يد السَّارِق لا يُناسِب هذا العصر الحاضر؛ فزماننا قد تغير عن زمن الرسول والدول الغريبة تعيبنا في هذا!! فهذا المَارِقُ قد زعمَ أنَّ حكمَ أهل هذا العصر أحسن من حُكم النبي ﷺ وأهدى سبيلًا.
  
  وكذلك يدخل في ذلك مَن قال: إنه يجوز في هذا العصر الحكم بغير ما أنزل الله!! لأنه قد استحلَّ محرمًا مُجمَعًا على تحريمِه. واللهُ أعلم.
  

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh5"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح️ الناقض الخامس:
  
  شرح الشيخ سليمان العلوان
  
  « مَن أبغضَ شيئًا مِمَّا جاء به الرسول ﷺ ولَوْ عملَ به؛ كفَر ».
  
  وبُغضُ شيءٍ مما جاء به الرسول ﷺ سواءً كان من الأقوال أو الأفعال، نوعٌ مِن أنواع النفاق الاعتقادي الذي صاحبه في الدرك الأسفل من النار.
  
  فمن ذلك كراهية البعضِ لتعدُّد الزوجات، فهم بذلك يُحاربون الله ورسوله ويردُّون على اللهِ أمرَه..
  
  وهؤلاءِ كفَّارٌ، وإن عملوا بمدلول النص، فهم لم يَستَكمِلوا شروط ( لا إله إلا الله )؛ لأنَّ مِن شروطِها المحبة لما دلَّت عليه.
  
  قال تعالى حاكِمًا بكُفرِ مَن كَرِه ما أنزلَ على رسولِه : ﴿والَّذينَ كفَرُوا فَتَعْسًا لَهم وأَضَلَّ أعمالَهُم• ذلك بأنَّهُم كَرِهُوا ما أَنزَلَ الله فأحبَطَ أعمالَهُم﴾
  
  ومِمَّا ينبغي التنبه عليه أنَّ كثيرًا مِن الناس قد تبين له منكرًا ما فيرفض القبول، فهذا لا يطلق عليه أنه مُبغِض لما جاء به الرسول دون تفصيل، لأنه قد لا يقبل الحق لا لأنه حق، ولكن لسوء تصرفك في الأمر بالمعروف والنهي عن المنكر.
  
  وهناك مِن الناس من يُلزِمُ صاحبَ المعصية بما لا يَلزَم، فيقول لهم : لولا أنكم تُبغضون ما جاء به محمد ﷺ لما فعلتُم هذه المنكرات.
  
  وهذا إلزامٌ باطِل؛ فهناك مِن الصحابة مَن حصلت منه بعض المخالفات - كشرب الخمر مثلًا - ولم يلزمه أحد من الصحابة بذلك الإلزام، وإلزامُهم بذلك يقتضي إخراج أهل الكبائر مِن الإسلام، وهذا مُخالف لمُعتَقد أهل السنة والجماعة في أنَّ أهل الكبائر تحت المشيئة، 
  
  والله أعلم.

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh6"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح️ الناقض السادس:
  
  شرح الشيخ سليمان العلوان
  
  « مَن استهزأ بشيءٍ مِن دين الرسول ﷺ أو ثوابه أو عقابِه كفرَ؛ والدليلُ قوله تعالى : ﴿قُل أَبِاللهِ وءاياتِهِ ورَسُولِه كُنتُمْ تَستَهْزِءونَ • لا تَعْتَذِرُوا قَد كفَرْتُم بعدَ إيمانِكُم﴾ ».
  
  الاستهزاء بشيءٍ مما جاءَ به الرسولُ ﷺ كُفرٌ بإجماعِ المسلمين، ولو لَم يقصد حقيقة الاستهزاء؛ كما لو هزلَ مازِحًا.
  
  فقولُهم : « إنما كنا نخوضُ ونَلعب » أي : إننا لم نقصد حقيقة الاستهزاء وإنما قصدنا الخوض واللعب، ومع ذلك كفَّرهم الله ﷻ لأنَّ هذا الباب لا يدخلُه الخوضُ واللعب، فهُمْ كفروا بهذا الكلام، مع أنهم كانوا من قبل مؤمنين.
  
  وقد قسَّمَ بعضُ أهلِ العلم الاستهزاء إلى قسمين :
  
  ١. الاستهزاء الصَّريح؛ كالَّذي نزَلَتْ فيه الآية.
  ٢. غيرُ الصريح؛ كالرمز بالعين، وإخراج اللسان، ومد الشفة، والغمزة باليد عند تلاوة كتاب الله أو سنة رسول الله ﷺ أو عند الأمر بالمعروف والنهي عن المنكر.
  
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh7"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح ️الناقض السابع: 
  
  شرح الشيخ سليمان العلوان
  
  « السِّحر، ومنه الصَّرف والعَطف، فمن فعله أو رضي به كفَر، والدليل قولُه تعالى : ﴿وما يُعَلِّمانِ مِن أحَدٍ حتَّى يقُولا إنَّما نحنُ فِتنَةٌ فلا تَكفُر﴾ ».
  
  السِّحرُ في الشَّرعِ : عُقَدٌ ورُقَى يتوصَّل بها الساحر إلى استخدام الشياطين لتضر المسحور.
  
  وقيل في تعريفه غير ذلك..
  
  ⇦ ومِنَ السحر الصرف والعطف :
  
  فالصرف : صرف الرجل عما يهواه؛ كصرفِه مثلًا عن محبةِ زوجتِه إلى بُغضِها.
  
  والعطفُ : عمل سحري كالصرف، ولكنه يعطف الرجل عما لا يهواه إلى محبتِه بطُرقٍ شيطانية.

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh8"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح الناقض الثامن:
  
  شرح الشيخ سليمان العلوان
  
  « مُظاهرةُ المشركين ومعاونتهم على المسلمين، والدليل قوله تعالى : ﴿ومَن يتولَّهم منكم فإنه منهم إنَّ الله لا يهدي القومَ الظالمين﴾ ».
  
  قوله : المُظاهرة ، أي : المُناصَرة.
  
  ثمَّ اعلم أنَّ إعانةَ الكفار تكون بكل شيءٍ يستعينون به ويتقوّون به على المسلمين من عَدَدٍ وعُدَد.

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh9"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح الناقض التاسع: 
  
  شرح الشيخ سليمان العلوان
  
  « مَن اعتقد أنَّ بعض الناس يسعه الخروج عن شريعة محمد ﷺ كما وسع الخضر الخروج عن شريعة موسى ﷺ فهو كافِر ».
  
  فمن رغب الخروج عن شريعة محمد ﷺ أو ظنَّ الاستغناء عنها فقد خلع ربقة الإسلام من عنُقِه، فإنه قد عُلِمَ بالاضطرار من دين الإسلام أنَّ رسالة محمد بن عبد الله ﷺ لجميع الناس، عربهم وعجمهم، وملوكهم وزهادهم، وعلمائهم وعامتهم، وأنها باقيةٌ دائمةٌ إلى يوم القيامة، بل عامة الثقلين الجن والإنس، وأنه ليس لأحد من الخلائق الخروج عن متابعته، بل لو كان الأنبياء المتقدمون قبله أحياء لوجب عليهم متابعته؛ فقد ثبت بالأحاديث الصحيحة أنَّ المسيح عيسى بن مريم إذا نزل إلى السماء فإنه يكونُ مُتَّبِعًا لشريعةِ محمد بن عبد الله ﷺ.
  
  فإذا كان ﷺ يجبُ اتِّباعُه ونصره على مَن يُدركُه من الأنبياء، فكيف بمن دونهم ؟!
  
  وقصة الخضر ليس فيها خروج عن الشريعة، ولهذا لما بين الخضر لموسى الأسباب التي فعل لأجلها ما فعل، وافقَه موسى ولم يختلفا حينئذٍ، ولو كان فعله الخضر مُخالِفًا لشريعةِ موسى لما وافقَه.
  
  ولهذا يتبين أنه لا يجوز لأحدٍ أن يدَّعي الخروج عن شريعة محمد ﷺ كما يدعيه غُلاة الصوفية، ويفسرون قوله تعالى : ﴿واعبُد ربَّك حتى يأتيك اليقين﴾ أي : العلم والمعرفة، ويُجوِّزون لمن حصل عنده علم ومعرفة الخروج عن شريعة محمد ﷺ، ويُسقِطون عنه التكاليف، وهذا كفرٌ وخروجٌ عن الإسلام باتفاق العلماء.

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}

if($data=="nwaketh10"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

  🔰شرح الناقض العاشر: 
  
  شرح الشيخ سليمان العلوان
  
  « الإعراضُ عن دينِ الله تعالى، لا يتعلَّمُه ولا يعملُ به، والدليلُ قولُه تعالى : ﴿ومَن أظلَمُ مِمَّن ذُكِّرَ بِئايٰتِ ربِّه ثمَّ أعرَضَ عنها إنَّا مِنَ المُجرمينَ مُنتَقِمُون﴾ ».
  
  والمُرادُ بالإعراضِ الذي هو ناقِضٌ مِن نواقضِ الإسلام: هو الإعراضُ عن تعلُّم أصل الدين الذي به يكونُ المرءُ مُسلِمًا، ولو كانَ جاهِلًا بتفاصيل الدين، لأنَّ هذا لا يقومُ به إلا العلماء وطلبة العلم.
  
  قال الشيخ العلامة سليمان بن سحمان: « فتبيَّن من كلام الشيخ أن الإنسان لا يكفر إلا بالإعراض عن تعلم الأصل الذي يدخل به الإنسانُ في الإسلام، لا بترك الواجبات والمستحبات ».
  
  وقال ابن القيم رحمه الله: « وأمَّا كفرُ الإعراض فأنه يُعرض بسمعه وقلبه عن الرسول، لا يصدِّقه ولا يكذِّبه، ولا يواليه ولا يعاديه، ولا يصغي إلى ما جاء به البتة.

[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"العودة 🔙",'callback_data'=>"nwaketh"]],
]])]);}





if($data=="Omewaabe"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الوالدين ، ❤️'

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"قصص ودروس",'callback_data'=>'dross'],['text'=>"كتب عن بر الوالدين",'callback_data'=>'kotobwalden']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

/*
تنفيذ القصص
*/


if($data=="dross"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص النساء القران الكريم ، 🗂'

- اختر اسم القصه من الاسفل وساقوم بارسالها لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"الشيخ سعد العتيق",'callback_data'=>'el3tegg'],['text'=>"الدكتور عمر عبد الكافي",'callback_data'=>'elkafii']],
[['text'=>"الشيخ محمد العريفي",'callback_data'=>'3rreeffi'],['text'=>"الدكتور محمد راتب النابلسي",'callback_data'=>'nabolsie']],
[['text'=>"الشيخ بدر المشاري",'callback_data'=>'bdrelmshare']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="el3tegg"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص الشيخ سعد العتيق

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"محاظره عن بر الوالدين",'callback_data'=>'qsselwalden'],['text'=>"محاظره عن بر الوالدين 2",'callback_data'=>'qsselwalden2']],
[['text'=>"كيف ابر والدي",'callback_data'=>'berrwlden']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="elkafii"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص الشيخ  الدكتور عمر عبد الكافي

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"محاظره عن بر الوالدين",'callback_data'=>'m7thrah'],['text'=>"عن بر الوالدين",'callback_data'=>'berr332']],
[['text'=>"عقوق الوالدين",'callback_data'=>'3qoqwalden']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="3rreeffi"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص الشيخ  الدكتور محمد العريفي

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"فضل بر الوالدين",'callback_data'=>'fthlelwlden'],['text'=>"خطبة بر الوالدين",'callback_data'=>'7h6bah']],
[['text'=>"قصص عن بر الوالدين",'callback_data'=>'qsqseat']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="nabolsie"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص الشيخ  الدكتور محمد راتب النابلسي

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"قصص واقعيه",'callback_data'=>'waq3eay']],
[['text'=>"عن بر الوالدين فيديو",'callback_data'=>'gssvied']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="bdrelmshare"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص الشيخ  الدكتور بدر المشاري

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"محاضره عن بر الوالدين",'callback_data'=>'brrr54']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data=="kotobwalden"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الخاص عن بر الوالدين ، 🗂'

- اختر اسم الكتاب من الاسفل وساقوم بارساله لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"أحكام بر الوالدين محمد المنجد",'callback_data'=>'elmngad'],['text'=>"موسوعة النابلسي بر الوالدين",'callback_data'=>'knblse']],
[['text'=>"مختصر بر الوالدين",'callback_data'=>'hnnaeio'],['text'=>"بر الوالدين للبخاري",'callback_data'=>'bo7hareai']],
[['text'=>"بر الوالدين في ضوء الكتاب والسنة",'callback_data'=>'kberrwalden']],
[['text'=>"بر_الوالدين بعد الزواج",'callback_data'=>'waldenb3delzoaj'],['text'=>"قصص في بر الوالدين",'callback_data'=>'kqsswalden']],
[['text'=>"بر الوالدين وحقوق الآباء والأبناء أحمد عاشور",'callback_data'=>'kahmed3shor']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data=="moss7fpdf"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم المصحف الشريف

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للمصاحف المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"مصحف رقم 1",'callback_data'=>'mos7f1'],['text'=>"مصحف رقم 2",'callback_data'=>'mos7f2']],
[['text'=>"مصحف رقم 3",'callback_data'=>'mos7f3'],['text'=>"مصحف رقم 4",'callback_data'=>'mos7f4']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data == "qsselwalden"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/3",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qsselwalden2"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/4",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "berrwlden"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/5",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "m7thrah"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/6",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "berr332"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/7",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "3qoqwalden"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/8",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "fthlelwlden"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/9",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "7h6bah"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/10",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qsqseat"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/11",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "waq3eay"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/12",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "gssvied"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/ddeneati/13",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "brrr54"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/14",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "elmngad"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/15",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "knblse"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/16",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "hnnaeio"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/17",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "bo7hareai"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/18",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "kberrwalden"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/19",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "waldenb3delzoaj"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/20",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "kqsswalden"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/21",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "kahmed3shor"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/22",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mos7f1"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/50",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mos7f2"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/51",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mos7f3"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/52",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mos7f4"){
   bot('sendDocument',[
    'chat_id'=>$chat_id2,
 'document'=>"https://t.me/ddeneati/53",
reply_to_message_id =>$message->message_id, 
]);
}





if($data=="Qasass"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص القران الكريم ، 🗂'

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للقصص المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"قصص النساء ف القران",'callback_data'=>'qn'],['text'=>"قصص الانبياء ف القران",'callback_data'=>'an']],
[['text'=>"قصص متنوعه من القران",'callback_data'=>'qqn'],['text'=>"قصص السيرة النبويه كامله",'callback_data'=>'ayn']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

/*
تنفيذ القصص
*/

if($data=="qn"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص النساء القران الكريم ، 🗂'

- اختر اسم القصه من الاسفل وساقوم بارسالها لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"قصة مريم بنت عمران عليه السلام",'callback_data'=>'qn1'],['text'=>"قصة زوجة فرعون وقصة ماشطه بنت فروع",'callback_data'=>'qn2']],
[['text'=>"قصة عائشه رضي الله عنها",'callback_data'=>'qn3'],['text'=>"فاطمه بنت محمد رضي الله عنها",'callback_data'=>'qn4']],
[['text'=>"قصة بلقيس ملكة سبا",'callback_data'=>'qn5'],['text'=>"قصة هاجر وماء زمزم",'callback_data'=>'qn6']],
[['text'=>"قصة خديجه رضي الله عنها",'callback_data'=>'qn7'],['text'=>"قصة اسيا بنت مزاحم",'callback_data'=>'qn8']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data == "qn1"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/2",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn2"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/6",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn3"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/7",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn4"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/9",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn5"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/10",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn6"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/5",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn7"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/32",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "qn8"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/30",
reply_to_message_id =>$message->message_id, 
]);
}

if($data=="an"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص النساء القران الكريم ، 🗂'

- اختر اسم القصه من الاسفل وساقوم بارسالها لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"قصة ادم عليه السلام",'callback_data'=>'sn1'],['text'=>"قصة ادريس عليه السلام",'callback_data'=>'sn2']],
[['text'=>"قصة نوح عليه السلام",'callback_data'=>'sn3'],['text'=>"قصة يوشع بن نون عليه السلام",'callback_data'=>'sn4']],
[['text'=>"قصة هود عليه السلام",'callback_data'=>'sn5'],['text'=>"قصة ابراهيم عليه السلام",'callback_data'=>'sn6']],
[['text'=>"قصة لوط عليه السلام",'callback_data'=>'sn7'],['text'=>"قصة العزير عليه السلام",'callback_data'=>'sn8']],
[['text'=>"قصة موسى عليه السلام",'callback_data'=>'sn9'],['text'=>"قصة ايوب عليه السلام",'callback_data'=>'sn10']],
[['text'=>"قصة سليمان عليه السلام",'callback_data'=>'sn11'],['text'=>"قصة صالح عليه السلام",'callback_data'=>'sn12']],
[['text'=>"قصة يونس عليه السلام",'callback_data'=>'sn13'],['text'=>"قصة يوسف عليه السلام",'callback_data'=>'sn14']],
[['text'=>"قصة عيسي عليه السلام",'callback_data'=>'sn15'],['text'=>"قصة داوود عليه السلام",'callback_data'=>'sn16']],
[['text'=>"قصة شعيب عليه السلام",'callback_data'=>'sn17'],['text'=>"قصة الخضر عليه السلام",'callback_data'=>'sn18']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data == "sn1"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/11",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn2"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/13",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn3"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/12",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn4"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/14",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn5"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/16",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn6"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/17",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn7"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/18",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn8"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/19",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn9"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/20",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn10"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/21",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn11"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/23",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn12"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/22",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn13"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/25",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn14"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/24",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn15"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/15",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn16"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/26",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn17"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/27?single",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn18"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/29?single",
reply_to_message_id =>$message->message_id, 
]);
}

if($data=="qqn"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم القصص المتنوعه ف القران الكريم ، 🗂'

- اختر اسم القصه من الاسفل وساقوم بارسالها لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"قصة قابيل و هابيل",'callback_data'=>'sn15'],['text'=>"قصة الخضر وذي القرنين",'callback_data'=>'sn16']],
[['text'=>"قصة يأجوج و مأجوج",'callback_data'=>'sn17'],['text'=>"قصة اصحاب السبت",'callback_data'=>'sn18']],
[['text'=>"قصة بقرة بنو اسرائيل",'callback_data'=>'sn19'],['text'=>"قصة اصحاب الكهف",'callback_data'=>'sn20']],
[['text'=>"قصة طالوت و جالوت",'callback_data'=>'sn21'],['text'=>"قصة سبأ",'callback_data'=>'sn22']],
[['text'=>"قصص سورة الكهف",'callback_data'=>'sn23'],['text'=>"قصة إبن الملك في دمشق",'callback_data'=>'sn24']],
[['text'=>"قصة رجل في عهد موسي",'callback_data'=>'sn25'],['text'=>"قصة رجل من مدينة الجبارين",'callback_data'=>'sn26']],
[['text'=>"قصة رجل فتن بالدنيا",'callback_data'=>'sn27'],['text'=>"قصة البقرة و هاروت و ماروت",'callback_data'=>'sn28']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data == "sn15"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/65",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn16"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/64",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn17"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/67",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn18"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/66",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn19"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/69",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn20"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/70",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn21"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/68",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn22"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/73",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn23"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/71",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn24"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/75",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn25"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/77",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn26"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/79",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn27"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/81",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "sn28"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/qesass1/83",
reply_to_message_id =>$message->message_id, 
]);
}

if($data=="ayn"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص النساء القران الكريم ، 🗂'

- اختر اسم القصه من الاسفل وساقوم بارسالها لك
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"ح 1 حال العرب في الجاهليه",'callback_data'=>'ayn1'],['text'=>"ح 2 عام الفيل",'callback_data'=>'ayn2']],
[['text'=>"ح 3 ولادة رسول الله صلى الله عليه وسلم",'callback_data'=>'ayn3'],['text'=>"ح 4 زواج النبي من خديجه ",'callback_data'=>'ayn4']],
[['text'=>"ح 5 نزول الوحي ",'callback_data'=>'ayn5'],['text'=>"ح 6 الدعوة إلى الله والجهر بها",'callback_data'=>'ayn6']],
[['text'=>"ح 7 تآمر المشركين على النبي صلى الله عليه وسلم",'callback_data'=>'ayn7'],['text'=>"ح 8 إيذاء قريش للنبي والمؤمنين",'callback_data'=>'ayn8']],
[['text'=>"ح 9 الهجرة إلى الحبشة",'callback_data'=>'ayn9'],['text'=>"ح 10 المقاطعة وعام الحزن",'callback_data'=>'ayn10']],
[['text'=>"ح 11 الإسراء والمعراج والبيعة",'callback_data'=>'ayn11'],['text'=>"ح 12 الهجرة إلى المدينة المنورة",'callback_data'=>'ayn12']],
[['text'=>"ح 13 بداية المرحلة المدنية",'callback_data'=>'ayn13'],['text'=>"ح 14 السرايا والبعوث قبل بدر",'callback_data'=>'ayn14']],
[['text'=>"ح 15 غزوة بدر الكبرى",'callback_data'=>'ayn15'],['text'=>"ح 16 جلاء يهود بني قينقاع",'callback_data'=>'ayn16']],
[['text'=>"ح 17 غزوة أحد",'callback_data'=>'ayn17'],['text'=>"ح 18 غزوة حمراء الأسد",'callback_data'=>'ayn18']],
[['text'=>"ح 19 غزوة الأحزاب",'callback_data'=>'ayn19'],['text'=>"ح 20 غزوة بني قريظة",'callback_data'=>'ayn20']],
[['text'=>"ح 21 غزوة بني المصطلق",'callback_data'=>'ayn21'],['text'=>"ح 22 صلح الحديبية",'callback_data'=>'ayn22']],
[['text'=>"ح 23 فتح خيبر",'callback_data'=>'ayn23'],['text'=>"ح 24 عمرة القضاء ومعركة مؤتة",'callback_data'=>'ayn24']],
[['text'=>"ح 25 فتح مكة",'callback_data'=>'ayn25'],['text'=>"ح 26 غزوة حنين",'callback_data'=>'ayn26']],
[['text'=>"ح 27 معركة تبوك",'callback_data'=>'ayn27'],['text'=>"ح 28 حجة الوداع",'callback_data'=>'ayn28']],
[['text'=>"ح 29 وفاة النبي صلى الله عليه وسلم",'callback_data'=>'ayn29'],['text'=>"ح 30 الحلقة الأخيرة",'callback_data'=>'ayn30']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}

if($data == "ayn1"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/34",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn2"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/35",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn3"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/36",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn4"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/37",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn5"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/38",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn6"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/39",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn7"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/40",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn8"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/41",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn9"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/42",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn10"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/43",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn11"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/44",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn12"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/45",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn13"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/46",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn14"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/47",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "ayn15"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/48",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn16"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/49",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn17"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/50",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn18"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/51",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn19"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/52",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn20"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/53",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn21"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/54",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn22"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/55",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn23"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/56",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn24"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/57",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn25"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/58",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn26"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/59",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn27"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/60",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn28"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/61",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn29"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/62",
reply_to_message_id =>$message->message_id, 
]);
}
 if($data == "ayn30"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/qesass1/63",
reply_to_message_id =>$message->message_id, 
]);
}
 



if($data=="roqua"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم قصص الرقيه الشرعيه ، 🗂'
     
- أسأل الله تعال أن يكتب الأجر لي ولك ❤️

- قم بااختيار الشيخ من الاسفل 
   ﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 reply_markup =>json_encode([
 inline_keyboard =>[
[['text'=>"الرقيه الاكثر استماع و الاعجاب",'callback_data'=>'الرقية']],
[[ 'text' => 'الصور .',callback_data => 'soarroqea' ],[ 'text' => 'الفيديو .',callback_data => 'vidroqea' ]],
[[ 'text' => 'ياسر الدوسري .',callback_data => 'mt1' ],['text'=> 'ماهر المعيقلي' ,callback_data => 'mt2']] ,
[[ 'text' => 'عمر العنزي .',callback_data => 'mt3' ],['text'=> 'نبيل العوضي .' ,callback_data => 'mt4']] ,
[[ 'text' => 'عبد الباسط عبد الصمد .',callback_data => 'mt5' ],['text'=> 'مشاري العفاسي .' ,callback_data => 'mt6']] ,
[[ 'text' => 'أحمد العجمي .',callback_data => 'mt7' ],['text'=> 'عمر عبد الكافي .' ,callback_data => 'mt8']] ,
[[ 'text' => 'سعد الغامدي .',callback_data => 'mt9' ],['text'=> 'عبد الرحمن السديس .' ,callback_data => 'mt10']] ,
[[ 'text' => 'اسلام صبحي .',callback_data => 'mt11' ],['text'=> 'ناصر القطامي .' ,callback_data => 'mt12']] ,
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],   
    ]
    ])
    ]);
    }

if($data=="soarroqea"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم صور الرقيه الشرعيه

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للصور المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"صورة رقم 1",'callback_data'=>'soar0h1'],['text'=>"صورة2",'callback_data'=>'so0rah2']],
[['text'=>"صورة 3",'callback_data'=>'so0rah3'],['text'=>"صورة 4",'callback_data'=>'so0rah4']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data=="vidroqea"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم الفيديو للرقية الشرعيه

 - اختر اسم القسم من الاسفل وساقوم بتحويلك للصور المتوفره داخله
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"فيديو رقم 1",'callback_data'=>'vvidd1'],['text'=>"فيديو رقم2",'callback_data'=>'vvidd2']],
[['text'=>"صورة 3",'callback_data'=>'so0rah3'],['text'=>"صورة 4",'callback_data'=>'so0rah4']],
[['text'=>"العودة 🔙",'callback_data'=>"rj03"]],
]
])
]);
}
if($data == "soar0h1"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/23",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "so0rah2"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/24",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "so0rah3"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/25",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "so0rah4"){
   bot('sendphoto',[
    'chat_id'=>$chat_id2,
 'photo'=>"https://t.me/ddeneati/26",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "vvidd1"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/ddeneati/27",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "vvidd2"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/ddeneati/28",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "vvidd3"){
   bot('sendvideo',[
    'chat_id'=>$chat_id2,
 'video'=>"https://t.me/ddeneati/29",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt1"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/20",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt2"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/30",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt3"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/34",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt4"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/35",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt5"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/31",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt6"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/32",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt7"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/33",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt8"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/34",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt9"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/35",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt10"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/36",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt11"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/37",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "mt12"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/ddeneati/38",
reply_to_message_id =>$message->message_id, 
]);
}





if($data=="tf"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم تفسير القرآن الكريم ، 🗂'

- اختر اسم القسم من الاسفل 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"التفسير الصوتي",'callback_data'=>'sttf'],['text'=>"كتب تفسير",'callback_data'=>'ftft']],
[['text'=>"العودة 🔙",'callback_data'=>"olomq"]],
]])]);}

if($data=="sttf"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم التفسير الصوتي للقرآن الكريم ، 🗂'

- اختر اسم التفسير من الاسفل
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"سورة الفاتحه",'callback_data'=>'st1'],['text'=>"سورة النبا",'callback_data'=>'st2']],
[['text'=>"سورة يوسف",'callback_data'=>'st3'],['text'=>"سورة هود",'callback_data'=>'st4']],
[['text'=>"سورة الزلزله",'callback_data'=>'st5'],['text'=>"سورة التكوير",'callback_data'=>'st6']],
[['text'=>"سورة التحريم",'callback_data'=>'st7'],['text'=>"سورة الطلاق",'callback_data'=>'st8']],
[['text'=>"سورة الهمزه",'callback_data'=>'st9'],['text'=>"سورة الاخلاص",'callback_data'=>'st10']],
[['text'=>"سورة الفلق",'callback_data'=>'st11'],['text'=>"سورة الناس",'callback_data'=>'st12']],
[['text'=>"العودة 🔙",'callback_data'=>"tf"]],
]])]);}

if($data == "st1"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/64",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "st2"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/65",
reply_to_message_id =>$message->message_id, 
]);
} 
if($data == "st3"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/66",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "st4"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/67",
reply_to_message_id =>$message->message_id, 
]);
} 
if($data == "st5"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/68",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "st6"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/69",
reply_to_message_id =>$message->message_id, 
]);
} 
if($data == "st7"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/70",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "st8"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/71",
reply_to_message_id =>$message->message_id, 
]);
} 
if($data == "st9"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/72",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "st10"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/73",
reply_to_message_id =>$message->message_id, 
]);
} 
if($data == "st11"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/74",
reply_to_message_id =>$message->message_id, 
]);
}
if($data == "st12"){
   bot('sendaudio',[
    'chat_id'=>$chat_id2,
 'audio'=>"https://t.me/sand_199/75",
reply_to_message_id =>$message->message_id, 
]);
} 

if($data=="ftft"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
 'text'=>"
- أهلاً بك مجدداً [$Name](tg://user?id=$chat_id2)

في قسم كتب تفسير القرآن الكريم ، 🗂

- اختر اسم الكتاب من الاسفل 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[ • قناة البوت ♡ آج‌ــ‌๋ـر ♡ 🌸؛](https://t.me//$ch)",
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
 'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"اكتاب تفسير السعدي",'callback_data'=>'ft1'],['text'=>"التفسير المسير لنخبه من العلماء",'callback_data'=>'ft2']],
[['text'=>"ااضواء البيان في ايضاح القران بالقران",'callback_data'=>'ft3'],['text'=>"كتاب تفسير القران للشيخ ابن عثيمين",'callback_data'=>'ft4']],
[['text'=>"العودة 🔙",'callback_data'=>"tf"]],
]])]);}
if($data == "ft1"){
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://t.me/sand_199/60",
]);}
if($data == "ft2"){
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://t.me/sand_199/61",
]);}
if($data == "ft3"){
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://t.me/sand_199/62",
]);}
if($data == "ft4"){
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://t.me/sand_199/63",
]);}



$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$id = $message->from->id;
$from_id = $message->from->id;
$name = $message->from->first_name;
if(isset($update->callback_query)){
$callbackMessage = '';
var_dump(bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>$callbackMessage]));
$up = $update->callback_query;
$chat_id = $up->message->chat->id;
$from_id = $up->from->id;
$user = $up->from->username;
$name = $up->from->first_name;
$message_id = $up->message->message_id;
$data = $up->data;
}
mkdir("sudo");


#البوت الجديد 



if($data =="سور"){
$keyboard["inline_keyboard"]=[];
$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?json=suwar"))->info;
for($i=0;$i<98;$i++){
$post=$postpost[$i];
	  	 $urlpost=$post->number;
	  	  $namepost=$post->name;
$stats="bb $urlpost $namepost";
$to=$i+1;
$post2=$postpost[$to];
	  	 $urlpost2=$post2->number;
	  	  $namepost2=$post2->name;
	  	  
$stats2="bb $urlpost2 $namepost2";
	$keyboard["inline_keyboard"][] = [['text'=>$namepost2,'callback_data'=>"$stats2"],['text'=>$namepost,'callback_data'=>"$stats"]];

$i++;
}
$talt="القائمة التالية";
$keyboard["inline_keyboard"][] = [['text'=>$talt,'callback_data'=>"التالي"]];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"rj03"]];
$reply_markup=json_encode($keyboard);


bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 هذة قائمة بسور القرآن الكريم قم بالضغط على اسم السورة لكي يتم تحميلها",		
'reply_markup'=>$reply_markup
]);
}

if($data == "التالي"){
$keyboard["inline_keyboard"]=[];
$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?json=suwar"))->info;
for($i=98;$i<114;$i++){
$post=$postpost[$i];
	  	 $urlpost=$post->number;
	  	  $namepost=$post->name;
$stats="bb $urlpost $namepost";
$to=$i+1;
$post2=$postpost[$to];
	  	 $urlpost2=$post2->number;
	  	  $namepost2=$post2->name;
$stats2="bb $urlpost2 $namepost2";
	$keyboard["inline_keyboard"][] = [['text'=>$namepost2,'callback_data'=>"$stats2"],['text'=>$namepost,'callback_data'=>"$stats"]];

$i++;
}
$talt="القائمة السابقة";
$keyboard["inline_keyboard"][] = [['text'=>$talt,'callback_data'=>"سور"]];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"rj03"]];
$reply_markup=json_encode($keyboard);


	  bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 هذة قائمة بسور القرآن الكريم قم بالضغط على اسم السورة لكي يتم تحميلها.",		
'reply_markup'=>$reply_markup
]);


}
#القرأء المتوفرين

if (preg_match('/^(bb) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$number= $data1['1'];
				$names= $data1['2'];
$keyboard["inline_keyboard"]=[];
$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?json=status"))->info;

foreach($postpost as $co => $count){


	  	 $urlpost=$co;
	  	  $namepost=$count;
$stats="get $urlpost $number $names ";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];


}
$reply_markup=json_encode($keyboard);

	  	  bot('sendmessage', [
'chat_id' => $chat_id,
	'text'=>"🔘 قم بإختيار القارئ الذي تود تحميل السورة بصوتة 
	
	⚠ تنوية : اذا لم يتم تنزيل السورة قم بتجربة التنزيل بصوت شيخ اخر
	$reply_markupp
					",		
'reply_markup'=>$reply_markup
]);
}#end if

if (preg_match('/^(get) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$url= $data1['1'];
				$shik= $data1['2'];
				$names= $data1['3'];
	 bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"جاري جلب سورة  $names  انتظر قليلا من فظلك ...⏳ 
					
[🔗 رابط تحميل مباشر ](http://download.tvquran.com/download/$url/$shik)",
'parse_mode'=>"MarkDown",
					
				
]);

$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?mp3=$url/$shik"))->info->url;
file_put_contents($chat_id.'.mp3',file_get_contents($postpost));

$audio =bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"✅ تم جلب سورة $names بنجاح 
					اذا كنت تريد تحميلها قم بالضغط على زر التحميل 📥",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📥 تحميل السورة ",'callback_data'=>'downlode '.$url." $shik $names"]],
]
])
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$url/$shik"]],
]
])
]);

}
}

if (preg_match('/^(downlode) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$surh= $data1['1'];
$shik= $data1['2'];
				$names= $data1['3'];
				
				$json = json_decode(file_get_contents("gra.json"),true);
				$gar=$json["info"]["$surh"];
				
bot('editmessagetext', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"⌛ جاري تحميل سورة $names  بصوت $gar
					",
]);

			$audio = bot('sendaudio',[
       'chat_id'=>$chat_id,
       'audio'=>new CURLFile($chat_id.'.mp3'),
       'performer'=>$gar,
       'title'=>$names.'.mp3' ,
       'caption'=>"@thkker_bot" ,
       
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$surh/$shik"]],
]
])
]);


}else{

bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل سورة $names  بصوت $gar
					",
]);

}
bot('sendaudioo',[
       'chat_id'=>$chat_id,
       'audio'=>"http://download.tvquran.com/download/$surh",
]);

unlink($chat_id.'.mp3');
}


if (preg_match('/^(اضافة) (.*)/s',$text) and $from_id ==$admin) {
$data1 = explode(" ",$text);
$url= $data1['1'];
$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?downlod=$url"));

	 bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"تم",		
]);
}

if (preg_match('/^(رقية) (.*)/s',$text) and $from_id ==$admin) {
$data1 = explode(" ",$text);
$url= $data1['1'];
$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?downlodr=$url"));

	 bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"تم",		
]);
}


if (preg_match('/^(جلب) (.*)/s',$text) and $from_id ==$admin) {
$data1 = explode(" ",$text);
$url= $data1['1'];
	 bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"تم",		
					
			
]);
$get =file_get_contents("$url");

file_put_contents("home.txt",$get);
}


if($data == "الرقية"){
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الرقية الشرعية قم بإختيار القسم الذي يتناسبك . .",		
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"الاكثر استماعاً  ",'callback_data'=>"Rouqiaa most_listened"]],
[['text'=>"الاكثر اعجاباً  ",'callback_data'=>"Rouqiaa likes"]],
[['text'=>"الاحدث  ",'callback_data'=>"Rouqiaa new"]],
[['text'=>"عشوائية  ",'callback_data'=>"Rouqiaa random"]],
[['text'=>"عودة للقائمة الرئيسية  ",'callback_data'=>"rj03"]],
]
])
]);


}

if (preg_match('/^(Rouqiaa) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&view=most_listened&sort=desc";
$tt="🔖 | قسم الرقية الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&view=likes&sort=desc";
$tt="🔖 | قسم الرقية الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&view=new&sort=desc";
$tt="🔖 | قسم الرقية الاحــــــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&view=random&sort=desc";
$tt="🔖 | قسم الرقية العشوائيةً";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];
file_put_contents("rgiah.txt","$a\n\n$gara\n",FILE_APPEND);

$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];




  	  $namepost="$namesh $namer";
$stats="Rouqia $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}



$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkh $no3 1"],['text'=>$talt,'callback_data'=>"altalih $no3 2"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الرقية"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الرقية  بإختيار الرقية لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}

if (preg_match('/^(alsabkh) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
$numbre= $data1['2'];

if($numbre!="0"){
if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=most_listened&sort=desc";
$tt="🔖 | قسم الرقية الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=likes&sort=desc";
$tt="🔖 | قسم الرقية الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=new&sort=desc";
$tt="🔖 | قسم الرقية الاحــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=random&sort=desc";
$tt="🔖 | قسم الرقية العشوائية ";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];
file_put_contents("rgiah.txt","$a\n\n$gara\n",FILE_APPEND);

$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];



  	  $namepost="$namesh $namer";
$stats="Rouqia $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}


$numbres= $numbre-1;
$numbret= $numbre+1;
$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkh $no3 $numbres"],['text'=>$talt,'callback_data'=>"altalih $no3 $numbret"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الرقية"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الرقية  بإختيار الرقية لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}
}
if (preg_match('/^(altalih) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
$numbre= $data1['2'];
if($numbre!="q0"){

if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=most_listened&sort=desc";
$tt="🔖 | قسم الرقية الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=likes&sort=desc";
$tt="🔖 | قسم الرقية الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=new&sort=desc";
$tt="🔖 | قسم الرقية الاحــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/6?json=1&page=$numbre&view=random&sort=desc";
$tt="🔖 | قسم الرقية العشوائية ";
}


$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];
file_put_contents("rgiah.txt","$a\n\n$gara\n",FILE_APPEND);

$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];



 $namepost="$namesh $namer";
$stats="Rouqia $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}


$numbres= $numbre-1;
$numbret= $numbre+1;
$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkh $no3 $numbres"],['text'=>$talt,'callback_data'=>"altalih $no3 $numbret"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الرقية"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الرقية  بإختيار الرقية لكي يتم تنزيلها 
$tt
",		
'reply_markup'=>$reply_markup
]);


}
}



if (preg_match('/^(Rouqia) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$url= $data1['1'];
				$no3= $data1['2'];
		
	 bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"جاري تنزيل الرقية الشرعية   ...⏳ 
					
[🔗 رابط تحميل مباشر ](http://download.tvquran.com/download/$url)",
'parse_mode'=>"MarkDown",
					
				
]);

$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?mp3=$url"))->info->url;
file_put_contents($chat_id.'.mp3',file_get_contents($postpost));

$audio =bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل الرقية الشرعية بنجاح
					اذا كنت تريد تحميلها قم بالضغط على زر التحميل 📥",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📥 تحميل الرقية ",'callback_data'=>'downloder '.$url." $no3"]],
]
])
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$url"]],
]
])
]);

}
}

if (preg_match('/^(downloder) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$surh= $data1['1'];
$no3= $data1['2'];
	
				
				$json = json_decode(file_get_contents("rgiah$no3.json"),true);
				$gar=$json["info"]["$surh"];
				


			$audio = bot('sendaudio',[
       'chat_id'=>$chat_id,
       'audio'=>new CURLFile($chat_id.'.mp3'),
       'performer'=>$gar,
       'title'=>'الرقية الشرعية.mp3' ,
       'caption'=>"
       $gar
       
       @thkker_bot" ,
       
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن للبوت جلب المقاطع الصوتية التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$surh"]],
]
])
]);


}else{
bot('editmessagetext', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل الرقية الشرعية
					",
]);


}
bot('sendaudioo',[
       'chat_id'=>$chat_id,
       'audio'=>"http://download.tvquran.com/download/$surh",
]);

unlink($chat_id.'.mp3');
}

if($data =="الاذكار"){

$keyboard["inline_keyboard"]=[];
$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?athkar=yes"))->info;

foreach($postpost as $co => $count){


	  	 $urlpost=$co;
	  	  $namepost=$count;
$stats="athkar $urlpost ";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];


}
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"rj03"]];

$reply_markup=json_encode($keyboard);

	  	  bot('editmessagetext', [
	  	  'message_id' => $message_id,
'chat_id' => $chat_id,
	'text'=>"🔘 قم بإختيار الاذكار لتحميلها 
	
	$reply_markupp
					",		
'reply_markup'=>$reply_markup
]);
}#end if



if (preg_match('/^(athkar) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$url= $data1['1'];
			
				$names= $data1['2'];
	 bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"جاري جلب الاذكار انتظر قليلا من فظلك ...⏳ 
					
[🔗 رابط تحميل مباشر ](http://download.tvquran.com/download/$url)",
'parse_mode'=>"MarkDown",
					
				
]);

$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?mp3=$url"))->info->url;
file_put_contents($chat_id.'.mp3',file_get_contents($postpost));

$audio =bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"✅ تم جلب الاذكار بنجاح 
					اذا كنت تريد تحميلها قم بالضغط على زر التحميل 📥",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📥 تحميل الاذكار ",'callback_data'=>'downlodeathkar '.$url." $names"]],
]
])
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع الصوتية التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$url"]],
]
])
]);

}
}

if (preg_match('/^(downlodeathkar) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$surh= $data1['1'];
				$names= $data1['2'];
				
				$json = json_decode(file_get_contents("athkar.json"),true);
				$gar=$json["info"]["$surh"];
				
bot('editmessagetext', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"⌛ جاري تحميل  $gar
					",
]);

			$audio = bot('sendaudio',[
       'chat_id'=>$chat_id,
       'audio'=>new CURLFile($chat_id.'.mp3'),
       'performer'=>$gar,
       'title'=>$names.'.mp3' ,
       'caption'=>"@thkker_bot" ,
       
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع الصوتية التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$surh"]],
]
])
]);


}else{

bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل $gar
					",
]);

}
bot('sendaudioo',[
       'chat_id'=>$chat_id,
       'audio'=>"http://download.tvquran.com/download/$surh",
]);

unlink($chat_id.'.mp3');
}

if($data == "الادعية"){
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الادعية قم بإختيار القسم الذي يتناسبك . .",		
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"الادعية الاكثر استماعاً  ",'callback_data'=>"ad3ihh most_listened"]],
[['text'=>"الادعية الاكثر اعجابً  ",'callback_data'=>"ad3ihh likes"]],
[['text'=>"الادعية الاحدث  ",'callback_data'=>"ad3ihh new"]],
[['text'=>"الادعية العشوائية  ",'callback_data'=>"ad3ihh random"]],
[['text'=>"عودة للقائمة الرئيسية  ",'callback_data'=>"rj03"]],
]
])
]);


}

if (preg_match('/^(ad3ihh) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&view=most_listened&sort=desc";
$tt="🔖 | قسم الادعية الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&view=likes&sort=desc";
$tt="🔖 | قسم الادعية الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&view=new&sort=desc";
$tt="🔖 | قسم الادعية الاحــــــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&view=random&sort=desc";
$tt="🔖 | قسم الادعية العشوائيةً";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];
file_put_contents("rgiah.txt","$a\n\n$gara\n",FILE_APPEND);

$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];




  	  $namepost="$namesh $namer";
$stats="ad3ih $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}



$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkha $no3 1"],['text'=>$talt,'callback_data'=>"altaliha $no3 2"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الادعية"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الادعية اختر الدعاء لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}

if (preg_match('/^(alsabkha) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
$numbre= $data1['2'];

if($numbre!="0"){
if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=most_listened&sort=desc";
$tt="🔖 | قسم الادعية الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=likes&sort=desc";
$tt="🔖 | قسم الادعية الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=new&sort=desc";
$tt="🔖 | قسم الادعية الاحــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=random&sort=desc";
$tt="🔖 | قسم الادعية العشوائية ";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];


$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];



  	  $namepost="$namesh $namer";
$stats="ad3ih $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}


$numbres= $numbre-1;
$numbret= $numbre+1;
$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkha $no3 $numbres"],['text'=>$talt,'callback_data'=>"altaliha $no3 $numbret"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الادعية"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الادعية  اختر الدعاء لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}
}
if (preg_match('/^(altaliha) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
$numbre= $data1['2'];
if($numbre!="q0"){

if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=most_listened&sort=desc";
$tt="🔖 | قسم الادعية الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=likes&sort=desc";
$tt="🔖 | قسم الادعية الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=new&sort=desc";
$tt="🔖 | قسم الادعية الاحــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/4?json=1&page=$numbre&view=random&sort=desc";
$tt="🔖 | قسم الادعية العشوائية ";
}



$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];
file_put_contents("rgiah.txt","$a\n\n$gara\n",FILE_APPEND);

$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];



 $namepost="$namesh $namer";
$stats="ad3ih $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}


$numbres= $numbre-1;
$numbret= $numbre+1;
$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkha $no3 $numbres"],['text'=>$talt,'callback_data'=>"altaliha $no3 $numbret"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الادعية"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم الادعية  اختر الدعاء لكي يتم تنزيلها 
$tt
",		
'reply_markup'=>$reply_markup
]);


}
}



if (preg_match('/^(ad3ih) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$url= $data1['1'];
				$no3= $data1['2'];
		
	 bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"جاري تنزيل الدعاء    ...⏳ 
					
[🔗 رابط تحميل مباشر ](http://download.tvquran.com/download/$url)",
'parse_mode'=>"MarkDown",
					
				
]);

$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?mp3=$url"))->info->url;
file_put_contents($chat_id.'.mp3',file_get_contents($postpost));

$audio =bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل الدعاء  بنجاح
					اذا كنت تريد تحميلها قم بالضغط على زر التحميل 📥",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📥 تحميل الدعاء ",'callback_data'=>'downloded '.$url." $no3"]],
]
])
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$url"]],
]
])
]);

}
}

if (preg_match('/^(downloded) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$surh= $data1['1'];
$no3= $data1['2'];
	
		
			$audio = bot('sendaudio',[
       'chat_id'=>$chat_id,
       'audio'=>new CURLFile($chat_id.'.mp3'),
       'performer'=>$gar,
       'title'=>'دعاء .mp3' ,
       'caption'=>"
       $gar
       
       @thkker_bot" ,
       
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن للبوت جلب المقاطع الصوتية التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$surh"]],
]
])
]);


}else{
bot('editmessagetext', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل الدعاء
					",
]);


}
bot('sendaudioo',[
       'chat_id'=>$chat_id,
       'audio'=>"http://download.tvquran.com/download/$surh",
]);

unlink($chat_id.'.mp3');
}

#الاطفال


if($data == "الاطفال"){
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم تلاوات الاطفال قم بإختيار القسم الذي يتناسبك . .",		
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"تلاوات الاكثر استماعاً  ",'callback_data'=>"tlawatat most_listened"]],
[['text'=>"تلاوات الاكثر اعجابً  ",'callback_data'=>"tlawatat likes"]],
[['text'=>"تلاوات الاحدث  ",'callback_data'=>"tlawatat new"]],
[['text'=>"تلاوات العشوائية  ",'callback_data'=>"tlawatat random"]],
[['text'=>"عودة للقائمة الرئيسية  ",'callback_data'=>"rj03"]],
]
])
]);


}

if (preg_match('/^(tlawatat) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&view=most_listened&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&view=likes&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&view=new&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاحــــــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&view=random&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال العشوائيةً";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];
file_put_contents("rgiah.txt","$a\n\n$gara\n",FILE_APPEND);

$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];




  	  $namepost="$namesh $namer";
$stats="tlawata $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}



$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkhtl $no3 1"],['text'=>$talt,'callback_data'=>"altalihtl $no3 2"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الاطفال"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم تلاوات الاطفال اختر التلاوة لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}

if (preg_match('/^(alsabkhtl) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
$numbre= $data1['2'];

if($numbre!="0"){
if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=most_listened&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=likes&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=new&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاحــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=random&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال العشوائية ";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];


$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];



  	  $namepost="$namesh $namer";
$stats="tlawata $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}


$numbres= $numbre-1;
$numbret= $numbre+1;
$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkhtl $no3 $numbres"],['text'=>$talt,'callback_data'=>"altalihtl $no3 $numbret"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الاطفال"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم تلاوات الاطفال  اختر التلاوة لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}
}
if (preg_match('/^(altalihtl) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$no3= $data1['1'];
$numbre= $data1['2'];
if($numbre!="q0"){

if($no3=="most_listened"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=most_listened&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاكثر استماعاً";
}
if($no3=="likes"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=likes&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاكثر اعجاباً";
}
if($no3=="new"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=new&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال الاحــــدثً";
}
if($no3=="random"){
$url="https://www.tvquran.com/ar/selections/category/7?json=1&page=$numbre&view=random&sort=desc";
$tt="🔖 | قسم تلاوات الاطفال العشوائية ";
}

$keyboard["inline_keyboard"]=[];

$post= file_get_contents("$url");

$array=[];

$strname1=str_replace(['ترتيب','<aside class="col-lg-3">'],"watawname",$post);

$ex=explode('watawname',$strname1);

$posts=$ex['1'];

$ex1=explode('<article class="l-box"',$posts);

for($a=1;$a<count($ex1);$a++){

$gara=$ex1[$a];


$str=str_replace(['<h4>','</h4>'],"wataw",$gara);

$ex2=explode('wataw',$str);

$shik=$ex2['0'];

$strname2=str_replace(['alt="','"></'],"watawnameyes",$shik);

$ex3=explode('watawnameyes',$strname2);
$namesh=$ex3['1'];

$strname22=str_replace(['<h3>','</h3>'],"watawnamer",$shik);

$ex4=explode('watawnamer',$strname22);
$namer=$ex4['1'];









$str2=str_replace(['<a href="//download.tvquran.com/download/','" download="//download.tvquran.com/download/'],"wataw",$gara);

if(strpos($gara,"//download.tvquran.com/download/") !== false){


$ex5=explode('wataw',$str2);

$id=$ex5['1'];



  	  $namepost="$namesh $namer";
$stats="tlawata $id $no3";

	$keyboard["inline_keyboard"][] = [['text'=>$namepost,'callback_data'=>$stats]];

}}


$numbres= $numbre-1;
$numbret= $numbre+1;
$talt="التالي";
$keyboard["inline_keyboard"][] = [['text'=>"السابق",'callback_data'=>"alsabkhtl $no3 $numbres"],['text'=>$talt,'callback_data'=>"altalihtl $no3 $numbret"]
];
$keyboard["inline_keyboard"][] = [['text'=>"عودة",'callback_data'=>"الاطفال"]];

$reply_markup=json_encode($keyboard);
bot('editmessagetext', [
'message_id' => $message_id,
'chat_id' => $chat_id,
'text'=>"📑 اهلا بك $name في قسم تلاوات الاطفال  اختر التلاوة لكي يتم تنزيلها 

$tt",		
'reply_markup'=>$reply_markup
]);


}
}



if (preg_match('/^(tlawata) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$url= $data1['1'];
				$no3= $data1['2'];
		
	 bot('sendmessage', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"جاري تنزيل التلاوة    ...⏳ 
					
[🔗 رابط تحميل مباشر ](http://download.tvquran.com/download/$url)",
'parse_mode'=>"MarkDown",
					
				
]);

$postpost =json_decode(file_get_contents("https://hmsbots.aba.vg/apigouran/api_quran.php?mp3=$url"))->info->url;
file_put_contents($chat_id.'.mp3',file_get_contents($postpost));

$audio =bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"✅ تم التلاوة  بنجاح
					اذا كنت تريد تحميلها قم بالضغط على زر التحميل 📥",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📥 تحميل الدعاء ",'callback_data'=>'downlodetl '.$url." $no3"]],
]
])
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن اللبوت جلب المقاطع التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$url"]],
]
])
]);

}
}

if (preg_match('/^(downlodetl) (.*)/s',$data) ) {
$data1 = explode(" ",$data);
$surh= $data1['1'];
$no3= $data1['2'];
	
		
			$audio = bot('sendaudio',[
       'chat_id'=>$chat_id,
       'audio'=>new CURLFile($chat_id.'.mp3'),
       'performer'=>$gar,
       'title'=>'تلاوة .mp3' ,
       'caption'=>"
       $gar
       
       @thkker_bot" ,
       
]);
$get=$audio->ok;
if($get!=1){
bot('sendmessage',[
					'chat_id'=>$chat_id,
					'text'=>"🚫 المعذرة لا يمكن للبوت جلب المقاطع الصوتية التي يزيد حجمها عن 50MB تم ارفاق رابط تحميل مباشر لتحميل السورة من الموقع الرئيسي عبر اي متصفح ",		
					'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رابط التحميل المباشر  ",'url'=>"http://download.tvquran.com/download/$surh"]],
]
])
]);


}else{
bot('editmessagetext', [
'message_id' => $message_id,
					'chat_id'=>$chat_id,
					'text'=>"✅ تم تحميل التلاوة
					",
]);


}
}


